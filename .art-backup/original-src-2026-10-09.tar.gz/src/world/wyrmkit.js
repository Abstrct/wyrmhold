// @ts-nocheck
/* WyrmKit — the living world of Wyrmhold.
 * Procedural sky-isles, beasts and rites, drawn with three.js (window.THREE).
 * Every scene returns a small controller; the page markup drives it. */
import * as T from 'three';

  var K = {};
  var TAU = Math.PI * 2;

  /* ------------------------------------------------------------------ utils */
  function rng(seed) {
    var s = (seed >>> 0) || 1;
    return function () { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
  }
  function hashStr(str) {
    var h = 2166136261;
    str = String(str);
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function makeNoise(seed) {
    var r = rng(seed), p = new Float32Array(256), perm = new Uint8Array(512), i;
    for (i = 0; i < 256; i++) { p[i] = r(); perm[i] = i; }
    for (i = 255; i > 0; i--) { var j = Math.floor(r() * (i + 1)), tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp; }
    for (i = 0; i < 256; i++) perm[i + 256] = perm[i];
    function lat(ix, iy) { return p[perm[(ix & 255) + perm[iy & 255]]]; }
    function sm(t) { return t * t * (3 - 2 * t); }
    function n(x, y) {
      var ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
      var a = lat(ix, iy), b = lat(ix + 1, iy), c = lat(ix, iy + 1), d = lat(ix + 1, iy + 1);
      var u = sm(fx), v = sm(fy);
      return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
    }
    return function (x, y, oct) {
      oct = oct || 4;
      var s = 0, amp = 0.5, f = 1, norm = 0;
      for (var o = 0; o < oct; o++) { s += amp * n(x * f, y * f); norm += amp; f *= 2.03; amp *= 0.5; }
      return s / norm;
    };
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, k) { return a + (b - a) * k; }
  K.rng = rng; K.hashStr = hashStr; K.makeNoise = makeNoise;

  K.C = {
    night: 0x0b0e1a, gold: 0xe8c872, verdigris: 0x5fd3b5, ember: 0xff7a4d,
    violet: 0x8b6cff, rose: 0xff8fb1, moss: 0x4f7f4a, stone: 0x6b6478, ice: 0x9fd8ff
  };

  /* --------------------------------------------------------------- materials */
  function M(color, o) {
    o = o || {};
    return new T.MeshStandardMaterial({
      color: color, flatShading: true,
      roughness: o.r != null ? o.r : 0.78, metalness: o.m || 0,
      emissive: o.e != null ? o.e : 0x000000, emissiveIntensity: o.ei != null ? o.ei : 1,
      transparent: !!o.t, opacity: o.o != null ? o.o : 1,
      side: o.ds ? T.DoubleSide : T.FrontSide, vertexColors: !!o.vc
    });
  }
  function G(color, o) {
    o = o || {};
    return new T.MeshBasicMaterial({
      color: color, toneMapped: false, transparent: !!o.t, opacity: o.o != null ? o.o : 1,
      blending: o.add ? T.AdditiveBlending : T.NormalBlending, depthWrite: o.add ? false : true,
      side: o.ds ? T.DoubleSide : T.FrontSide
    });
  }
  function mesh(geo, mat, x, y, z) {
    var m = new T.Mesh(geo, mat);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true; m.receiveShadow = true;
    return m;
  }
  function chain(n, r0, r1, mat, detail) {
    var g = new T.Group(), segs = [];
    for (var i = 0; i < n; i++) {
      var k = n > 1 ? i / (n - 1) : 0;
      var s = mesh(new T.IcosahedronGeometry(lerp(r0, r1, k), detail || 0), mat);
      g.add(s); segs.push(s);
    }
    return { group: g, segs: segs };
  }

  var texCache = {};
  function glowTexture(inner, outer, key) {
    key = key || ('g' + inner + outer);
    if (texCache[key]) return texCache[key];
    var c = document.createElement('canvas'); c.width = c.height = 128;
    var x = c.getContext('2d');
    var gr = x.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, inner); gr.addColorStop(0.25, inner); gr.addColorStop(1, outer);
    x.fillStyle = gr; x.fillRect(0, 0, 128, 128);
    var t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace;
    texCache[key] = t;
    return t;
  }
  function softDot() { return glowTexture('rgba(255,255,255,1)', 'rgba(255,255,255,0)', 'dot'); }
  function glowSprite(color, size, opacity) {
    var s = new T.Sprite(new T.SpriteMaterial({
      map: softDot(), color: color, transparent: true, opacity: opacity == null ? 0.8 : opacity,
      blending: T.AdditiveBlending, depthWrite: false, toneMapped: false
    }));
    s.scale.setScalar(size || 2);
    return s;
  }
  K.glowSprite = glowSprite;

  function runeTexture(color) {
    var key = 'rune' + color;
    if (texCache[key]) return texCache[key];
    var c = document.createElement('canvas'); c.width = c.height = 1024;
    var x = c.getContext('2d'), r = rng(77);
    x.translate(512, 512);
    x.strokeStyle = color; x.lineCap = 'round';
    function ring(rad, w) { x.lineWidth = w; x.beginPath(); x.arc(0, 0, rad, 0, TAU); x.stroke(); }
    ring(500, 6); ring(470, 2); ring(360, 4); ring(330, 2); ring(150, 3);
    // glyph band
    for (var i = 0; i < 36; i++) {
      x.save(); x.rotate(i / 36 * TAU); x.translate(0, -415); x.lineWidth = 5;
      x.beginPath();
      var strokes = 2 + Math.floor(r() * 3);
      for (var s = 0; s < strokes; s++) {
        var ax = (r() - 0.5) * 34, ay = (r() - 0.5) * 40, bx = (r() - 0.5) * 34, by = (r() - 0.5) * 40;
        if (r() < 0.35) { x.moveTo(ax, ay); x.arc(ax, ay, 8 + r() * 8, 0, Math.PI * (0.6 + r())); }
        else { x.moveTo(ax, ay); x.lineTo(bx, by); }
      }
      x.stroke(); x.restore();
    }
    // star polygon
    x.lineWidth = 3; x.beginPath();
    for (var k = 0; k <= 7; k++) { var a = k * (TAU * 3 / 7) - Math.PI / 2; var px = Math.cos(a) * 330, py = Math.sin(a) * 330; if (k) x.lineTo(px, py); else x.moveTo(px, py); }
    x.stroke();
    for (var q = 0; q < 7; q++) { var b = q * TAU / 7 - Math.PI / 2; x.beginPath(); x.lineWidth = 3; x.arc(Math.cos(b) * 240, Math.sin(b) * 240, 26, 0, TAU); x.stroke(); }
    var t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; t.anisotropy = 4;
    texCache[key] = t;
    return t;
  }
  function runeDisc(radius, color, opacity) {
    var m = new T.Mesh(new T.PlaneGeometry(radius * 2, radius * 2), new T.MeshBasicMaterial({
      map: runeTexture(color || '#e8c872'), transparent: true, opacity: opacity == null ? 0.9 : opacity,
      blending: T.AdditiveBlending, depthWrite: false, toneMapped: false, side: T.DoubleSide
    }));
    m.rotation.x = -Math.PI / 2;
    return m;
  }
  K.runeDisc = runeDisc;

  /* ------------------------------------------------------------------- stage */
  function Stage(canvas, o) {
    o = o || {};
    var renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = T.SRGBColorSpace;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = o.exposure || 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = T.PCFSoftShadowMap;
    var scene = new T.Scene();
    scene.background = new T.Color(o.bg || 0x120f24);
    scene.fog = new T.FogExp2(o.fog || 0x2a2148, o.fogDensity || 0.0085);
    var camera = new T.PerspectiveCamera(o.fov || 42, 1, 0.1, 3000);
    var updaters = [], raf = 0, alive = true, last = performance.now(), start = last;
    var host = canvas.parentElement || canvas;
    function resize() {
      var w = host.clientWidth || 960, h = host.clientHeight || 600;
      renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
    }
    var ro = (typeof ResizeObserver !== 'undefined') ? new ResizeObserver(resize) : null;
    if (ro) ro.observe(host); else window.addEventListener('resize', resize);
    resize();
    function frame(now) {
      if (!alive) return;
      raf = requestAnimationFrame(frame);
      var dt = Math.min((now - last) / 1000, 0.05); last = now;
      var t = (now - start) / 1000;
      for (var i = 0; i < updaters.length; i++) updaters[i](t, dt);
      renderer.render(scene, camera);
    }
    raf = requestAnimationFrame(frame);
    var st = {
      renderer: renderer, scene: scene, camera: camera, canvas: canvas,
      add: function (fn) { updaters.push(fn); return fn; },
      remove: function (fn) { var i = updaters.indexOf(fn); if (i >= 0) updaters.splice(i, 1); },
      dispose: function () {
        alive = false; cancelAnimationFrame(raf);
        if (ro) ro.disconnect(); else window.removeEventListener('resize', resize);
        scene.traverse(function (ob) {
          if (ob.geometry) ob.geometry.dispose();
          if (ob.material) {
            (Array.isArray(ob.material) ? ob.material : [ob.material]).forEach(function (m) { m.dispose(); });
          }
        });
        renderer.dispose();
      }
    };
    return st;
  }
  K.Stage = Stage;

  /* -------------------------------------------------------------------- sky */
  var shaderTail = '\n#include <tonemapping_fragment>\n#include <colorspace_fragment>\n';
  function sky(stage, o) {
    o = o || {};
    var moonDir = (o.moonDir || new T.Vector3(-0.5, 0.42, -0.75)).clone().normalize();
    var mat = new T.ShaderMaterial({
      side: T.BackSide, depthWrite: false, fog: false,
      uniforms: {
        top: { value: new T.Color(o.top || 0x070a1c) },
        mid: { value: new T.Color(o.mid || 0x23194a) },
        horizon: { value: new T.Color(o.horizon || 0xc0708a) },
        glow: { value: new T.Color(o.glow || 0xffe2b0) },
        moonDir: { value: moonDir }
      },
      vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: [
        'uniform vec3 top; uniform vec3 mid; uniform vec3 horizon; uniform vec3 glow; uniform vec3 moonDir;',
        'varying vec3 vP;',
        'void main(){',
        '  float h = vP.y;',
        '  vec3 c = mix(horizon, mid, smoothstep(-0.02, 0.28, h));',
        '  c = mix(c, top, smoothstep(0.25, 0.95, h));',
        '  c = mix(c, mid*0.55, smoothstep(0.0, -0.5, h));',
        '  float m = max(dot(normalize(vP), moonDir), 0.0);',
        '  c += glow * (pow(m, 60.0) * 0.5 + pow(m, 6.0) * 0.12);',
        '  gl_FragColor = vec4(c, 1.0);',
        shaderTail, '}'
      ].join('\n')
    });
    var dome = new T.Mesh(new T.SphereGeometry(1400, 48, 24), mat);
    dome.renderOrder = -10;
    stage.scene.add(dome);

    // stars
    var N = o.stars || 2600, pos = new Float32Array(N * 3), sz = new Float32Array(N), ph = new Float32Array(N), r = rng(9);
    for (var i = 0; i < N; i++) {
      var u = r() * 2 - 1, a = r() * TAU;
      var y = Math.abs(u) * 0.95 + 0.04; if (r() < 0.12) y = -y * 0.3;
      var rad = Math.sqrt(1 - y * y);
      pos[i * 3] = Math.cos(a) * rad * 1300; pos[i * 3 + 1] = y * 1300; pos[i * 3 + 2] = Math.sin(a) * rad * 1300;
      sz[i] = 1.2 + Math.pow(r(), 6) * 7; ph[i] = r() * 50;
    }
    var sg = new T.BufferGeometry();
    sg.setAttribute('position', new T.BufferAttribute(pos, 3));
    sg.setAttribute('size', new T.BufferAttribute(sz, 1));
    sg.setAttribute('phase', new T.BufferAttribute(ph, 1));
    var smat = new T.ShaderMaterial({
      transparent: true, depthWrite: false, blending: T.AdditiveBlending, fog: false,
      uniforms: { time: { value: 0 }, pr: { value: stage.renderer.getPixelRatio() } },
      vertexShader: 'attribute float size; attribute float phase; uniform float time; uniform float pr; varying float vA; void main(){ vA = 0.55 + 0.45*sin(time*1.7 + phase); vec4 mv = modelViewMatrix*vec4(position,1.0); gl_PointSize = size*pr; gl_Position = projectionMatrix*mv; }',
      fragmentShader: 'varying float vA; void main(){ float d = length(gl_PointCoord-0.5); float a = smoothstep(0.5, 0.0, d); gl_FragColor = vec4(vec3(1.0,0.93,0.82)*a*vA, a*vA); }'
    });
    var stars = new T.Points(sg, smat); stars.renderOrder = -9;
    stage.scene.add(stars);

    // aurora ribbons
    var aur = new T.Group();
    var amat = new T.ShaderMaterial({
      transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide, fog: false,
      uniforms: { time: { value: 0 }, c1: { value: new T.Color(o.aurora1 || 0x45f0c0) }, c2: { value: new T.Color(o.aurora2 || 0x9a6bff) }, strength: { value: o.auroraStrength == null ? 0.55 : o.auroraStrength } },
      vertexShader: 'varying vec2 vUv; uniform float time; void main(){ vUv = uv; vec3 p = position; p.y += sin(uv.x*9.0 + time*0.35)*18.0; p.z += sin(uv.x*5.0 - time*0.2)*30.0; gl_Position = projectionMatrix*modelViewMatrix*vec4(p,1.0); }',
      fragmentShader: [
        'varying vec2 vUv; uniform float time; uniform vec3 c1; uniform vec3 c2; uniform float strength;',
        'void main(){',
        '  float bands = 0.5 + 0.5*sin(vUv.x*80.0 + sin(vUv.x*13.0 + time*0.6)*4.0);',
        '  bands = pow(bands, 3.0);',
        '  float v = smoothstep(0.0, 0.25, vUv.y) * smoothstep(1.0, 0.35, vUv.y);',
        '  float edge = smoothstep(0.0, 0.12, vUv.x) * smoothstep(1.0, 0.88, vUv.x);',
        '  vec3 col = mix(c1, c2, vUv.y);',
        '  float a = v*edge*(0.35 + 0.65*bands)*strength;',
        '  gl_FragColor = vec4(col*a, a);',
        shaderTail, '}'
      ].join('\n')
    });
    for (var k = 0; k < 3; k++) {
      var pg = new T.PlaneGeometry(900, 180, 160, 1);
      var pa = pg.attributes.position;
      for (var v = 0; v < pa.count; v++) {
        var px = pa.getX(v), ang = px / 900 * 1.6;
        pa.setXYZ(v, Math.sin(ang) * 800, pa.getY(v), -Math.cos(ang) * 800);
      }
      pg.computeVertexNormals();
      var ribbon = new T.Mesh(pg, amat);
      ribbon.position.y = 260 + k * 70;
      ribbon.rotation.y = -0.6 + k * 0.7;
      ribbon.renderOrder = -8;
      aur.add(ribbon);
    }
    stage.scene.add(aur);

    // moon
    var moon = new T.Group();
    var disc = new T.Sprite(new T.SpriteMaterial({ map: glowTexture('rgba(255,246,222,1)', 'rgba(255,230,190,0)', 'moon'), transparent: true, depthWrite: false, fog: false, toneMapped: false }));
    disc.scale.setScalar(90);
    var halo = glowSprite(0xffd9a0, 420, 0.35); halo.material.fog = false;
    moon.add(halo); moon.add(disc);
    moon.position.copy(moonDir).multiplyScalar(1100);
    stage.scene.add(moon);

    stage.add(function (t) { smat.uniforms.time.value = t; amat.uniforms.time.value = t; });
    return { dome: dome, stars: stars, aurora: aur, moon: moon, moonDir: moonDir, auroraMat: amat };
  }
  K.sky = sky;

  function cloudSea(stage, o) {
    o = o || {};
    var mat = new T.ShaderMaterial({
      transparent: true, depthWrite: false, fog: false,
      uniforms: { time: { value: 0 }, lit: { value: new T.Color(o.lit || 0xd9b6d8) }, shade: { value: new T.Color(o.shade || 0x2b2350) }, moonDir: { value: (o.moonDir || new T.Vector3(-0.5, 0.42, -0.75)).clone().normalize() } },
      vertexShader: 'varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }',
      fragmentShader: [
        'varying vec2 vUv; varying vec3 vW; uniform float time; uniform vec3 lit; uniform vec3 shade; uniform vec3 moonDir;',
        'float h(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }',
        'float n(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h(i),h(i+vec2(1,0)),f.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x), f.y); }',
        'float fbm(vec2 p){ float s=0.0, a=0.5; for(int i=0;i<5;i++){ s+=a*n(p); p*=2.03; a*=0.5; } return s; }',
        'void main(){',
        '  vec2 p = vW.xz*0.012 + vec2(time*0.012, time*0.006);',
        '  float c = fbm(p + fbm(p*1.7 - time*0.01));',
        '  float d = length(vW.xz);',
        '  float fade = smoothstep(900.0, 250.0, d);',
        '  vec2 md = normalize(moonDir.xz);',
        '  float side = 0.5 + 0.5*dot(normalize(vW.xz + 0.0001), md);',
        '  vec3 col = mix(shade, lit, smoothstep(0.35, 0.8, c) * (0.45 + 0.55*side));',
        '  float a = smoothstep(0.28, 0.6, c) * fade;',
        '  gl_FragColor = vec4(col, a);',
        shaderTail, '}'
      ].join('\n')
    });
    var plane = new T.Mesh(new T.PlaneGeometry(2000, 2000, 1, 1), mat);
    plane.rotation.x = -Math.PI / 2;
    plane.position.y = o.y == null ? -40 : o.y;
    plane.renderOrder = -5;
    stage.scene.add(plane);
    stage.add(function (t) { mat.uniforms.time.value = t; });
    return plane;
  }
  K.cloudSea = cloudSea;

  function lights(stage, o) {
    o = o || {};
    var hemi = new T.HemisphereLight(o.sky || 0x9d8cff, o.ground || 0x2b1d3a, o.hemi || 0.9);
    stage.scene.add(hemi);
    var moonL = new T.DirectionalLight(o.moon || 0xffe7c4, o.moonI || 2.2);
    var md = (o.moonDir || new T.Vector3(-0.5, 0.42, -0.75)).clone().normalize();
    moonL.position.copy(md).multiplyScalar(80);
    moonL.castShadow = true;
    moonL.shadow.mapSize.set(2048, 2048);
    var sc = moonL.shadow.camera; sc.left = -45; sc.right = 45; sc.top = 45; sc.bottom = -45; sc.near = 1; sc.far = 220;
    moonL.shadow.bias = -0.0008; moonL.shadow.normalBias = 0.04;
    stage.scene.add(moonL);
    var rim = new T.DirectionalLight(o.rim || 0x6fe7ff, o.rimI || 0.8);
    rim.position.set(40, 10, 50);
    stage.scene.add(rim);
    return { hemi: hemi, moon: moonL, rim: rim };
  }
  K.lights = lights;

  /* ------------------------------------------------------------------ motes */
  function motes(stage, o) {
    o = o || {};
    var N = o.count || 300, box = o.box || 40, pos = new Float32Array(N * 3), seed = new Float32Array(N), r = rng(o.seed || 3);
    for (var i = 0; i < N; i++) {
      pos[i * 3] = (r() - 0.5) * box; pos[i * 3 + 1] = r() * (o.h || 20) + (o.y || 0); pos[i * 3 + 2] = (r() - 0.5) * box;
      seed[i] = r() * 100;
    }
    var g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(pos, 3));
    g.setAttribute('seed', new T.BufferAttribute(seed, 1));
    var mat = new T.ShaderMaterial({
      transparent: true, depthWrite: false, blending: T.AdditiveBlending,
      uniforms: { time: { value: 0 }, color: { value: new T.Color(o.color || 0xffe08a) }, h: { value: o.h || 20 }, pr: { value: stage.renderer.getPixelRatio() }, size: { value: o.size || 7 } },
      vertexShader: 'attribute float seed; uniform float time; uniform float h; uniform float pr; uniform float size; varying float vA; void main(){ vec3 p = position; p.y = position.y + mod(time*0.6 + seed, h) - h*0.5; p.x += sin(time*0.7 + seed)*0.8; p.z += cos(time*0.5 + seed*1.3)*0.8; vA = 0.5+0.5*sin(time*3.0+seed*7.0); vec4 mv = modelViewMatrix*vec4(p,1.0); gl_PointSize = size*pr*(30.0/-mv.z); gl_Position = projectionMatrix*mv; }',
      fragmentShader: 'uniform vec3 color; varying float vA; void main(){ float d = length(gl_PointCoord-0.5); float a = smoothstep(0.5,0.0,d)*vA; gl_FragColor = vec4(color*a, a);\n#include <colorspace_fragment>\n}'
    });
    var pts = new T.Points(g, mat);
    pts.frustumCulled = false;
    stage.scene.add(pts);
    stage.add(function (t) { mat.uniforms.time.value = t; });
    return pts;
  }
  K.motes = motes;

  /* ------------------------------------------------------------------- isle */
  function isle(o) {
    o = o || {};
    var R = o.radius || 16, seed = o.seed || 7, noise = makeNoise(seed), noise2 = makeNoise(seed + 101);
    var rings = o.rings || 30, segs = o.segs || 84, under = o.under || 16, depth = o.depth || R * 1.15;
    var hills = o.hills == null ? 3.2 : o.hills;
    var lake = o.lake ? { x: Math.cos(o.lakeAngle || 0.6) * R * 0.42, z: Math.sin(o.lakeAngle || 0.6) * R * 0.42, r: R * (o.lakeSize || 0.27) } : null;
    var grassA = new T.Color(o.grass || 0x3f7d55), grassB = new T.Color(o.grass2 || 0x8ab86a), soil = new T.Color(0x6a4b3a), sand = new T.Color(0xc9b48a);
    var rockA = new T.Color(o.rock || 0x5a4e6e), rockB = new T.Color(o.rock2 || 0x2c2440), vein = new T.Color(o.vein || 0x45e0c0);

    function edgeK(a) { return 1 + 0.2 * (noise(Math.cos(a) * 1.3 + 7, Math.sin(a) * 1.3 + 7, 3) - 0.5) * 2; }
    function heightAt(x, z) {
      var d = Math.sqrt(x * x + z * z), a = Math.atan2(z, x), rr = d / (R * edgeK(a));
      var h = (noise(x * 0.07 + 3, z * 0.07 + 3, 4) - 0.42) * hills * 2;
      h += Math.max(0, noise(x * 0.03 + 9, z * 0.03 + 9, 2) - 0.5) * hills * 3;
      h *= 1 - Math.pow(clamp(rr, 0, 1), 3);
      if (lake) {
        var ld = Math.hypot(x - lake.x, z - lake.z) / lake.r;
        if (ld < 1.35) { var k = clamp((ld - 0.7) / 0.65, 0, 1); h = lerp(-1.6 + ld * 0.6, h, k * k); }
      }
      return h;
    }
    var pos = [], col = [], idx = [];
    var tmp = new T.Color();
    var ringsTotal = rings + under;
    for (var r = 0; r <= ringsTotal; r++) {
      for (var s = 0; s < segs; s++) {
        var a = s / segs * TAU, ek = edgeK(a), x, y, z;
        if (r <= rings) {
          var rr = r / rings;
          x = Math.cos(a) * rr * R * ek; z = Math.sin(a) * rr * R * ek;
          y = heightAt(x, z);
          var gn = noise2(x * 0.15, z * 0.15, 3);
          tmp.copy(grassA).lerp(grassB, clamp(gn * 1.4 - 0.2 + y * 0.06, 0, 1));
          if (rr > 0.94) tmp.lerp(soil, (rr - 0.94) / 0.06);
          if (lake && Math.hypot(x - lake.x, z - lake.z) < lake.r * 1.12) tmp.copy(sand).lerp(soil, clamp(-y * 0.4, 0, 1));
        } else {
          var k = (r - rings) / under;
          var f = Math.pow(1 - k, 1.25) * (0.95 + 0.1 * noise2(a * 3, k * 6, 2));
          var jag = 1 + (noise(Math.cos(a) * 4 + k * 3, Math.sin(a) * 4 - k * 3, 3) - 0.5) * 0.55 * Math.sin(k * Math.PI);
          x = Math.cos(a) * R * ek * f * jag; z = Math.sin(a) * R * ek * f * jag;
          y = -depth * Math.pow(k, 0.85) - 0.4 + (noise(a * 2, k * 4, 2) - 0.5) * 2;
          var band = 0.5 + 0.5 * Math.sin(y * 1.3 + noise(a * 3, 0, 2) * 4);
          tmp.copy(rockA).lerp(rockB, clamp(k * 0.9 + band * 0.25, 0, 1));
          if (noise2(a * 5 + 20, y * 0.4, 2) > 0.66) tmp.lerp(vein, 0.75);
        }
        pos.push(x, y, z); col.push(tmp.r, tmp.g, tmp.b);
      }
    }
    for (r = 0; r < ringsTotal; r++) {
      for (s = 0; s < segs; s++) {
        var s2 = (s + 1) % segs;
        var i0 = r * segs + s, i1 = r * segs + s2, i2 = (r + 1) * segs + s, i3 = (r + 1) * segs + s2;
        idx.push(i0, i2, i1, i1, i2, i3);
      }
    }
    var geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new T.Float32BufferAttribute(col, 3));
    geo.setIndex(idx);
    geo = geo.toNonIndexed();
    geo.computeVertexNormals();
    var group = new T.Group();
    var land = new T.Mesh(geo, new T.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.92, metalness: 0 }));
    land.castShadow = true; land.receiveShadow = true;
    group.add(land);

    var out = { group: group, land: land, radius: R, heightAt: heightAt, lake: lake, depth: depth, updaters: [] };

    if (lake) {
      var wmat = new T.ShaderMaterial({
        transparent: true,
        uniforms: { time: { value: 0 }, deep: { value: new T.Color(0x123a5c) }, shallow: { value: new T.Color(0x3fc6c0) }, glint: { value: new T.Color(0xfff1c8) } },
        vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
        fragmentShader: [
          'varying vec2 vUv; uniform float time; uniform vec3 deep; uniform vec3 shallow; uniform vec3 glint;',
          'void main(){ vec2 p = vUv-0.5; float d = length(p)*2.0;',
          ' float w = sin(p.x*40.0 + time*1.3)*sin(p.y*36.0 - time*1.1);',
          ' vec3 c = mix(deep, shallow, smoothstep(0.2, 1.0, d) + w*0.05);',
          ' c += glint*smoothstep(0.85, 1.0, w)*0.5;',
          ' float a = smoothstep(1.0, 0.92, d)*0.9;',
          ' gl_FragColor = vec4(c, a);', shaderTail, '}'
        ].join('\n')
      });
      var water = new T.Mesh(new T.CircleGeometry(lake.r * 1.08, 48), wmat);
      water.rotation.x = -Math.PI / 2;
      water.position.set(lake.x, -0.55, lake.z);
      water.receiveShadow = true;
      group.add(water);
      out.water = water;
      out.updaters.push(function (t) { wmat.uniforms.time.value = t; });

      // waterfall where the lake points at the rim
      var la = Math.atan2(lake.z, lake.x), rimR = R * edgeK(la) * 0.985;
      var fall = waterfall(depth * 1.4, lake.r * 0.4);
      fall.obj.position.set(Math.cos(la) * rimR, -0.6, Math.sin(la) * rimR);
      fall.obj.rotation.y = -la + Math.PI / 2;
      group.add(fall.obj);
      out.updaters.push(fall.update);
    }
    out.update = function (t) { for (var i = 0; i < out.updaters.length; i++) out.updaters[i](t); };
    out.surface = function (x, z) { return new T.Vector3(x, heightAt(x, z), z); };
    return out;
  }
  K.isle = isle;

  function waterfall(h, w) {
    var mat = new T.ShaderMaterial({
      transparent: true, depthWrite: false, side: T.DoubleSide,
      uniforms: { time: { value: 0 }, c: { value: new T.Color(0xbff6ff) } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: [
        'varying vec2 vUv; uniform float time; uniform vec3 c;',
        'float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)))*43758.5453); }',
        'void main(){ float col = floor(vUv.x*26.0); float sp = 0.6 + h(vec2(col,1.0))*0.8;',
        ' float s = fract(vUv.y*3.0 + time*sp + h(vec2(col,2.0)));',
        ' float streak = smoothstep(0.0, 0.5, s)*smoothstep(1.0, 0.6, s);',
        ' float edge = smoothstep(0.0, 0.2, vUv.x)*smoothstep(1.0, 0.8, vUv.x);',
        ' float fade = smoothstep(0.0, 0.5, vUv.y);',
        ' float a = (0.25 + 0.6*streak)*edge*fade;',
        ' gl_FragColor = vec4(c, a);', shaderTail, '}'
      ].join('\n')
    });
    var g = new T.PlaneGeometry(w, h, 1, 12);
    g.translate(0, -h / 2, 0);
    var pa = g.attributes.position;
    for (var i = 0; i < pa.count; i++) { var y = pa.getY(i), k = Math.min(1, Math.max(0, -y / h)); pa.setZ(i, Math.pow(k, 0.5) * 2.4); pa.setX(i, pa.getX(i) * (1 + k * 0.8)); }
    var m = new T.Mesh(g, mat);
    var grp = new T.Group(); grp.add(m);
    var mist = glowSprite(0xcfefff, w * 4, 0.25); mist.position.set(0, -h * 0.95, 2.4); grp.add(mist);
    return { obj: grp, update: function (t) { mat.uniforms.time.value = t; } };
  }

  /* ------------------------------------------------------------- flora/rock */
  function pine(r, s) {
    var g = new T.Group(), c = [0x1f5a4a, 0x2b6d52, 0x16463f][Math.floor(r() * 3)];
    var trunk = mesh(new T.CylinderGeometry(0.12, 0.18, 0.8, 5), M(0x4a3428), 0, 0.4, 0); g.add(trunk);
    for (var i = 0; i < 3; i++) { var cn = mesh(new T.ConeGeometry(1.0 - i * 0.25, 1.4, 6), M(c), 0, 1.0 + i * 0.75, 0); cn.rotation.y = r() * 3; g.add(cn); }
    g.scale.setScalar(s); return g;
  }
  function bloomTree(r, s) {
    var g = new T.Group();
    var cols = [0xff9ec7, 0xc79bff, 0xffd27a, 0x8ff0d0];
    var trunk = mesh(new T.CylinderGeometry(0.14, 0.24, 1.6, 5), M(0x5a3a30), 0, 0.8, 0); trunk.rotation.z = (r() - 0.5) * 0.3; g.add(trunk);
    var c = cols[Math.floor(r() * cols.length)];
    for (var i = 0; i < 4; i++) {
      var b = mesh(new T.IcosahedronGeometry(0.7 + r() * 0.4, 0), M(c, { e: c, ei: 0.12 }), (r() - 0.5) * 1.1, 1.9 + r() * 0.7, (r() - 0.5) * 1.1);
      g.add(b);
    }
    g.scale.setScalar(s); return g;
  }
  function crystal(color, s) {
    var g = new T.Group();
    var m = M(color, { e: color, ei: 0.9, r: 0.2, m: 0.1, t: true, o: 0.92 });
    for (var i = 0; i < 4; i++) {
      var c = mesh(new T.OctahedronGeometry(0.4, 0), m);
      c.scale.set(0.6, 1.8 + i * 0.5, 0.6);
      c.position.set(Math.cos(i * 2.1) * 0.35 * (i ? 1 : 0), 0.6 + i * 0.1, Math.sin(i * 2.1) * 0.35 * (i ? 1 : 0));
      c.rotation.set((i ? 0.4 : 0) * Math.cos(i), i, (i ? 0.4 : 0) * Math.sin(i));
      g.add(c);
    }
    g.scale.setScalar(s || 1);
    return g;
  }
  K.crystal = crystal;
  function rock(r, s) {
    var m = mesh(new T.DodecahedronGeometry(0.6, 0), M(0x7a7088));
    m.scale.set(s * (0.8 + r() * 0.6), s * (0.5 + r() * 0.5), s * (0.8 + r() * 0.6));
    m.rotation.set(r() * 3, r() * 3, r() * 3);
    return m;
  }
  function dressIsle(I, o) {
    o = o || {};
    var r = rng(o.seed || 11), R = I.radius, n = o.trees == null ? 60 : o.trees, avoid = o.avoid || [];
    function free(x, z, pad) {
      if (I.lake && Math.hypot(x - I.lake.x, z - I.lake.z) < I.lake.r * 1.25 + pad) return false;
      for (var i = 0; i < avoid.length; i++) if (Math.hypot(x - avoid[i].x, z - avoid[i].z) < (avoid[i].r || 2.5) + pad) return false;
      return true;
    }
    for (var i = 0; i < n; i++) {
      var a = r() * TAU, d = Math.sqrt(r()) * R * 0.86, x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (!free(x, z, 0.6)) continue;
      var t = r() < 0.65 ? pine(r, 0.6 + r() * 0.7) : bloomTree(r, 0.6 + r() * 0.5);
      t.position.set(x, I.heightAt(x, z) - 0.05, z); t.rotation.y = r() * TAU;
      I.group.add(t);
    }
    for (i = 0; i < (o.rocks == null ? 20 : o.rocks); i++) {
      a = r() * TAU; d = Math.sqrt(r()) * R * 0.9; x = Math.cos(a) * d; z = Math.sin(a) * d;
      if (!free(x, z, 0)) continue;
      var rk = rock(r, 0.5 + r() * 1.1); rk.position.set(x, I.heightAt(x, z), z); I.group.add(rk);
    }
    // crystals jutting from the underside
    for (i = 0; i < (o.crystals == null ? 8 : o.crystals); i++) {
      a = r() * TAU; var k = 0.25 + r() * 0.5;
      var cr = crystal(o.crystalColor || K.C.verdigris, 0.8 + r() * 1.2);
      cr.position.set(Math.cos(a) * R * (1 - k) * 0.95, -I.depth * k, Math.sin(a) * R * (1 - k) * 0.95);
      cr.rotation.set(Math.PI + (r() - 0.5), 0, (r() - 0.5));
      I.group.add(cr);
    }
    // hanging roots
    var rootM = M(0x4b3a3a);
    for (i = 0; i < 14; i++) {
      a = r() * TAU; var len = 3 + r() * 6;
      var root = mesh(new T.CylinderGeometry(0.03, 0.12, len, 4), rootM);
      var rr2 = R * (0.55 + r() * 0.35);
      root.position.set(Math.cos(a) * rr2, -I.depth * 0.25 - len / 2, Math.sin(a) * rr2);
      root.rotation.z = (r() - 0.5) * 0.3;
      I.group.add(root);
    }
  }
  K.dressIsle = dressIsle;

  function cloudPuff(r, s, color) {
    var g = new T.Group(), m = M(color || 0xe8dcff, { r: 1, e: 0x4a3a7a, ei: 0.35 });
    var n = 4 + Math.floor(r() * 4);
    for (var i = 0; i < n; i++) {
      var p = mesh(new T.IcosahedronGeometry(1 + r() * 1.2, 1), m, (i - n / 2) * 1.2 + r(), r() * 0.8, (r() - 0.5) * 1.6);
      p.castShadow = false;
      p.scale.y = 0.7; g.add(p);
    }
    g.scale.setScalar(s);
    return g;
  }
  K.cloudPuff = cloudPuff;

  /* ---------------------------------------------------------------- beasts */
  function wingFeather(len) {
    var sh = new T.Shape();
    sh.moveTo(0, 0.35); sh.lineTo(len * 0.35, 0.75); sh.lineTo(len * 0.75, 0.85); sh.lineTo(len, 0.6);
    var n = 7;
    for (var i = 0; i <= n; i++) {
      var k = i / n, x = lerp(len, 0.2, k);
      sh.lineTo(x + 0.12, -0.5 - Math.sin(k * Math.PI) * 0.9 + 0.1);
      sh.lineTo(x - len / n * 0.5, -0.25 - Math.sin(k * Math.PI) * 0.6);
    }
    sh.lineTo(0, -0.4); sh.lineTo(0, 0.35);
    var g = new T.ShapeGeometry(sh, 4); g.rotateX(Math.PI / 2);
    return g;
  }
  function wingBat(len) {
    var s = len / 4.6, sh = new T.Shape();
    sh.moveTo(0, 0.4 * s); sh.lineTo(1.6 * s, 1.2 * s); sh.lineTo(3.4 * s, 1.6 * s); sh.lineTo(4.6 * s, 0.9 * s);
    sh.quadraticCurveTo(3.7 * s, 0.1 * s, 3.9 * s, -0.9 * s);
    sh.quadraticCurveTo(3.0 * s, -0.3 * s, 2.6 * s, -1.4 * s);
    sh.quadraticCurveTo(1.9 * s, -0.6 * s, 1.3 * s, -1.5 * s);
    sh.quadraticCurveTo(0.8 * s, -0.6 * s, 0, -0.9 * s);
    sh.lineTo(0, 0.4 * s);
    var g = new T.ShapeGeometry(sh, 6); g.rotateX(Math.PI / 2);
    return g;
  }
  function wingMoth(len) {
    var sh = new T.Shape();
    sh.moveTo(0, 0.2); sh.bezierCurveTo(len * 0.4, len * 0.9, len * 1.0, len * 0.7, len * 0.95, len * 0.1);
    sh.bezierCurveTo(len * 0.9, -len * 0.3, len * 0.5, -len * 0.2, 0, -0.2);
    var g = new T.ShapeGeometry(sh, 10); g.rotateX(Math.PI / 2);
    return g;
  }
  function wingPair(geo, mat, x, y, z) {
    var R = new T.Group(), L = new T.Group();
    var wr = new T.Mesh(geo, mat), wl = new T.Mesh(geo, mat);
    wr.castShadow = wl.castShadow = true;
    wl.scale.x = -1;
    R.add(wr); L.add(wl);
    R.position.set(x, y, z); L.position.set(-x, y, z);
    return { R: R, L: L, flap: function (a) { R.rotation.z = a; L.rotation.z = -a; } };
  }
  function eyes(group, color, sep, y, z, r) {
    var m = G(color);
    [-1, 1].forEach(function (s) { var e = new T.Mesh(new T.SphereGeometry(r || 0.07, 8, 6), m); e.position.set(sep * s, y, z); group.add(e); });
  }

  function dragon(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var mb = M(o.color || 0xc9963a, { r: 0.5, m: 0.35 }), mbel = M(o.belly || 0xf1d9a0), mw = M(o.wing || 0x8a2f3a, { ds: true, r: 0.85, e: o.wing || 0x8a2f3a, ei: 0.12 });
    var pts = [];
    for (var i = 0; i <= 10; i++) { var t = i / 10; pts.push(new T.Vector2(Math.max(0.06, Math.sin(t * Math.PI) * 0.95 * (1 - 0.3 * t)), (t - 0.5) * 3.6)); }
    var tg = new T.LatheGeometry(pts, 7); tg.rotateX(Math.PI / 2);
    var torso = mesh(tg, mb); torso.scale.set(1, 0.85, 1); body.add(torso);
    var bel = mesh(new T.SphereGeometry(0.8, 7, 5), mbel, 0, -0.32, 0); bel.scale.set(0.85, 0.5, 2.0); body.add(bel);
    var neck = chain(6, 0.42, 0.28, mb); body.add(neck.group);
    var head = new T.Group(); body.add(head);
    var skull = mesh(new T.ConeGeometry(0.42, 1.3, 6), mb, 0, 0, 0.5); skull.rotation.x = Math.PI / 2; head.add(skull);
    var brow = mesh(new T.IcosahedronGeometry(0.4, 0), mb, 0, 0.08, 0); brow.scale.set(1.1, 0.8, 1); head.add(brow);
    var jaw = mesh(new T.ConeGeometry(0.28, 1.05, 5), mbel, 0, -0.22, 0.45); jaw.rotation.x = Math.PI / 2; head.add(jaw);
    var hornM = M(o.horn || 0xf3e6c4, { r: 0.4 });
    [-1, 1].forEach(function (s) {
      var h = mesh(new T.ConeGeometry(0.09, 1.0, 5), hornM, 0.22 * s, 0.32, -0.15); h.rotation.set(-1.15, 0, 0.35 * s); head.add(h);
      var h2 = mesh(new T.ConeGeometry(0.05, 0.5, 4), hornM, 0.36 * s, 0.05, -0.1); h2.rotation.set(-1.3, 0, 0.9 * s); head.add(h2);
    });
    eyes(head, o.eye || 0xfff3a0, 0.25, 0.12, 0.33, 0.08);
    var spineM = M(o.wing || 0x8a2f3a);
    for (i = 0; i < 6; i++) { var sp = mesh(new T.ConeGeometry(0.1, 0.45, 4), spineM, 0, 0.78 - Math.abs(i - 2.5) * 0.05, 1.2 - i * 0.5); sp.rotation.x = -0.45; body.add(sp); }
    var tail = chain(11, 0.34, 0.06, mb); body.add(tail.group);
    var tip = mesh(new T.ConeGeometry(0.28, 0.6, 3), spineM); tip.scale.z = 0.3; tail.group.add(tip);
    var legG = new T.CylinderGeometry(0.11, 0.2, 0.9, 5);
    [[0.55, 0.9], [-0.55, 0.9], [0.55, -0.8], [-0.55, -0.8]].forEach(function (p) { var l = mesh(legG, mb, p[0], -0.75, p[1]); l.rotation.x = 0.55; body.add(l); });
    var w = wingPair(wingBat(o.span || 4.8), mw, 0.45, 0.45, 0.5); body.add(w.R); body.add(w.L);
    var boneM = mb;
    [w.R, w.L].forEach(function (pv, k) {
      var side = k ? -1 : 1, bg = new T.Group();
      var bone = mesh(new T.CylinderGeometry(0.05, 0.1, 3.7, 4), boneM); bone.rotation.z = Math.PI / 2; bg.add(bone);
      bg.position.set(1.75 * side, 0.02, 1.0 * (o.span || 4.8) / 4.6); bg.rotation.y = -0.34 * side;
      pv.add(bg);
    });
    var phase = (o.phase != null) ? o.phase : Math.random() * 10, rate = o.flap || 2.2;
    function update(t) {
      t += phase;
      var f = Math.sin(t * rate);
      w.flap(f * 0.6 + 0.12);
      body.position.y = -f * 0.18;
      for (var i = 0; i < neck.segs.length; i++) {
        var k = (i + 1) / neck.segs.length;
        neck.segs[i].position.set(Math.sin(t * 0.8 + k) * 0.08 * k, 0.3 + 1.15 * Math.sin(k * Math.PI / 2), 1.7 + 1.2 * k);
      }
      head.position.set(Math.sin(t * 0.8 + 1) * 0.1, 1.6, 3.15);
      head.rotation.x = 0.12 + Math.sin(t * 0.9) * 0.06;
      for (var j = 0; j < tail.segs.length; j++) {
        var q = (j + 1) / tail.segs.length;
        tail.segs[j].position.set(Math.sin(t * 1.5 - q * 3) * 0.55 * q, 0.1 - q * 0.45 + Math.sin(t * 1.1 - q * 2) * 0.15 * q, -1.7 - q * 3.5);
      }
      var lst = tail.segs[tail.segs.length - 1].position;
      tip.position.set(lst.x, lst.y, lst.z - 0.35); tip.rotation.set(-Math.PI / 2, 0, 0);
    }
    update(0);
    return { obj: g, update: update, flying: true };
  }

  function bird(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var mb = M(o.color || 0xd8c7a0, { r: 0.8 }), mf = M(o.feather || 0x6f7fb0, { ds: true, e: o.edge || 0x000000, ei: 0.25 }), mh = M(o.head || 0xf2efe6);
    var tb = mesh(new T.CapsuleGeometry(0.5, 1.3, 3, 7), mb); tb.rotation.x = Math.PI / 2; body.add(tb);
    var head = new T.Group(); head.position.set(0, 0.55, 1.15); body.add(head);
    var hs = mesh(new T.IcosahedronGeometry(0.42, 1), mh); head.add(hs);
    var beak = mesh(new T.ConeGeometry(0.15, 0.55, 4), M(o.beak || 0xe0a93a), 0, -0.06, 0.48); beak.rotation.x = Math.PI / 2 + 0.35; head.add(beak);
    eyes(head, o.eye || 0x9ff4ff, 0.2, 0.1, 0.3, 0.06);
    if (o.tufts) [-1, 1].forEach(function (s) { var tf = mesh(new T.ConeGeometry(0.1, 0.5, 4), mh, 0.22 * s, 0.42, -0.05); tf.rotation.z = -0.3 * s; head.add(tf); });
    var w = wingPair(wingFeather(o.span || 3.2), mf, 0.35, 0.25, 0.3); body.add(w.R); body.add(w.L);
    var fan = mesh(new T.ConeGeometry(0.55, 1.1, 5), mf, 0, 0.05, -1.3); fan.rotation.x = -Math.PI / 2; fan.scale.y = 1; fan.scale.x = 1.4; fan.scale.z = 0.2; body.add(fan);
    var tail = null;
    if (o.lionTail) { tail = chain(7, 0.12, 0.06, mb); body.add(tail.group); }
    var legM = M(o.leg || 0x8a6a40);
    [[0.25, 0.4], [-0.25, 0.4], [0.25, -0.5], [-0.25, -0.5]].forEach(function (p) { var l = mesh(new T.CylinderGeometry(0.06, 0.1, 0.6, 4), legM, p[0], -0.6, p[1]); body.add(l); });
    var phase = Math.random() * 10, rate = o.flap || 3.2;
    function update(t) {
      t += phase;
      var f = Math.sin(t * rate);
      w.flap(f * 0.7 + 0.1);
      body.position.y = -f * 0.15;
      head.rotation.y = Math.sin(t * 0.6) * 0.3;
      if (tail) for (var j = 0; j < tail.segs.length; j++) { var q = (j + 1) / tail.segs.length; tail.segs[j].position.set(Math.sin(t * 2 - q * 3) * 0.3 * q, -q * 0.5, -1.2 - q * 1.6); }
    }
    update(0);
    return { obj: g, update: update, flying: true };
  }

  function owl(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var mb = M(o.color || 0x3a2d5c, { t: true, o: 0.92, e: 0x6b4cff, ei: 0.12 }), mf = M(o.feather || 0x2a2148, { ds: true, t: true, o: 0.9, e: 0x6b4cff, ei: 0.18 });
    var b = mesh(new T.IcosahedronGeometry(0.9, 1), mb); b.scale.set(1, 1.15, 0.95); body.add(b);
    var face = mesh(new T.CircleGeometry(0.62, 12), M(0x5a4a86, { ds: true }), 0, 0.35, 0.82); body.add(face);
    var em = G(o.eye || 0xc9a0ff);
    [-1, 1].forEach(function (s) {
      var e = new T.Mesh(new T.CircleGeometry(0.2, 12), em); e.position.set(0.25 * s, 0.42, 0.86); body.add(e);
      var tf = mesh(new T.ConeGeometry(0.14, 0.6, 4), mb, 0.45 * s, 1.05, 0); tf.rotation.z = -0.35 * s; body.add(tf);
    });
    var beak = mesh(new T.ConeGeometry(0.08, 0.25, 4), M(0xd6b25a), 0, 0.25, 0.9); beak.rotation.x = Math.PI; body.add(beak);
    var w = wingPair(wingFeather(o.span || 2.8), mf, 0.6, 0.2, 0); body.add(w.R); body.add(w.L);
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      var f = Math.sin(t * 2.6);
      w.flap(f * 0.75);
      body.position.y = -f * 0.2;
      var s = 0.82 + 0.1 * Math.sin(t * 0.7);
      mb.opacity = s; mf.opacity = s;
    }
    update(0);
    return { obj: g, update: update, flying: true };
  }

  function serpent(o) {
    o = o || {};
    var g = new T.Group();
    var mb = M(o.color || 0x1f8a9a, { r: 0.4, m: 0.3 }), mfin = M(o.fin || 0xf2c766, { ds: true, e: o.fin || 0xf2c766, ei: 0.3 });
    var c = chain(18, 0.38, 0.07, mb, 1); g.add(c.group);
    var head = new T.Group(); g.add(head);
    var sk = mesh(new T.ConeGeometry(0.36, 1.0, 6), mb); sk.rotation.x = Math.PI / 2; head.add(sk);
    eyes(head, o.eye || 0xfff6a0, 0.2, 0.15, 0.05, 0.07);
    var frills = [];
    for (var i = 0; i < 5; i++) { var fr = mesh(new T.ConeGeometry(0.12, 0.7, 3), mfin, 0, 0.25, -0.2 - i * 0.12); fr.rotation.x = -0.8 - i * 0.12; head.add(fr); frills.push(fr); }
    var fins = [];
    for (i = 2; i < 14; i += 2) { var fn = mesh(new T.ConeGeometry(0.1, 0.5, 3), mfin); c.group.add(fn); fins.push({ m: fn, i: i }); }
    var phase = Math.random() * 10;
    function path(k, t) {
      return new T.Vector3(Math.sin(k * 7 - t * 1.4) * 1.1, Math.sin(k * 9 - t * 1.8) * 0.7 + 0.1, (0.5 - k) * 7);
    }
    function update(t) {
      t += phase;
      for (var i = 0; i < c.segs.length; i++) c.segs[i].position.copy(path(i / c.segs.length, t));
      var p0 = path(-0.06, t), p1 = path(0, t);
      head.position.copy(p0);
      head.lookAt(new T.Vector3().copy(p0).multiplyScalar(2).sub(p1).applyMatrix4(g.matrixWorld));
      for (var f = 0; f < fins.length; f++) { var fp = c.segs[fins[f].i].position; fins[f].m.position.set(fp.x, fp.y + 0.35, fp.z); }
      for (var q = 0; q < frills.length; q++) frills[q].rotation.z = Math.sin(t * 6 + q) * 0.15;
    }
    update(0);
    return { obj: g, update: update, water: true };
  }

  function kraken(o) {
    o = o || {};
    var g = new T.Group();
    var mb = M(o.color || 0x7a2e5e, { r: 0.45, m: 0.2 }), ms = M(o.sucker || 0xf0a0b8);
    var head = mesh(new T.IcosahedronGeometry(1.1, 1), mb, 0, 1.4, 0); head.scale.set(1, 1.35, 1); g.add(head);
    eyes(g, o.eye || 0xffd25a, 0.55, 1.0, 0.85, 0.16);
    var arms = [];
    for (var i = 0; i < 8; i++) { var a = chain(9, 0.3, 0.05, i % 2 ? mb : ms); g.add(a.group); arms.push(a); }
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      head.position.y = 1.4 + Math.sin(t * 1.2) * 0.15;
      for (var i = 0; i < arms.length; i++) {
        var ang = i / arms.length * TAU + Math.sin(t * 0.4) * 0.1;
        for (var j = 0; j < arms[i].segs.length; j++) {
          var k = (j + 1) / arms[i].segs.length;
          var rad = 0.7 + k * 2.6, curl = Math.sin(t * 1.6 + i * 0.9 + k * 2.5);
          arms[i].segs[j].position.set(Math.cos(ang) * rad, 0.4 + Math.sin(k * Math.PI) * 1.8 * (0.4 + 0.6 * curl) - k * 0.6, Math.sin(ang) * rad);
        }
      }
    }
    update(0);
    return { obj: g, update: update, water: true };
  }

  function wight(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var mc = M(o.color || 0x2d6f78, { t: true, o: 0.88, e: o.glow || 0x2fd0c0, ei: 0.22, ds: true });
    var cg = new T.ConeGeometry(0.95, 2.6, 9, 4, true), pa = cg.attributes.position, r = rng(5);
    for (var i = 0; i < pa.count; i++) { if (pa.getY(i) < -1.0) { pa.setY(i, pa.getY(i) - r() * 0.6); pa.setX(i, pa.getX(i) * (1 + r() * 0.2)); } }
    cg.computeVertexNormals();
    var cloak = mesh(cg, mc, 0, 1.2, 0); body.add(cloak);
    var hood = mesh(new T.IcosahedronGeometry(0.48, 1), mc, 0, 2.55, 0.05); body.add(hood);
    var face = new T.Mesh(new T.SphereGeometry(0.34, 10, 8), G(0x05070c)); face.position.set(0, 2.5, 0.22); body.add(face);
    eyes(body, o.eye || 0x8ffff0, 0.12, 2.55, 0.5, 0.06);
    var armM = mc;
    [-1, 1].forEach(function (s) { var a = mesh(new T.ConeGeometry(0.16, 1.3, 5), armM, 0.65 * s, 1.7, 0.3); a.rotation.set(-0.9, 0, -0.5 * s); body.add(a); });
    var wisps = [];
    for (i = 0; i < 5; i++) { var w = glowSprite(o.glow || 0x5ffff0, 0.6, 0.8); body.add(w); wisps.push(w); }
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      body.position.y = Math.sin(t * 1.3) * 0.25 + 0.2;
      body.rotation.y = Math.sin(t * 0.4) * 0.3;
      for (var i = 0; i < wisps.length; i++) { var a = t * 1.1 + i * 1.25; wisps[i].position.set(Math.cos(a) * 1.2, 0.6 + ((t * 0.6 + i * 0.4) % 2.4), Math.sin(a) * 1.2); }
    }
    update(0);
    return { obj: g, update: update };
  }

  function humanoid(o) {
    // ghoul archer, harpy-folk, etc.
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var ms = M(o.color || 0x9fb59a, { r: 0.9 }), mr = M(o.rag || 0x3d3a3f, { ds: true });
    var torso = mesh(new T.CapsuleGeometry(0.32, 0.8, 2, 6), ms, 0, 1.6, 0.1); torso.rotation.x = 0.45; body.add(torso);
    var rag = mesh(new T.ConeGeometry(0.55, 1.1, 6, 1, true), mr, 0, 1.15, 0); body.add(rag);
    var head = new T.Group(); head.position.set(0, 2.25, 0.5); body.add(head);
    var sk = mesh(new T.IcosahedronGeometry(0.3, 1), ms); sk.scale.set(0.9, 1.1, 1); head.add(sk);
    eyes(head, o.eye || 0xb6ff6a, 0.11, 0.05, 0.25, 0.06);
    var legM = ms;
    [-1, 1].forEach(function (s) { var l = mesh(new T.CylinderGeometry(0.08, 0.1, 1.1, 5), legM, 0.18 * s, 0.55, 0); l.rotation.x = -0.15; body.add(l); });
    var armL = new T.Group(), armR = new T.Group();
    armL.position.set(0.4, 1.95, 0.35); armR.position.set(-0.4, 1.95, 0.35);
    [armL, armR].forEach(function (a) { var am = mesh(new T.CylinderGeometry(0.06, 0.08, 1.3, 5), ms, 0, -0.6, 0); a.add(am); body.add(a); });
    armL.rotation.set(-1.3, 0, 0.1); armR.rotation.set(-1.1, 0, -0.3);
    var bow = mesh(new T.TorusGeometry(0.75, 0.04, 4, 14, Math.PI), M(o.bow || 0x6b4a2a), 0.25, 2.0, 1.35); bow.rotation.set(0, Math.PI / 2, Math.PI / 2); body.add(bow);
    var glow = glowSprite(o.eye || 0xb6ff6a, 0.9, 0.7); glow.position.set(0.25, 2.0, 1.45); body.add(glow);
    var quiver = mesh(new T.CylinderGeometry(0.12, 0.1, 0.8, 5), M(0x4a3020), -0.25, 1.9, -0.3); quiver.rotation.x = 0.5; body.add(quiver);
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      body.rotation.y = Math.sin(t * 0.5) * 0.25;
      head.rotation.z = Math.sin(t * 1.7) * 0.12;
      glow.material.opacity = 0.4 + 0.4 * Math.sin(t * 4);
      body.position.y = Math.abs(Math.sin(t * 1.4)) * 0.06;
    }
    update(0);
    return { obj: g, update: update };
  }

  function harpy(o) {
    var b = bird({ color: 0xc99a7a, feather: 0x8a2f2f, head: 0xe9c9b0, beak: 0x2a1f1f, eye: 0xffb36a, span: 2.8, flap: 4.2, edge: 0xff6a3d });
    return b;
  }

  function troll(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var ms = M(o.color || 0x6f7a8a, { r: 0.95 }), mm = M(0x5f8f4a);
    var torso = mesh(new T.IcosahedronGeometry(1.15, 1), ms, 0, 2.1, 0); torso.scale.set(1.15, 1.1, 0.9); body.add(torso);
    var belly = mesh(new T.IcosahedronGeometry(0.8, 0), M(0x8a8f96), 0, 1.6, 0.4); body.add(belly);
    var head = new T.Group(); head.position.set(0, 3.05, 0.65); body.add(head);
    var hs = mesh(new T.IcosahedronGeometry(0.48, 0), ms); hs.scale.set(1.1, 0.9, 1.1); head.add(hs);
    var nose = mesh(new T.ConeGeometry(0.14, 0.45, 4), ms, 0, -0.05, 0.45); nose.rotation.x = Math.PI / 2; head.add(nose);
    eyes(head, o.eye || 0xffb347, 0.2, 0.1, 0.38, 0.07);
    [-1, 1].forEach(function (s) { var tk = mesh(new T.ConeGeometry(0.06, 0.3, 4), M(0xf2ead6), 0.18 * s, -0.3, 0.35); head.add(tk); });
    var armR = new T.Group(), armL = new T.Group();
    armR.position.set(1.25, 2.6, 0); armL.position.set(-1.25, 2.6, 0);
    [armR, armL].forEach(function (a) { var up = mesh(new T.CapsuleGeometry(0.3, 1.3, 2, 6), ms, 0, -0.9, 0.1); a.add(up); var fist = mesh(new T.IcosahedronGeometry(0.42, 0), ms, 0, -1.8, 0.2); a.add(fist); body.add(a); });
    var club = new T.Group(); club.position.set(0, -1.85, 0.25); armR.add(club);
    var cs = mesh(new T.CylinderGeometry(0.32, 0.12, 2.2, 6), M(0x5a3e2a), 0, 0.4, 0.6); cs.rotation.x = 1.0; club.add(cs);
    for (var i = 0; i < 4; i++) { var sp = mesh(new T.ConeGeometry(0.07, 0.3, 4), M(0xcfc6b0), Math.cos(i * 1.6) * 0.3, 0.75 + i * 0.05, 1.3 + Math.sin(i * 1.6) * 0.3); club.add(sp); }
    [-1, 1].forEach(function (s) { var l = mesh(new T.CylinderGeometry(0.3, 0.36, 1.1, 6), ms, 0.5 * s, 0.55, 0); body.add(l); });
    [-1, 1].forEach(function (s) { for (var k = 0; k < 3; k++) { var m = mesh(new T.ConeGeometry(0.16, 0.5, 4), mm, 0.8 * s + (k - 1) * 0.18, 3.0, -0.2 + k * 0.1); body.add(m); } });
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      var br = 1 + Math.sin(t * 1.4) * 0.03;
      torso.scale.set(1.15 * br, 1.1 * br, 0.9 * br);
      armR.rotation.x = -0.25 + Math.sin(t * 0.9) * 0.18;
      armL.rotation.x = Math.sin(t * 0.9 + 1) * 0.15;
      head.rotation.y = Math.sin(t * 0.5) * 0.35;
      body.rotation.y = Math.sin(t * 0.3) * 0.2;
    }
    update(0);
    return { obj: g, update: update };
  }

  function treant(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var mb = M(o.bark || 0x5a3f2e, { r: 1 }), ml = M(o.leaf || 0x3f8a5a, { e: o.leafGlow || 0x173b2a, ei: 0.6 }), mbl = M(0xff9ec7, { e: 0xff6aa8, ei: 0.25 });
    var trunk = mesh(new T.CylinderGeometry(0.5, 0.85, 3.4, 7), mb, 0, 1.9, 0); body.add(trunk);
    eyes(body, o.eye || 0xffc04a, 0.22, 2.8, 0.5, 0.09);
    var mouth = new T.Mesh(new T.BoxGeometry(0.35, 0.06, 0.05), G(0xffa030)); mouth.position.set(0, 2.35, 0.55); body.add(mouth);
    var limbs = [];
    [[1, 2.9, 0.4], [-1, 3.0, -0.3], [1, 2.2, -0.9], [-1, 2.4, 0.8]].forEach(function (p, i) {
      var lg = new T.Group(); lg.position.set(0.4 * p[0], p[1], 0);
      var br = mesh(new T.ConeGeometry(0.18, 2.0, 5), mb, p[0] * 0.9, 0.5, 0); br.rotation.z = -1.0 * p[0]; br.rotation.y = p[2]; lg.add(br);
      body.add(lg); limbs.push(lg);
    });
    var canopy = new T.Group(); canopy.position.y = 4.0; body.add(canopy);
    var r = rng(o.seed || 21);
    for (var i = 0; i < 7; i++) { var c = mesh(new T.IcosahedronGeometry(0.8 + r() * 0.5, 0), r() < 0.25 ? mbl : ml, (r() - 0.5) * 2.2, r() * 1.2, (r() - 0.5) * 2.0); canopy.add(c); }
    for (i = 0; i < 5; i++) { var rt = mesh(new T.ConeGeometry(0.16, 1.2, 4), mb, Math.cos(i * 1.3) * 0.75, 0.25, Math.sin(i * 1.3) * 0.75); rt.rotation.z = Math.cos(i * 1.3) * 1.1; rt.rotation.x = -Math.sin(i * 1.3) * 1.1; body.add(rt); }
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      body.rotation.z = Math.sin(t * 0.7) * 0.04;
      canopy.rotation.y = Math.sin(t * 0.5) * 0.2;
      for (var i = 0; i < limbs.length; i++) limbs[i].rotation.x = Math.sin(t * 1.1 + i) * 0.15;
    }
    update(0);
    return { obj: g, update: update };
  }

  function sprite(o) {
    o = o || {};
    var g = new T.Group(), c = o.color || 0x9ff4ff;
    var core = new T.Mesh(new T.IcosahedronGeometry(0.45, 1), G(0xffffff)); g.add(core);
    var halo = glowSprite(c, 3.2, 0.9); g.add(halo);
    var N = 46, pos = new Float32Array(N * 3), gg = new T.BufferGeometry();
    gg.setAttribute('position', new T.BufferAttribute(pos, 3));
    var trail = new T.Points(gg, new T.PointsMaterial({ map: softDot(), color: c, size: 0.7, transparent: true, depthWrite: false, blending: T.AdditiveBlending, toneMapped: false }));
    trail.frustumCulled = false;
    g.add(trail);
    var phase = Math.random() * 10;
    function p(t) { return [Math.sin(t * 1.6) * 1.6, Math.cos(t * 2.3) * 0.6, Math.cos(t * 1.6) * 1.6]; }
    function update(t) {
      t += phase;
      var h = p(t); core.position.set(h[0], h[1], h[2]); halo.position.copy(core.position);
      for (var i = 0; i < N; i++) { var q = p(t - i * 0.025); pos[i * 3] = q[0] + (Math.random() - 0.5) * 0.05 * i; pos[i * 3 + 1] = q[1] + (Math.random() - 0.5) * 0.05 * i; pos[i * 3 + 2] = q[2]; }
      gg.attributes.position.needsUpdate = true;
    }
    update(0);
    return { obj: g, update: update, flying: true };
  }

  function mothShip(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var wood = M(0x6a4630, { r: 0.9 }), trim = M(0xd8b86a, { m: 0.5, r: 0.4 });
    var pts = [];
    for (var i = 0; i <= 10; i++) { var t = i / 10; pts.push(new T.Vector2(Math.max(0.05, Math.sin(t * Math.PI) * 1.0), (t - 0.5) * 5)); }
    var hg = new T.LatheGeometry(pts, 8); hg.rotateX(Math.PI / 2);
    var hull = mesh(hg, wood); hull.scale.set(1, 0.6, 1); body.add(hull);
    var rail = mesh(new T.TorusGeometry(0.95, 0.05, 4, 16), trim, 0, 0.35, 0); rail.rotation.x = Math.PI / 2; rail.scale.y = 2.4; body.add(rail);
    var mast = mesh(new T.CylinderGeometry(0.06, 0.08, 3.2, 5), wood, 0, 1.8, 0.2); body.add(mast);
    var mw = M(o.wing || 0xd8c8f0, { ds: true, t: true, o: 0.88, e: o.wingGlow || 0x8a6cff, ei: 0.25 });
    var fore = wingPair(wingMoth(3.0), mw, 0.1, 2.2, 0.6), hind = wingPair(wingMoth(2.0), mw, 0.1, 1.6, -0.6);
    [fore, hind].forEach(function (w) { w.R.rotation.y = 0.3; w.L.rotation.y = -0.3; body.add(w.R); body.add(w.L); });
    var spots = G(0xffb04a);
    [-1, 1].forEach(function (s) { var sp = new T.Mesh(new T.CircleGeometry(0.28, 12), spots); sp.position.set(1.7 * s, 2.25, 1.0); sp.rotation.x = -Math.PI / 2; body.add(sp); });
    var lantern = glowSprite(0xffcf6a, 1.6, 0.9); lantern.position.set(0, 0.5, 2.7); body.add(lantern);
    var ant = [];
    [-1, 1].forEach(function (s) { var a = mesh(new T.CylinderGeometry(0.02, 0.03, 1.4, 3), trim, 0.25 * s, 0.9, 2.6); a.rotation.set(0.9, 0, -0.4 * s); body.add(a); ant.push(a); });
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      var f = Math.sin(t * 1.5);
      fore.flap(f * 0.35 + 0.2); hind.flap(Math.sin(t * 1.5 - 0.6) * 0.3 + 0.15);
      body.rotation.z = Math.sin(t * 0.6) * 0.06;
      body.position.y = Math.sin(t * 0.9) * 0.2;
      lantern.material.opacity = 0.7 + 0.25 * Math.sin(t * 5);
    }
    update(0);
    return { obj: g, update: update, flying: true };
  }

  function voidWhale(o) {
    o = o || {};
    var g = new T.Group(), body = new T.Group(); g.add(body);
    var pts = [];
    for (var i = 0; i <= 14; i++) { var t = i / 14; pts.push(new T.Vector2(Math.max(0.05, Math.pow(Math.sin(t * Math.PI), 0.8) * 1.5 * (0.55 + 0.45 * t)), (t - 0.5) * 8)); }
    var bg = new T.LatheGeometry(pts, 10); bg.rotateX(Math.PI / 2);
    bg = bg.toNonIndexed();
    var cc = [], pa = bg.attributes.position, r = rng(o.seed || 31), base = new T.Color(o.color || 0x1d1a4a), belly = new T.Color(0x3a5a9a), speck = new T.Color(0xffffff);
    for (i = 0; i < pa.count; i += 3) {
      var y = (pa.getY(i) + pa.getY(i + 1) + pa.getY(i + 2)) / 3;
      var c = base.clone().lerp(belly, clamp(-y * 0.8 + 0.3, 0, 1));
      if (r() < 0.06) c.lerp(speck, 0.9);
      for (var k = 0; k < 3; k++) cc.push(c.r, c.g, c.b);
    }
    bg.setAttribute('color', new T.Float32BufferAttribute(cc, 3));
    bg.computeVertexNormals();
    var hull = mesh(bg, new T.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.6, metalness: 0.2, emissive: 0x1a1450, emissiveIntensity: 0.6 }));
    body.add(hull);
    var stripeM = G(o.glow || 0x7fe8ff);
    for (i = 0; i < 6; i++) { var s = new T.Mesh(new T.BoxGeometry(0.06, 0.04, 2.6), stripeM); s.position.set((i - 2.5) * 0.25, -1.05, 0.8); body.add(s); }
    eyes(body, o.eye || 0x9ff4ff, 0.95, 0.15, 3.0, 0.1);
    var finM = M(o.fin || 0x2c2766, { ds: true, e: 0x3a2a9a, ei: 0.3 });
    var fl = wingPair(wingMoth(2.2), finM, 1.0, -0.4, 1.0); body.add(fl.R); body.add(fl.L);
    var fluke = new T.Group(); fluke.position.set(0, 0, -4.0); body.add(fluke);
    var fk = wingPair(wingMoth(1.8), finM, 0.05, 0, 0); fk.R.rotation.y = -1.2; fk.L.rotation.y = 1.2; fluke.add(fk.R); fluke.add(fk.L);
    var phase = Math.random() * 10;
    function update(t) {
      t += phase;
      fluke.rotation.x = Math.sin(t * 0.9) * 0.35;
      fl.flap(Math.sin(t * 0.9 + 1) * 0.3);
      body.rotation.x = Math.sin(t * 0.9) * 0.05;
      body.rotation.z = Math.sin(t * 0.3) * 0.08;
    }
    update(0);
    return { obj: g, update: update, flying: true };
  }

  /* ------------------------------------------------------------- hallows */
  function hallow(type, o) {
    o = o || {};
    var g = new T.Group(), ups = [];
    var stone = M(0x8a8096), dark = M(0x3a3348), wood = M(0x5a3e2a), gold = M(0xd8b86a, { m: 0.6, r: 0.35 });
    if (type === 14) { // Root Delver — mine of wildroot
      var arch = mesh(new T.TorusGeometry(1.2, 0.35, 5, 10, Math.PI), stone, 0, 0, 0); g.add(arch);
      var hole = new T.Mesh(new T.CircleGeometry(1.0, 10, 0, Math.PI), G(0x0a0612)); hole.position.z = -0.05; g.add(hole);
      var wheel = new T.Group(); wheel.position.set(1.9, 1.4, 0); g.add(wheel);
      wheel.add(mesh(new T.TorusGeometry(0.8, 0.08, 4, 12), wood));
      for (var i = 0; i < 4; i++) { var sp = mesh(new T.BoxGeometry(1.6, 0.08, 0.08), wood); sp.rotation.z = i * Math.PI / 4; wheel.add(sp); }
      var post = mesh(new T.CylinderGeometry(0.1, 0.12, 1.5, 5), wood, 1.9, 0.7, -0.2); g.add(post);
      var cart = mesh(new T.BoxGeometry(0.9, 0.5, 0.6), wood, -1.6, 0.25, 0.8); g.add(cart);
      var ore = crystal(0xffc85a, 0.35); ore.position.set(-1.6, 0.45, 0.8); g.add(ore);
      for (i = 0; i < 5; i++) { var rt = mesh(new T.ConeGeometry(0.12, 1.4, 4), M(0x9a6a3a, { e: 0xffaa40, ei: 0.25 }), (i - 2) * 0.5, 0.1, 1.4 + (i % 2) * 0.3); rt.rotation.x = 1.2; g.add(rt); }
      ups.push(function (t) { wheel.rotation.z = t * 0.8; });
    } else if (type === 15) { // Gloam Cauldron
      var pts = [];
      for (i = 0; i <= 8; i++) { var k = i / 8; pts.push(new T.Vector2(Math.sin(k * Math.PI * 0.85) * 1.3 + 0.1, k * 1.8)); }
      var pot = mesh(new T.LatheGeometry(pts, 12), M(0x2a2630, { m: 0.6, r: 0.4 }), 0, 0.4, 0); g.add(pot);
      var brew = new T.Mesh(new T.CircleGeometry(1.15, 16), G(0x7dffb0)); brew.rotation.x = -Math.PI / 2; brew.position.y = 1.95; g.add(brew);
      var glow = glowSprite(0x7dffb0, 4, 0.6); glow.position.y = 2.4; g.add(glow);
      for (i = 0; i < 3; i++) { var lg = mesh(new T.CylinderGeometry(0.08, 0.12, 0.7, 4), dark, Math.cos(i * 2.1) * 0.8, 0.3, Math.sin(i * 2.1) * 0.8); g.add(lg); }
      var fire = [];
      for (i = 0; i < 5; i++) { var f = new T.Mesh(new T.ConeGeometry(0.2, 0.7, 4), G(i % 2 ? 0xff7a3a : 0xffc04a)); f.position.set(Math.cos(i * 1.3) * 0.4, 0.2, Math.sin(i * 1.3) * 0.4); g.add(f); fire.push(f); }
      var bub = [];
      for (i = 0; i < 6; i++) { var b = new T.Mesh(new T.SphereGeometry(0.12, 6, 4), G(0xb6ffd0, { t: true, o: 0.8 })); g.add(b); bub.push(b); }
      ups.push(function (t) {
        for (var i = 0; i < fire.length; i++) fire[i].scale.y = 0.7 + 0.4 * Math.abs(Math.sin(t * 7 + i));
        for (var j = 0; j < bub.length; j++) { var c = (t * 0.5 + j / bub.length) % 1; bub[j].position.set(Math.cos(j * 2.4) * 0.6, 2.0 + c * 1.6, Math.sin(j * 2.4) * 0.6); bub[j].scale.setScalar(1 - c); }
        glow.material.opacity = 0.45 + 0.2 * Math.sin(t * 3);
      });
    } else if (type === 16) { // Ward Lantern
      g.add(mesh(new T.CylinderGeometry(0.12, 0.2, 3.6, 6), dark, 0, 1.8, 0));
      var hook = mesh(new T.TorusGeometry(0.35, 0.05, 4, 10, Math.PI), gold, 0, 3.7, 0); g.add(hook);
      var cage = mesh(new T.OctahedronGeometry(0.5, 0), M(0xd8b86a, { m: 0.6, r: 0.3, t: true, o: 0.5 }), 0, 3.0, 0); cage.scale.y = 1.4; g.add(cage);
      var orb = new T.Mesh(new T.IcosahedronGeometry(0.28, 1), G(0x9fe8ff)); orb.position.y = 3.0; g.add(orb);
      var og = glowSprite(0x9fe8ff, 3.2, 0.7); og.position.y = 3.0; g.add(og);
      ups.push(function (t) { og.material.opacity = 0.5 + 0.25 * Math.sin(t * 2.2); cage.rotation.y = t * 0.6; });
    } else if (type === 17) { // Veil Moon
      var mo = mesh(new T.IcosahedronGeometry(1.0, 2), M(0xc8c0e8, { e: 0x5a4aa0, ei: 0.4 }), 0, 0, 0); g.add(mo);
      var ring = new T.Mesh(new T.TorusGeometry(1.7, 0.05, 4, 40), G(0xc9a0ff, { t: true, o: 0.7 })); ring.rotation.x = 1.2; g.add(ring);
      var vg = glowSprite(0xb08cff, 6, 0.4); g.add(vg);
      ups.push(function (t) { mo.rotation.y = t * 0.3; ring.rotation.z = t * 0.4; });
    } else if (type === 18) { // Barrow Vault
      var mound = mesh(new T.SphereGeometry(1.8, 10, 6, 0, TAU, 0, Math.PI / 2), M(0x4f7f4a), 0, 0, 0); mound.scale.y = 0.75; g.add(mound);
      var door = mesh(new T.BoxGeometry(0.9, 1.2, 0.2), stone, 0, 0.5, 1.55); g.add(door);
      var lint = mesh(new T.BoxGeometry(1.4, 0.25, 0.4), stone, 0, 1.15, 1.5); g.add(lint);
      for (i = 0; i < 3; i++) { var st = mesh(new T.BoxGeometry(0.3, 1.4, 0.3), stone, Math.cos(i * 2.1 + 0.5) * 2.2, 0.6, Math.sin(i * 2.1 + 0.5) * 2.2); st.rotation.z = 0.1; g.add(st); }
      var rune = new T.Mesh(new T.CircleGeometry(0.22, 6), G(0xffd27a)); rune.position.set(0, 0.6, 1.66); g.add(rune);
    } else if (type === 19) { // Thunder Spire
      var tw = mesh(new T.CylinderGeometry(0.5, 0.9, 4.2, 6), stone, 0, 2.1, 0); g.add(tw);
      var roof = mesh(new T.ConeGeometry(0.75, 1.0, 6), dark, 0, 4.7, 0); g.add(roof);
      var cr = crystal(0xa8d8ff, 0.6); cr.position.y = 5.4; g.add(cr);
      var bolt = glowSprite(0xa8d8ff, 3, 0.7); bolt.position.y = 6.2; g.add(bolt);
      var win = new T.Mesh(new T.PlaneGeometry(0.25, 0.4), G(0xffc04a)); win.position.set(0, 2.8, 0.66); g.add(win);
      ups.push(function (t) { cr.rotation.y = t; cr.position.y = 5.4 + Math.sin(t * 1.5) * 0.2; bolt.material.opacity = Math.random() < 0.03 ? 1 : 0.4; });
    } else if (type === 20) { // Mana Spring
      var basin = mesh(new T.CylinderGeometry(1.4, 1.6, 0.5, 10), stone, 0, 0.25, 0); g.add(basin);
      var pool = new T.Mesh(new T.CircleGeometry(1.2, 16), G(0x5ad8ff)); pool.rotation.x = -Math.PI / 2; pool.position.y = 0.52; g.add(pool);
      var col = new T.Mesh(new T.CylinderGeometry(0.35, 0.5, 5, 12, 1, true), G(0x7ae8ff, { t: true, o: 0.35, add: true, ds: true })); col.position.y = 3.0; g.add(col);
      var mg = glowSprite(0x7ae8ff, 4, 0.6); mg.position.y = 1.0; g.add(mg);
      ups.push(function (t) { col.scale.x = col.scale.z = 1 + 0.15 * Math.sin(t * 3); col.material.opacity = 0.25 + 0.12 * Math.sin(t * 2); });
    } else if (type === 21) { // Ley Heart
      var heart = crystal(0x6affd8, 2.0); heart.position.y = 1.4; g.add(heart);
      var rings = [];
      for (i = 0; i < 3; i++) { var rg = new T.Mesh(new T.TorusGeometry(2.0 + i * 0.5, 0.04, 4, 48), G(i === 1 ? 0xe8c872 : 0x6affd8)); rg.position.y = 3.0; g.add(rg); rings.push(rg); }
      var hg = glowSprite(0x6affd8, 8, 0.45); hg.position.y = 3; g.add(hg);
      ups.push(function (t) { heart.rotation.y = t * 0.3; for (var i = 0; i < rings.length; i++) { rings[i].rotation.x = t * (0.4 + i * 0.2); rings[i].rotation.y = t * (0.3 - i * 0.15); } });
    } else if (type === 22) { // The Worldroot
      var tr = mesh(new T.CylinderGeometry(0.9, 1.8, 7, 9), M(0x6a4a3a), 0, 3.5, 0); g.add(tr);
      var cn = new T.Group(); cn.position.y = 7.5; g.add(cn);
      var rr = rng(99);
      for (i = 0; i < 12; i++) { var lf = mesh(new T.IcosahedronGeometry(1.4 + rr() * 1.0, 0), M(rr() < 0.3 ? 0xe8c872 : 0x4f9a6a, { e: 0x1a3a2a, ei: 0.5 }), (rr() - 0.5) * 6, rr() * 2.5, (rr() - 0.5) * 6); cn.add(lf); }
      var wg = glowSprite(0xffe7a0, 12, 0.35); wg.position.y = 8.5; g.add(wg);
      ups.push(function (t) { cn.rotation.y = Math.sin(t * 0.2) * 0.1; });
    }
    var s = o.scale || 1; g.scale.setScalar(s);
    return { obj: g, update: function (t) { for (var i = 0; i < ups.length; i++) ups[i](t); } };
  }

  /* ---------------------------------------------------- the bestiary index */
  // type id (the chain's struct type) -> how its beast is shaped
  var BEASTS = {
    1: function () { return dragon({ color: 0xd2a043, belly: 0xf6e2b0, wing: 0x7a2238, eye: 0xfff6b0, span: 5.2 }); },
    2: function () { return voidWhale({}); },
    3: function () { return sprite({ color: 0x8ff6ff }); },
    4: function () { return mothShip({}); },
    5: function () { return harpy(); },
    6: function () { return owl({}); },
    7: function () { return bird({ color: 0xd9c08a, feather: 0x4c6ea8, head: 0xf5f2e8, eye: 0x9ff4ff, edge: 0x58c8ff, span: 3.6, lionTail: true, flap: 2.6 }); },
    8: function () { return treant({}); },
    9: function () { return troll({}); },
    10: function () { return humanoid({}); },
    11: function () { return kraken({}); },
    12: function () { return serpent({}); },
    13: function () { return wight({}); }
  };
  function beast(type) {
    type = +type;
    if (BEASTS[type]) return BEASTS[type]();
    return hallow(type, {});
  }
  K.beast = beast;
  K.dragon = dragon;

  // realm ambit for each beast type (matches the chain's operating ambit)
  K.REALM = { 1: 'skies', 2: 'starfall', 3: 'starfall', 4: 'starfall', 5: 'skies', 6: 'skies', 7: 'skies', 8: 'wilds', 9: 'wilds', 10: 'wilds', 11: 'deeps', 12: 'deeps', 13: 'deeps', 14: 'wilds', 15: 'wilds', 16: 'starfall', 17: 'starfall', 18: 'wilds', 19: 'wilds', 20: 'wilds', 21: 'wilds', 22: 'wilds' };
  // how big each looks beside its kin
  var SCALE = { 1: 0.8, 2: 0.75, 3: 0.8, 4: 0.7, 5: 0.6, 6: 0.6, 7: 0.6, 8: 0.6, 9: 0.55, 10: 0.7, 11: 0.45, 12: 0.5, 13: 0.55, 14: 0.7, 15: 0.7, 16: 0.7, 17: 0.8, 18: 0.7, 19: 0.6, 20: 0.7, 21: 0.6, 22: 0.45 };

  /* ------------------------------------------------------------ particles */
  function Bursts(stage) {
    var list = [];
    stage.add(function (t, dt) {
      for (var i = list.length - 1; i >= 0; i--) {
        var b = list[i]; b.age += dt;
        var k = b.age / b.life;
        if (k >= 1) { stage.scene.remove(b.pts); b.pts.geometry.dispose(); b.pts.material.dispose(); list.splice(i, 1); continue; }
        var p = b.pos;
        for (var j = 0; j < b.n; j++) {
          b.vel[j * 3 + 1] += b.grav * dt;
          p[j * 3] += b.vel[j * 3] * dt; p[j * 3 + 1] += b.vel[j * 3 + 1] * dt; p[j * 3 + 2] += b.vel[j * 3 + 2] * dt;
          if (b.swirl) { var x = p[j * 3] - b.o.x, z = p[j * 3 + 2] - b.o.z, c = Math.cos(dt * b.swirl), s = Math.sin(dt * b.swirl); p[j * 3] = b.o.x + x * c - z * s; p[j * 3 + 2] = b.o.z + x * s + z * c; }
        }
        b.pts.geometry.attributes.position.needsUpdate = true;
        b.pts.material.opacity = 1 - k * k;
      }
    });
    return function burst(origin, o) {
      o = o || {};
      var n = o.count || 80, pos = new Float32Array(n * 3), vel = new Float32Array(n * 3), sp = o.speed || 6;
      for (var i = 0; i < n; i++) {
        var a = Math.random() * TAU, u = o.up ? Math.random() * 0.4 + 0.6 : Math.random() * 2 - 1, r = Math.sqrt(1 - u * u);
        var rad = o.ring ? (o.ring * (0.8 + Math.random() * 0.4)) : 0;
        pos[i * 3] = origin.x + Math.cos(a) * rad; pos[i * 3 + 1] = origin.y; pos[i * 3 + 2] = origin.z + Math.sin(a) * rad;
        var s = sp * (0.4 + Math.random() * 0.6);
        vel[i * 3] = Math.cos(a) * r * s * (o.spread == null ? 1 : o.spread); vel[i * 3 + 1] = u * s; vel[i * 3 + 2] = Math.sin(a) * r * s * (o.spread == null ? 1 : o.spread);
      }
      var g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(pos, 3));
      var pts = new T.Points(g, new T.PointsMaterial({ map: softDot(), color: o.color || 0xffe08a, size: o.size || 0.6, transparent: true, depthWrite: false, blending: T.AdditiveBlending, toneMapped: false }));
      pts.frustumCulled = false;
      stage.scene.add(pts);
      list.push({ pts: pts, pos: pos, vel: vel, n: n, age: 0, life: o.life || 1.6, grav: o.grav == null ? -4 : o.grav, swirl: o.swirl || 0, o: origin.clone() });
    };
  }
  K.Bursts = Bursts;

  /* -------------------------------------------------------------- orbit cam */
  function Orbit(stage, o) {
    o = o || {};
    var cam = stage.camera, canvas = stage.canvas;
    var cur = { az: o.az || 0.7, el: o.el || 0.35, dist: o.dist || 50, target: (o.target || new T.Vector3()).clone() };
    var goal = { az: cur.az, el: cur.el, dist: cur.dist, target: cur.target.clone() };
    var drag = false, px = 0, py = 0, moved = 0, idle = 0;
    function down(e) { drag = true; px = e.clientX; py = e.clientY; moved = 0; try { canvas.setPointerCapture(e.pointerId); } catch (x) { } }
    function move(e) {
      if (!drag) return;
      var dx = e.clientX - px, dy = e.clientY - py; px = e.clientX; py = e.clientY;
      moved += Math.abs(dx) + Math.abs(dy);
      goal.az -= dx * 0.006; goal.el = clamp(goal.el + dy * 0.004, o.minEl == null ? 0.02 : o.minEl, o.maxEl || 1.35);
      idle = 0;
    }
    function up(e) {
      drag = false;
      if (moved < 6 && o.onTap) {
        var r = canvas.getBoundingClientRect();
        o.onTap(new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1));
      }
    }
    function wheel(e) { e.preventDefault(); goal.dist = clamp(goal.dist * (1 + e.deltaY * 0.0012), o.min || 10, o.max || 200); idle = 0; }
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('wheel', wheel, { passive: false });
    canvas.style.touchAction = 'none';
    stage.add(function (t, dt) {
      idle += dt;
      if (!drag && o.auto && idle > 2.5) goal.az += dt * o.auto;
      var k = 1 - Math.exp(-dt * (o.ease || 3));
      cur.az = lerp(cur.az, goal.az, k); cur.el = lerp(cur.el, goal.el, k); cur.dist = lerp(cur.dist, goal.dist, k);
      cur.target.lerp(goal.target, k);
      var ce = Math.cos(cur.el);
      cam.position.set(cur.target.x + Math.sin(cur.az) * ce * cur.dist, cur.target.y + Math.sin(cur.el) * cur.dist, cur.target.z + Math.cos(cur.az) * ce * cur.dist);
      cam.lookAt(cur.target);
    });
    return {
      goal: goal,
      to: function (target, dist, el, az) { if (target) goal.target.copy(target); if (dist) goal.dist = dist; if (el != null) goal.el = el; if (az != null) goal.az = az; idle = 0; },
      dispose: function () { canvas.removeEventListener('pointerdown', down); canvas.removeEventListener('pointermove', move); canvas.removeEventListener('pointerup', up); canvas.removeEventListener('wheel', wheel); }
    };
  }
  K.Orbit = Orbit;

  function picker(stage, roots) {
    var rc = new T.Raycaster();
    return function (ndc) {
      rc.setFromCamera(ndc, stage.camera);
      var hits = rc.intersectObjects(roots(), true);
      for (var i = 0; i < hits.length; i++) {
        var o = hits[i].object;
        while (o) { if (o.userData && o.userData.pick != null) return o.userData.pick; o = o.parent; }
      }
      return null;
    };
  }

  function wardDome(radius, color) {
    var mat = new T.ShaderMaterial({
      transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide,
      uniforms: { time: { value: 0 }, c: { value: new T.Color(color || 0x8fe8ff) }, power: { value: 0.5 }, flash: { value: 0 } },
      vertexShader: 'varying vec3 vN; varying vec3 vV; varying vec3 vP; void main(){ vP = position; vec4 mv = modelViewMatrix*vec4(position,1.0); vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }',
      fragmentShader: [
        'varying vec3 vN; varying vec3 vV; varying vec3 vP; uniform float time; uniform vec3 c; uniform float power; uniform float flash;',
        'void main(){ float f = pow(1.0 - abs(dot(vN, vV)), 2.5);',
        ' float hex = abs(sin(vP.x*1.2 + time*0.4)*sin(vP.y*1.2)*sin(vP.z*1.2 - time*0.3));',
        ' float a = (f*0.6 + smoothstep(0.92, 1.0, hex)*0.25) * power + flash*f;',
        ' gl_FragColor = vec4(c*a, a);', shaderTail, '}'
      ].join('\n')
    });
    var m = new T.Mesh(new T.SphereGeometry(radius, 48, 24, 0, TAU, 0, Math.PI * 0.62), mat);
    m.renderOrder = 5;
    return { obj: m, mat: mat };
  }

  /* ============================================================== SCENES */

  /* ---- The Gate: title vista ---- */
  K.gate = function (canvas, o) {
    o = o || {};
    var st = Stage(canvas, { fogDensity: 0.006 });
    var sk = sky(st, {});
    lights(st, {});
    cloudSea(st, { y: -46 });
    var I = isle({ radius: 17, seed: 7, lake: true, lakeAngle: 0.9 });
    dressIsle(I, { trees: 90, seed: 4 });
    st.scene.add(I.group); st.add(I.update);
    // a keep on the summit
    var keep = new T.Group();
    var kx = -5, kz = -3, ky = I.heightAt(kx, kz);
    keep.position.set(kx, ky, kz);
    var stone = M(0x9a90a8), roof = M(0x3a2d5c);
    [[0, 0, 1.6, 6], [2.2, 1.2, 0.9, 4.2], [-1.8, 1.6, 0.8, 3.6]].forEach(function (p) {
      keep.add(mesh(new T.CylinderGeometry(p[2] * 0.85, p[2], p[3], 7), stone, p[0], p[3] / 2, p[1]));
      keep.add(mesh(new T.ConeGeometry(p[2] * 1.25, p[2] * 2.2, 7), roof, p[0], p[3] + p[2] * 1.1, p[1]));
      var w = new T.Mesh(new T.PlaneGeometry(0.3, 0.5), G(0xffc66a)); w.position.set(p[0], p[3] * 0.7, p[1] + p[2] * 0.86); keep.add(w);
    });
    var beacon = glowSprite(0xe8c872, 5, 0.8); beacon.position.set(0, 9.3, 0); keep.add(beacon);
    st.scene.add(keep);
    var hc = hallow(20, {}); hc.obj.position.copy(I.surface(6, -6)); st.scene.add(hc.obj); st.add(hc.update);
    // distant isles
    var far = [];
    for (var i = 0; i < 7; i++) {
      var fi = isle({ radius: 3 + (i % 3) * 2, seed: 30 + i, rings: 10, segs: 30, under: 8, hills: 1.2 });
      dressIsle(fi, { trees: 8, rocks: 3, crystals: 2, seed: 40 + i });
      var a = i / 7 * TAU + 0.4, d = 60 + (i % 3) * 30;
      fi.group.position.set(Math.cos(a) * d, -8 + (i % 4) * 9, Math.sin(a) * d);
      st.scene.add(fi.group); far.push(fi);
    }
    for (i = 0; i < 18; i++) {
      var r = rng(200 + i), cp = cloudPuff(r, 1.5 + r() * 2.5);
      var ca = r() * TAU, cd = 25 + r() * 70;
      cp.position.set(Math.cos(ca) * cd, -14 - r() * 18, Math.sin(ca) * cd);
      st.scene.add(cp); far.push({ group: cp, drift: 0.2 + r() * 0.4 });
    }
    motes(st, { count: 260, box: 50, h: 24, y: -4 });
    // the Elder Wyrm circles
    var wy = dragon({ color: 0xd2a043, belly: 0xf6e2b0, wing: 0x7a2238, span: 5.2, flap: 1.6 });
    wy.obj.scale.setScalar(1.3);
    st.scene.add(wy.obj);
    var flock = [];
    for (i = 0; i < 5; i++) { var h = harpy(); h.obj.scale.setScalar(0.35); st.scene.add(h.obj); flock.push(h); }
    var px = 0, py = 0;
    function pm(e) { var r = canvas.getBoundingClientRect(); px = ((e.clientX - r.left) / r.width - 0.5); py = ((e.clientY - r.top) / r.height - 0.5); }
    window.addEventListener('pointermove', pm);
    var look = new T.Vector3(0, 3, 0);
    st.add(function (t) {
      var a = t * 0.05 + 0.4;
      st.camera.position.set(Math.sin(a) * 58 + px * 6, 15 - py * 5, Math.cos(a) * 58);
      st.camera.lookAt(look);
      wy.update(t);
      var wa = -t * 0.22;
      wy.obj.position.set(Math.cos(wa) * 27, 9 + Math.sin(t * 0.5) * 3, Math.sin(wa) * 27);
      wy.obj.rotation.set(0, -wa + Math.PI, 0.35);
      wy.obj.rotation.y = Math.atan2(-Math.sin(wa) * -1, Math.cos(wa) * -1);
      var dir = new T.Vector3(Math.sin(wa), 0, -Math.cos(wa));
      wy.obj.lookAt(wy.obj.position.clone().add(dir));
      wy.obj.rotateZ(-0.3);
      for (var i = 0; i < flock.length; i++) {
        flock[i].update(t);
        var fa = t * 0.15 + i * 0.25;
        flock[i].obj.position.set(Math.cos(fa) * 48 + i * 1.5, 18 + Math.sin(t + i) * 1.2, Math.sin(fa) * 48 - 10);
        flock[i].obj.lookAt(Math.cos(fa + 0.1) * 48 + i * 1.5, 18, Math.sin(fa + 0.1) * 48 - 10);
      }
      for (var j = 0; j < far.length; j++) { var f = far[j]; if (f.drift) f.group.position.x += Math.sin(t * 0.1 + j) * 0.01; else f.group.position.y += Math.sin(t * 0.4 + j) * 0.005; }
      beacon.material.opacity = 0.6 + 0.3 * Math.sin(t * 2);
    });
    // Alpha rain: the first light falling, as it did when the sky broke.
    var RN = 1600, rpos = new Float32Array(RN * 3), rvel = new Float32Array(RN), rr = rng(808);
    for (var q = 0; q < RN; q++) { rpos[q * 3] = (rr() - 0.5) * 140; rpos[q * 3 + 1] = rr() * 90 - 20; rpos[q * 3 + 2] = (rr() - 0.5) * 140; rvel[q] = 6 + rr() * 10; }
    var rgeo = new T.BufferGeometry(); rgeo.setAttribute('position', new T.BufferAttribute(rpos, 3));
    var rmat = new T.PointsMaterial({ map: softDot(), color: 0xffd98a, size: 1.7, transparent: true, opacity: 0, depthWrite: false, blending: T.AdditiveBlending, toneMapped: false });
    var rain = new T.Points(rgeo, rmat); rain.frustumCulled = false; st.scene.add(rain);
    var rainOn = 0, rainLvl = 0, push = 0, lookY = 3;
    st.add(function (t, dt) {
      rainLvl += ((rainOn ? 1 : 0) - rainLvl) * Math.min(1, dt * 1.2);
      rmat.opacity = rainLvl * 0.95;
      if (rainLvl > 0.01) {
        for (var q = 0; q < RN; q++) { rpos[q * 3 + 1] -= rvel[q] * dt; rpos[q * 3] += Math.sin(t + q) * dt * 0.6; if (rpos[q * 3 + 1] < -30) rpos[q * 3 + 1] = 70; }
        rgeo.attributes.position.needsUpdate = true;
      }
      push += ((rainOn ? 1 : 0) - push) * Math.min(1, dt * 0.4);
      look.y = lookY + push * 8;
    });
    return {
      rain: function (on) { rainOn = on ? 1 : 0; },
      dispose: function () { window.removeEventListener('pointermove', pm); st.dispose(); }
    };
  };

  /* ---- The Hold: your isle, your hallows, your warband ---- */
  K.hold = function (canvas, o) {
    o = o || {};
    var st = Stage(canvas, { fogDensity: 0.0065 });
    var sk = sky(st, {});
    lights(st, {});
    cloudSea(st, { y: -44 });
    var R = 19;
    var I = isle({ radius: R, seed: o.seed || 17, lake: true, lakeAngle: 0.5, lakeSize: 0.3 });
    var plots = [];
    for (var i = 0; i < 9; i++) { var a = 2.0 + i * 0.52, d = i % 2 ? R * 0.62 : R * 0.36; plots.push({ x: Math.cos(a) * d, z: Math.sin(a) * d, r: 3 }); }
    var wildSpots = [];
    for (i = 0; i < 14; i++) { a = -1.6 + i * 0.32 + (i % 2) * 0.1; d = R * (0.78 + (i % 3) * 0.05); wildSpots.push({ x: Math.cos(a + 3.6) * d, z: Math.sin(a + 3.6) * d, r: 2 }); }
    dressIsle(I, { trees: 70, seed: 5, avoid: plots.concat(wildSpots), crystals: 10 });
    st.scene.add(I.group); st.add(I.update);
    motes(st, { count: 220, box: 46, h: 22, y: -2 });
    for (i = 0; i < 14; i++) { var r = rng(500 + i), cp = cloudPuff(r, 1.4 + r() * 2.2); var ca = r() * TAU, cd = 30 + r() * 50; cp.position.set(Math.cos(ca) * cd, -12 - r() * 20, Math.sin(ca) * cd); st.scene.add(cp); }
    var dome = wardDome(R * 1.35); dome.obj.position.y = -2; st.scene.add(dome.obj);
    var burst = Bursts(st);
    var orbit = Orbit(st, { dist: 78, el: 0.58, az: 0.9, target: new T.Vector3(0, 4, 0), min: 18, max: 140, auto: 0.03, onTap: function (ndc) { var id = pick(ndc); if (o.onPick) o.onPick(id); } });

    var units = {}, roots = [];
    var counters = { skies: 0, starfall: 0, wilds: 0, deeps: 0, hallow: 0 };
    var selRing = runeDisc(2.2, '#e8c872', 0.95); selRing.visible = false; st.scene.add(selRing);
    var selBeam = new T.Mesh(new T.CylinderGeometry(0.6, 0.6, 30, 16, 1, true), G(0xe8c872, { t: true, o: 0.12, add: true, ds: true })); selBeam.visible = false; st.scene.add(selBeam);
    var selected = null;

    function placeUnit(u) {
      var type = +u.type, b = beast(type), realm = u.realm || K.REALM[type];
      var holder = new T.Group(); holder.add(b.obj);
      holder.userData.pick = u.id;
      b.obj.scale.multiplyScalar(SCALE[type] || 0.6);
      var info = { u: u, b: b, holder: holder, realm: realm, type: type };
      if (type >= 14) {
        var slot = (u.plot != null ? u.plot : counters.hallow++) % plots.length, p = plots[slot];
        if (type === 16 || type === 17) {
          info.orbit = { r: R * 0.9 + (slot % 3) * 2, y: 20 + (slot % 2) * 4, s: 0.06, ph: slot * 1.7 };
        } else {
          holder.position.copy(I.surface(p.x, p.z)); holder.rotation.y = Math.atan2(-p.x, -p.z) + Math.PI;
        }
      } else if (realm === 'wilds') {
        var ws = wildSpots[counters.wilds++ % wildSpots.length];
        holder.position.copy(I.surface(ws.x, ws.z)); holder.rotation.y = Math.atan2(ws.x, ws.z);
      } else if (realm === 'deeps') {
        var n = counters.deeps++;
        info.swim = { r: I.lake.r * (0.25 + (n % 3) * 0.22), s: 0.25 + n * 0.05, ph: n * 2.1 };
      } else if (realm === 'skies') {
        n = counters.skies++;
        info.orbit = { r: R * 0.85 + (n % 3) * 4, y: 9 + (n % 4) * 2.2, s: 0.16 + (n % 2) * 0.05, ph: n * 1.3, dir: n % 2 ? -1 : 1 };
      } else {
        n = counters.starfall++;
        info.orbit = { r: R * 1.35 + (n % 3) * 5, y: 22 + (n % 3) * 3, s: 0.07 + (n % 2) * 0.03, ph: n * 2.2, dir: n % 2 ? -1 : 1 };
      }
      if (u.offline) holder.traverse(function (m) { if (m.material && m.material.color) { m.material = m.material.clone(); m.material.color.multiplyScalar(0.35); } });
      if (u.building) {
        holder.traverse(function (m) { if (m.material && !m.isSprite) { m.material = m.material.clone(); m.material.transparent = true; m.material.opacity = 0.32; m.material.depthWrite = false; } });
        info.rune = runeDisc(2.6 / (SCALE[type] || 0.6), '#e8c872', 0.9); info.rune.position.y = 0.2; b.obj.add(info.rune);
      }
      info.key = [type, realm, !!u.offline, !!u.building].join('|');
      st.scene.add(holder);
      units[u.id] = info; roots.push(holder);
      return info;
    }
    (o.units || []).forEach(placeUnit);

    function worldPos(info) { var v = new T.Vector3(); info.holder.getWorldPosition(v); return v; }
    var pick = picker(st, function () { return roots; });

    st.add(function (t) {
      for (var id in units) {
        var u = units[id];
        u.b.update(t);
        if (u.orbit) {
          var a = t * u.orbit.s * (u.orbit.dir || 1) + u.orbit.ph;
          u.holder.position.set(Math.cos(a) * u.orbit.r, u.orbit.y + Math.sin(t * 0.7 + u.orbit.ph) * 0.8, Math.sin(a) * u.orbit.r);
          if (u.b.flying) {
            var a2 = a + 0.05 * (u.orbit.dir || 1);
            u.holder.lookAt(Math.cos(a2) * u.orbit.r, u.holder.position.y, Math.sin(a2) * u.orbit.r);
          }
        }
        if (u.rune) u.rune.rotation.z = t * 0.8;
        if (u.swim) {
          var sa = t * u.swim.s + u.swim.ph;
          u.holder.position.set(I.lake.x + Math.cos(sa) * u.swim.r, -0.9, I.lake.z + Math.sin(sa) * u.swim.r);
          u.holder.rotation.y = -sa;
        }
      }
      dome.mat.uniforms.time.value = t;
      dome.mat.uniforms.flash.value *= 0.95;
      if (selected && units[selected]) {
        var p = worldPos(units[selected]);
        selRing.position.set(p.x, p.y + 0.15, p.z); selRing.rotation.z = t * 0.5;
        selBeam.position.set(p.x, p.y + 15, p.z);
      }
    });

    var ctl = {
      setWard: function (v) { dome.mat.uniforms.power.value = clamp(v, 0, 1.4); },
      select: function (id) {
        selected = id && units[id] ? id : null;
        selRing.visible = selBeam.visible = !!selected;
        if (selected && !arguments[1]) { var p = worldPos(units[selected]); orbit.to(p, 30); }
      },
      focus: function (realm) {
        var map = { all: [new T.Vector3(0, 4, 0), 78, 0.58], starfall: [new T.Vector3(0, 22, 0), 70, 0.25], skies: [new T.Vector3(0, 10, 0), 52, 0.3], wilds: [new T.Vector3(0, 1, 0), 40, 0.55], deeps: [new T.Vector3(I.lake.x, -1, I.lake.z), 22, 0.75] };
        var m = map[realm] || map.all; orbit.to(m[0], m[1], m[2]);
      },
      sync: function (list, quiet) {
        var want = {};
        list.forEach(function (u) { want[u.id] = u; });
        Object.keys(units).forEach(function (id) {
          var w = want[id], cur = units[id];
          var key = w ? [+w.type, w.realm || K.REALM[+w.type], !!w.offline, !!w.building].join('|') : null;
          if (!w) ctl.remove(id, quiet);
          else if (key !== cur.key) { ctl.remove(id, true); ctl.add(w, true); }
        });
        list.forEach(function (u) { if (!units[u.id]) ctl.add(u, quiet); });
        if (selected && units[selected]) ctl.select(selected, true);
      },
      has: function (id) { return !!units[id]; },
      add: function (u, quiet) {
        var info = placeUnit(u);
        if (quiet) return u.id;
        st.scene.updateMatrixWorld(true);
        var p = worldPos(info);
        var disc = runeDisc(3.5, '#e8c872', 1); disc.position.set(p.x, p.y + 0.2, p.z); st.scene.add(disc);
        var t0 = performance.now();
        info.holder.scale.setScalar(0.01);
        var f = st.add(function () {
          var k = (performance.now() - t0) / 1600;
          disc.rotation.z += 0.05; disc.scale.setScalar(1 + k * 0.6); disc.material.opacity = 1 - k;
          info.holder.scale.setScalar(clamp(k * 1.5, 0.01, 1));
          if (k >= 1) { st.scene.remove(disc); st.remove(f); }
        });
        burst(p, { color: 0xe8c872, count: 160, speed: 7, up: true, grav: -3, swirl: 2, ring: 1.5 });
        burst(p, { color: 0x9ff4ff, count: 80, speed: 3, up: true, grav: 2 });
        return u.id;
      },
      remove: function (id, quiet) {
        var u = units[id]; if (!u) return;
        var p = worldPos(u);
        if (!quiet) burst(p, { color: 0xff7a4d, count: 120, speed: 6 });
        st.scene.remove(u.holder); roots.splice(roots.indexOf(u.holder), 1); delete units[id];
        if (selected === id) ctl.select(null);
      },
      rite: function (kind) {
        var find = function (type) { for (var id in units) if (units[id].type === type) return worldPos(units[id]); return new T.Vector3(0, 2, 0); };
        if (kind === 'delve') { var p = find(14); burst(p.add(new T.Vector3(0, 1, 0)), { color: 0xffc85a, count: 140, speed: 6, up: true, grav: -6 }); }
        else if (kind === 'brew') { p = find(15); burst(p.add(new T.Vector3(0, 2.5, 0)), { color: 0x7dffb0, count: 160, speed: 3, up: true, grav: 3, swirl: 3, ring: 0.8, life: 2.4 }); }
        else if (kind === 'tithe') { burst(new T.Vector3(0, 4, 0), { color: 0xe8c872, count: 260, speed: 10, up: true, grav: 6, spread: 0.15, life: 2.6, size: 0.8 }); }
        else if (kind === 'ward') { dome.mat.uniforms.flash.value = 1.2; }
        else if (kind === 'seek') { burst(new T.Vector3(0, 6, 0), { color: 0xc9a0ff, count: 220, speed: 12, grav: 0, life: 2 }); }
      },
      dispose: function () { orbit.dispose(); st.dispose(); }
    };
    return ctl;
  };

  /* ---- The Summoning Circle: one beast on the dais ---- */
  K.circle = function (canvas, o) {
    o = o || {};
    var st = Stage(canvas, { fogDensity: 0.01, bg: 0x0c0a1c });
    sky(st, { horizon: 0x6a3a7a, mid: 0x1c1440, auroraStrength: 0.8 });
    lights(st, { hemi: 0.7 });
    var dais = new T.Group(); st.scene.add(dais);
    var base = mesh(new T.CylinderGeometry(7, 7.6, 1.2, 9), M(0x3a3348), 0, -0.6, 0); dais.add(base);
    var top = mesh(new T.CylinderGeometry(6.2, 6.6, 0.4, 9), M(0x5a5070), 0, 0.15, 0); dais.add(top);
    var disc = runeDisc(6, '#e8c872', 0.7); disc.position.y = 0.37; dais.add(disc);
    var inner = runeDisc(3.4, '#5fd3b5', 0.6); inner.position.y = 0.38; dais.add(inner);
    for (var i = 0; i < 7; i++) {
      var a = i / 7 * TAU, pl = mesh(new T.BoxGeometry(0.6, 3 + (i % 2), 0.6), M(0x4a4060), Math.cos(a) * 8.5, 1.2, Math.sin(a) * 8.5); dais.add(pl);
      var fl = glowSprite(i % 2 ? 0x5fd3b5 : 0xe8c872, 2.2, 0.8); fl.position.set(Math.cos(a) * 8.5, 3.2 + (i % 2), Math.sin(a) * 8.5); dais.add(fl);
    }
    var I = isle({ radius: 9, seed: 3, rings: 14, segs: 40, under: 10, hills: 0.6 }); I.group.position.y = -1.4; I.group.scale.setScalar(1.1); st.scene.add(I.group);
    motes(st, { count: 160, box: 26, h: 14, y: 0, color: 0xc9a0ff });
    cloudSea(st, { y: -30 });
    var burst = Bursts(st);
    var orbit = Orbit(st, { dist: 24, el: 0.22, az: 0.4, target: new T.Vector3(0, 3, 0), min: 10, max: 60, auto: 0.12 });
    var cur = null, holder = new T.Group(); st.scene.add(holder);
    var pillar = new T.Mesh(new T.CylinderGeometry(2.4, 2.4, 40, 24, 1, true), G(0xe8c872, { t: true, o: 0, add: true, ds: true })); pillar.position.y = 20; st.scene.add(pillar);
    var flash = 0;
    function show(type) {
      if (cur) { holder.remove(cur.obj); }
      cur = beast(type);
      var flying = cur.flying, ty = +type;
      var s = ty >= 14 ? 1.1 : (ty === 2 ? 1.0 : ty === 11 ? 0.8 : 1.3);
      if (ty === 22) s = 0.45;
      cur.obj.scale.setScalar(s);
      cur.obj.position.y = flying ? 4.2 : 0.4;
      if (ty === 11 || ty === 12) cur.obj.position.y = 1.6;
      if (ty === 13) cur.obj.position.y = 0.4;
      if (ty === 17) cur.obj.position.y = 4;
      holder.add(cur.obj);
    }
    show(o.type || 1);
    st.add(function (t, dt) {
      if (cur) cur.update(t);
      holder.rotation.y = t * 0.25;
      disc.rotation.z = t * 0.1; inner.rotation.z = -t * 0.25;
      flash = Math.max(0, flash - dt * 0.6);
      pillar.material.opacity = flash * 0.5;
      disc.material.opacity = 0.6 + flash * 0.4;
    });
    return {
      show: show,
      summon: function (type) {
        flash = 1.2;
        burst(new T.Vector3(0, 0.6, 0), { color: 0xe8c872, count: 260, speed: 9, up: true, grav: -2, swirl: 3, ring: 3 });
        burst(new T.Vector3(0, 3, 0), { color: 0x5fd3b5, count: 140, speed: 5, grav: 1 });
        if (type) show(type);
        if (cur) { var target = cur.obj, s0 = target.scale.x, t0 = performance.now(); target.scale.setScalar(s0 * 0.02); var f = st.add(function () { var k = Math.min(1, (performance.now() - t0) / 1200), e = 1 - Math.pow(1 - k, 3); target.scale.setScalar(s0 * (0.02 + 0.98 * e)); if (k >= 1) st.remove(f); }); }
      },
      dispose: function () { orbit.dispose(); st.dispose(); }
    };
  };

  /* ---- The Sky Atlas: every warden's isle ---- */
  K.atlas = function (canvas, o) {
    o = o || {};
    var st = Stage(canvas, { fogDensity: 0.0022, bg: 0x090b1c });
    sky(st, { horizon: 0x3a2a6a, mid: 0x14123a, top: 0x05060f, auroraStrength: 0.9 });
    lights(st, { hemi: 1.1 });
    var covens = o.covens || [];
    var cols = o.colors || {};
    var burst = Bursts(st);
    var hubs = {};
    covens.forEach(function (c, i) {
      var a = i / covens.length * TAU + 0.3, d = i === 0 ? 0 : 300;
      var pos = new T.Vector3(Math.cos(a) * d, (i % 2) * 24 - 12, Math.sin(a) * d);
      var cr = crystal(cols[c] || 0xe8c872, 4.5); cr.position.copy(pos); st.scene.add(cr);
      var gl = glowSprite(cols[c] || 0xe8c872, 34, 0.45); gl.position.copy(pos).add(new T.Vector3(0, 4, 0)); st.scene.add(gl);
      var ring = runeDisc(12, '#' + new T.Color(cols[c] || 0xe8c872).getHexString(), 0.5); ring.position.copy(pos); st.scene.add(ring);
      hubs[c] = { pos: pos, cr: cr, ring: ring };
    });
    var geos = [];
    for (var i = 0; i < 6; i++) { var gi = isle({ radius: 2.6, seed: 60 + i, rings: 9, segs: 26, under: 7, hills: 0.8 }); geos.push(gi); }
    var roots = [], isles = [], linePos = [], lineCol = [], perCoven = {};
    (o.isles || []).forEach(function (w) { perCoven[w.coven] = (perCoven[w.coven] || 0) + 1; });
    (o.isles || []).forEach(function (w, idx) {
      var h = hashStr(w.id), r = rng(h);
      var hub = hubs[w.coven] || { pos: new T.Vector3() };
      var spread = 30 + Math.sqrt(perCoven[w.coven] || 1) * 7;
      var a = r() * TAU, d = 16 + Math.sqrt(r()) * spread;
      var p = hub.pos.clone().add(new T.Vector3(Math.cos(a) * d, (r() - 0.5) * (18 + spread * 0.35), Math.sin(a) * d));
      var gsrc = geos[h % geos.length];
      var g = new T.Group();
      var land = gsrc.land.clone(); g.add(land);
      var c = cols[w.coven] || 0xe8c872;
      var tree = r() < 0.5 ? pine(r, 0.6) : bloomTree(r, 0.6); tree.position.y = 0.4; g.add(tree);
      var beacon = glowSprite(w.you ? 0xffe7a0 : c, w.you ? 9 : 4, w.you ? 1 : 0.75); beacon.position.y = 2.8; g.add(beacon);
      g.position.copy(p); g.rotation.y = r() * TAU;
      g.userData.pick = idx;
      var s = w.you ? 1.6 : 0.8 + r() * 0.5; g.scale.setScalar(s);
      st.scene.add(g); roots.push(g);
      isles.push({ g: g, p: p, w: w, beacon: beacon, ph: r() * 10 });
      linePos.push(p.x, p.y - 1, p.z, hub.pos.x, hub.pos.y, hub.pos.z);
      var lc = new T.Color(c);
      lineCol.push(lc.r * 0.6, lc.g * 0.6, lc.b * 0.6, lc.r * 0.1, lc.g * 0.1, lc.b * 0.1);
    });
    var lg = new T.BufferGeometry();
    lg.setAttribute('position', new T.Float32BufferAttribute(linePos, 3));
    lg.setAttribute('color', new T.Float32BufferAttribute(lineCol, 3));
    var leys = new T.LineSegments(lg, new T.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.8, blending: T.AdditiveBlending, depthWrite: false, toneMapped: false }));
    st.scene.add(leys);
    motes(st, { count: 700, box: 520, h: 90, y: -45, color: 0xc9b8ff, size: 14 });
    var sel = runeDisc(5, '#e8c872', 1); sel.visible = false; st.scene.add(sel);
    var beam = new T.Mesh(new T.CylinderGeometry(0.8, 0.8, 120, 16, 1, true), G(0xe8c872, { t: true, o: 0.16, add: true, ds: true })); beam.visible = false; st.scene.add(beam);
    var pick = picker(st, function () { return roots; });
    var orbit = Orbit(st, { dist: 330, el: 0.6, az: 0.3, target: new T.Vector3(0, 0, 0), min: 20, max: 700, auto: 0.02, onTap: function (ndc) { var i = pick(ndc); if (i != null && o.onPick) o.onPick(i); } });
    var selected = -1, ride = null;
    st.add(function (t) {
      for (var i = 0; i < isles.length; i++) { var s = isles[i]; s.g.position.y = s.p.y + Math.sin(t * 0.5 + s.ph) * 0.8; }
      for (var c in hubs) { hubs[c].cr.rotation.y = t * 0.2; hubs[c].ring.rotation.z = t * 0.05; }
      if (selected >= 0) { var p = isles[selected].g.position; sel.position.set(p.x, p.y - 0.8, p.z); sel.rotation.z = t; beam.position.set(p.x, p.y + 60, p.z); }
      if (ride) ride(t);
    });
    var you = isles.findIndex(function (s) { return s.w.you; });
    var amber = new T.Color(0xffa040);
    return {
      // Isles holding unbrewed wildroot burn amber — brighter, and larger, the richer the prize.
      glowRich: function (ores) {
        for (var i = 0; i < isles.length; i++) {
          var o = ores[i] || 0, b = isles[i].beacon;
          if (isles[i].w.you) continue;
          if (!b.userData.base) b.userData.base = { color: b.material.color.clone(), scale: b.scale.x };
          if (o > 0) { b.material.color.copy(amber); b.scale.setScalar(b.userData.base.scale * (1.4 + Math.min(2.6, Math.log10(1 + o) * 1.6))); b.material.opacity = 1; }
          else { b.material.color.copy(b.userData.base.color); b.scale.setScalar(b.userData.base.scale); }
        }
      },
      select: function (i) {
        selected = i == null ? -1 : i;
        sel.visible = beam.visible = selected >= 0;
        if (selected >= 0) orbit.to(isles[selected].p, 34, 0.35);
        else orbit.to(new T.Vector3(), 330, 0.6);
      },
      ride: function (i) {
        if (you < 0 || i == null) return;
        var a = isles[you].p.clone(), b = isles[i].p.clone(), wy = dragon({ span: 5.2 }), t0 = -1;
        wy.obj.scale.setScalar(0.9); st.scene.add(wy.obj);
        var mid = a.clone().lerp(b, 0.5).add(new T.Vector3(0, 30, 0));
        orbit.to(mid, 120, 0.5);
        ride = function (t) {
          if (t0 < 0) t0 = t;
          var k = Math.min(1, (t - t0) / 5), e = k * k * (3 - 2 * k);
          var p = new T.Vector3().copy(a).multiplyScalar((1 - e) * (1 - e)).add(mid.clone().multiplyScalar(2 * e * (1 - e))).add(b.clone().multiplyScalar(e * e));
          var e2 = Math.min(1, e + 0.01), p2 = new T.Vector3().copy(a).multiplyScalar((1 - e2) * (1 - e2)).add(mid.clone().multiplyScalar(2 * e2 * (1 - e2))).add(b.clone().multiplyScalar(e2 * e2));
          wy.obj.position.copy(p); wy.obj.lookAt(p2); wy.update(t);
          if (k >= 1) { burst(b, { color: 0xe8c872, count: 200, speed: 8 }); st.scene.remove(wy.obj); ride = null; orbit.to(b, 48, 0.4); }
        };
      },
      dispose: function () { orbit.dispose(); st.dispose(); }
    };
  };

  /* ---- The Skirmish: two warbands across the gulf ---- */
  K.skirmish = function (canvas, o) {
    o = o || {};
    var st = Stage(canvas, { fogDensity: 0.005 });
    sky(st, { horizon: 0xd0705a, mid: 0x2a1a48, glow: 0xffc890, auroraStrength: 0.35 });
    lights(st, { moon: 0xffd8b0 });
    cloudSea(st, { y: -38, lit: 0xe8a8a0 });
    var burst = Bursts(st);
    var sides = { ours: { x: -26, isle: null }, theirs: { x: 26, isle: null } };
    var units = {}, roots = [];
    ['ours', 'theirs'].forEach(function (side, si) {
      var I = isle({ radius: 12, seed: si ? 44 : 17, lake: true, lakeAngle: si ? 0 : Math.PI, lakeSize: 0.34, rings: 20, segs: 60, under: 12 });
      dressIsle(I, { trees: 28, seed: si ? 8 : 9, avoid: [{ x: 0, z: 0, r: 8 }], crystals: 5, crystalColor: si ? 0xff7a8a : K.C.verdigris });
      I.group.position.x = sides[side].x;
      st.scene.add(I.group); st.add(I.update);
      sides[side].isle = I;
      var counts = { starfall: 0, skies: 0, wilds: 0, deeps: 0 };
      (o[side] || []).forEach(function (u) {
        var type = +u.type, b = beast(type), realm = u.realm || K.REALM[type];
        var holder = new T.Group(); holder.add(b.obj); holder.userData.pick = u.id;
        b.obj.scale.multiplyScalar((SCALE[type] || 0.6) * 0.9);
        var n = counts[realm]++, face = si ? -1 : 1, base = sides[side].x;
        var spot;
        if (realm === 'wilds') { spot = I.surface(4 * face - (n % 3) * 2.2 * face, -5 + n * 3.4); spot.x += base; }
        else if (realm === 'deeps') { spot = new T.Vector3(base + I.lake.x + (n - 1) * 1.6, -0.9, I.lake.z + (n % 2) * 1.6); }
        else if (realm === 'skies') { spot = new T.Vector3(base + 4 * face, 10 + (n % 2) * 2, -6 + n * 4.5); }
        else { spot = new T.Vector3(base + 2 * face, 21 + (n % 2) * 2.5, -7 + n * 5); }
        holder.position.copy(spot);
        holder.rotation.y = face > 0 ? Math.PI / 2 : -Math.PI / 2;
        st.scene.add(holder); roots.push(holder);
        units[u.id] = { b: b, holder: holder, base: spot.clone(), realm: realm, side: side, ph: Math.random() * 10, hit: 0 };
      });
    });
    var pick = picker(st, function () { return roots; });
    var orbit = Orbit(st, { dist: 78, el: 0.2, az: 0, target: new T.Vector3(0, 7, 0), min: 25, max: 150, onTap: function (ndc) { var id = pick(ndc); if (o.onPick) o.onPick(id); } });
    var marks = {};
    function mark(key, color) {
      var d = runeDisc(2.4, color, 0.95); d.visible = false; st.scene.add(d);
      var bm = new T.Mesh(new T.CylinderGeometry(0.4, 0.4, 24, 12, 1, true), G(new T.Color(color).getHex(), { t: true, o: 0.14, add: true, ds: true })); bm.visible = false; st.scene.add(bm);
      marks[key] = { d: d, bm: bm, id: null };
    }
    mark('a', '#e8c872'); mark('t', '#ff7a4d');
    var bolts = [];
    st.add(function (t, dt) {
      for (var id in units) {
        var u = units[id];
        u.b.update(t);
        if (u.dying != null) {
          u.dying += dt;
          u.holder.rotation.z += dt * 3; u.holder.position.y -= dt * 6; u.holder.scale.multiplyScalar(0.97);
          if (u.dying > 1.6) { st.scene.remove(u.holder); roots.splice(roots.indexOf(u.holder), 1); delete units[id]; }
          continue;
        }
        var bob = u.realm === 'wilds' || u.realm === 'deeps' ? 0 : Math.sin(t * 0.8 + u.ph) * 0.8;
        var shake = u.hit > 0 ? (Math.random() - 0.5) * u.hit : 0;
        u.hit = Math.max(0, u.hit - dt * 1.5);
        u.holder.position.set(u.base.x + shake, u.base.y + bob, u.base.z + shake);
      }
      for (var k in marks) {
        var m = marks[k];
        if (m.id && units[m.id]) {
          var p = units[m.id].holder.position;
          m.d.visible = m.bm.visible = true;
          m.d.position.set(p.x, p.y + 0.1, p.z); m.d.rotation.z = t * (k === 'a' ? 0.6 : -0.6);
          m.bm.position.set(p.x, p.y + 12, p.z);
        } else { m.d.visible = m.bm.visible = false; }
      }
      for (var i = bolts.length - 1; i >= 0; i--) {
        var b = bolts[i]; b.k += dt / b.dur;
        var e = Math.min(1, b.k);
        var p0 = b.a, p1 = b.c, p2 = b.b;
        var q = new T.Vector3().copy(p0).multiplyScalar((1 - e) * (1 - e)).add(p1.clone().multiplyScalar(2 * e * (1 - e))).add(p2.clone().multiplyScalar(e * e));
        b.s.position.copy(q); b.core.position.copy(q);
        for (var j = b.trail.length - 1; j > 0; j--) b.trail[j].copy(b.trail[j - 1]);
        b.trail[0].copy(q);
        var arr = b.tg.attributes.position.array;
        for (j = 0; j < b.trail.length; j++) { arr[j * 3] = b.trail[j].x; arr[j * 3 + 1] = b.trail[j].y; arr[j * 3 + 2] = b.trail[j].z; }
        b.tg.attributes.position.needsUpdate = true;
        if (b.k >= 1) {
          st.scene.remove(b.s); st.scene.remove(b.core); st.scene.remove(b.tp);
          if (b.miss) burst(p2, { color: 0xbfd8ff, count: 30, speed: 3 });
          else { burst(p2, { color: b.color, count: 140, speed: 8 }); if (units[b.to]) units[b.to].hit = 1.2; }
          bolts.splice(i, 1);
          if (b.done) b.done();
        }
      }
    });
    function centerOf(id) { var u = units[id]; if (!u) return null; var v = u.holder.position.clone(); v.y += u.realm === 'wilds' ? 1.6 : 0.6; return v; }
    var ctl = {
      mark: function (key, id) { if (marks[key]) marks[key].id = id; },
      strike: function (from, to, opt) {
        opt = opt || {};
        var a = centerOf(from), b = centerOf(to); if (!a || !b) { if (opt.done) opt.done(); return; }
        if (opt.miss) b = b.clone().add(new T.Vector3((Math.random() - 0.5) * 6, 4 + Math.random() * 4, (Math.random() - 0.5) * 6));
        var c = a.clone().lerp(b, 0.5).add(new T.Vector3(0, opt.guided ? 12 : 4, (Math.random() - 0.5) * 8));
        var color = opt.color || 0xffc04a;
        var s = glowSprite(color, 3.2, 1), core = new T.Mesh(new T.SphereGeometry(0.3, 8, 6), G(0xffffff));
        var tg = new T.BufferGeometry(), N = 24, trail = [];
        for (var i = 0; i < N; i++) trail.push(a.clone());
        tg.setAttribute('position', new T.BufferAttribute(new Float32Array(N * 3), 3));
        var tp = new T.Points(tg, new T.PointsMaterial({ map: softDot(), color: color, size: 1.0, transparent: true, depthWrite: false, blending: T.AdditiveBlending, toneMapped: false }));
        tp.frustumCulled = false;
        st.scene.add(s); st.scene.add(core); st.scene.add(tp);
        burst(a, { color: color, count: 40, speed: 3 });
        bolts.push({ s: s, core: core, tp: tp, tg: tg, trail: trail, a: a, b: b, c: c, k: 0, dur: opt.dur || 0.9, color: color, miss: opt.miss, to: to, done: opt.done });
      },
      fell: function (id) { if (units[id]) { units[id].dying = 0; burst(centerOf(id), { color: 0xff5a3a, count: 220, speed: 10, life: 2 }); } },
      view: function (which) {
        if (which === 'ours') orbit.to(new T.Vector3(-26, 8, 0), 50, 0.25, -0.6);
        else if (which === 'theirs') orbit.to(new T.Vector3(26, 8, 0), 50, 0.25, 0.6);
        else orbit.to(new T.Vector3(0, 7, 0), 78, 0.2, 0);
      },
      dispose: function () { orbit.dispose(); st.dispose(); }
    };
    return ctl;
  };

  /* ---- The Leyweave: mana river from wellspring to hold ---- */
  K.leyweave = function (canvas, o) {
    o = o || {};
    var st = Stage(canvas, { fogDensity: 0.004, bg: 0x0a0b1e });
    sky(st, { horizon: 0x2a5a7a, mid: 0x161a40, auroraStrength: 1.0, aurora1: 0x5fd3b5, aurora2: 0xe8c872 });
    lights(st, { hemi: 1 });
    var nodes = [
      { x: -42, y: 6, kind: 'well', c: 0xe8c872 },
      { x: -14, y: 2, kind: 'shrine', c: 0x5fd3b5 },
      { x: 14, y: 4, kind: 'shrine', c: 0x5fd3b5 },
      { x: 42, y: 0, kind: 'hold', c: 0xc9a0ff }
    ];
    nodes.forEach(function (n, i) {
      var I = isle({ radius: n.kind === 'well' ? 8 : 5.5, seed: 70 + i, rings: 14, segs: 44, under: 10, hills: 1 });
      dressIsle(I, { trees: n.kind === 'hold' ? 14 : 6, rocks: 4, crystals: 3, seed: 80 + i, avoid: [{ x: 0, z: 0, r: 3.5 }] });
      I.group.position.set(n.x, n.y, 0); st.scene.add(I.group);
      var top = n.kind === 'well' ? hallow(21, {}) : n.kind === 'hold' ? hallow(15, { scale: 0.9 }) : hallow(16, {});
      top.obj.position.set(n.x, n.y + I.heightAt(0, 0), 0); st.scene.add(top.obj); st.add(top.update);
      n.top = new T.Vector3(n.x, n.y + 4, 0);
    });
    var flows = [];
    for (var i = 0; i < nodes.length - 1; i++) {
      var a = nodes[i].top, b = nodes[i + 1].top, c = a.clone().lerp(b, 0.5).add(new T.Vector3(0, 9, 0));
      var curve = new T.QuadraticBezierCurve3(a, c, b);
      var tube = new T.Mesh(new T.TubeGeometry(curve, 48, 0.12, 6, false), G(0x5fd3b5, { t: true, o: 0.35, add: true }));
      st.scene.add(tube);
      var N = 60, pos = new Float32Array(N * 3), g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(pos, 3));
      var pts = new T.Points(g, new T.PointsMaterial({ map: softDot(), color: i === 0 ? 0xe8c872 : 0x7affe0, size: 1.1, transparent: true, depthWrite: false, blending: T.AdditiveBlending, toneMapped: false }));
      pts.frustumCulled = false;
      st.scene.add(pts);
      flows.push({ curve: curve, g: g, pos: pos, n: N, speed: 0.12 });
    }
    motes(st, { count: 260, box: 120, h: 40, y: -10, color: 0x9fe8ff });
    cloudSea(st, { y: -30 });
    var orbit = Orbit(st, { dist: 105, el: 0.18, az: 0, target: new T.Vector3(0, 4, 0), min: 40, max: 200, auto: 0 });
    var rate = 1, tithe = 0, burst = Bursts(st);
    st.add(function (t, dt) {
      for (var f = 0; f < flows.length; f++) {
        var fl = flows[f];
        for (var i = 0; i < fl.n; i++) {
          var k = ((i / fl.n) + t * fl.speed * rate) % 1;
          var p = fl.curve.getPoint(k);
          fl.pos[i * 3] = p.x + Math.sin(t * 3 + i) * 0.2; fl.pos[i * 3 + 1] = p.y + Math.cos(t * 2 + i) * 0.2; fl.pos[i * 3 + 2] = p.z;
        }
        fl.g.attributes.position.needsUpdate = true;
      }
    });
    return {
      setRate: function (r) { rate = clamp(r, 0.05, 4); },
      tithe: function () { burst(nodes[nodes.length - 1].top.clone(), { color: 0xe8c872, count: 200, speed: 8, up: true, grav: 2 }); burst(nodes[0].top.clone(), { color: 0xe8c872, count: 260, speed: 10, ring: 2, grav: 0 }); },
      dispose: function () { orbit.dispose(); st.dispose(); }
    };
  };

  /* ---- A small living portrait (a guide, a card): one beast in its own little sky ---- */
  K.portrait = function (canvas, o) {
    o = o || {};
    var size = o.size || 96;
    var renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(size, size, false);
    renderer.outputColorSpace = T.SRGBColorSpace;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    var scene = new T.Scene();
    var cam = new T.PerspectiveCamera(32, 1, 0.1, 100);
    cam.position.set(0, 0.6, o.dist || 6.2); cam.lookAt(0, 0.35, 0);
    scene.add(new T.HemisphereLight(0xc9b8ff, 0x1a1030, 1.6));
    var key = new T.DirectionalLight(0xffe7c4, 2.2); key.position.set(2, 3, 4); scene.add(key);
    var b = beast(o.type || 6);
    b.obj.scale.setScalar(o.scale || 1.05);
    if (o.tint != null) b.obj.traverse(function (m) {
      if (m.material && m.material.color && !m.isSprite) { var mat = m.material.clone(); mat.color.lerp(new T.Color(o.tint), 0.55); mat.opacity = 1; mat.transparent = false; m.material = mat; }
    });
    scene.add(b.obj);
    var halo = glowSprite(0xe8c872, 5, 0.35); halo.position.set(0, 0.4, -1); scene.add(halo);
    var raf = 0, t0 = performance.now();
    (function loop() {
      raf = requestAnimationFrame(loop);
      var t = (performance.now() - t0) / 1000;
      b.update(t * 0.6);
      b.obj.rotation.y = Math.sin(t * 0.5) * 0.35;
      halo.material.opacity = 0.25 + 0.12 * Math.sin(t * 1.7);
      renderer.render(scene, cam);
    })();
    return { dispose: function () { cancelAnimationFrame(raf); renderer.dispose(); } };
  };

  /* -------------------------------------------------- mount helper for pages */
  // Pages call WyrmKit.mount(kind, canvas, opts, cb): retries until THREE is ready.
  K.mount = function (kind, canvas, opts, cb) {
    var tries = 0;
    (function go() {
      if (!canvas || !canvas.isConnected || !(canvas.parentElement && canvas.parentElement.clientWidth)) {
        if (tries++ < 120) return setTimeout(go, 50);
      }
      try { var c = K[kind](canvas, opts); if (cb) cb(c); }
      catch (e) { console.error('WyrmKit mount failed', kind, e); }
    })();
  };

export default K;
