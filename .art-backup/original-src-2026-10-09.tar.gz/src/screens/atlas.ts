/* The Sky Atlas: the newest wardens on the ledger, each isle a real planet, drawn around its
 * coven's wellspring. Ride out signs a real MsgFleetMove. */
import { h, clear, toast } from '../core/dom';
import K from '../world/wyrmkit.js';
import { mountScene, type Ctx, type Screen } from './types';
import { topbar } from '../ui/frame';
import { omenSight, wardens, wardenName, type Sight, type Warden } from '../realm';
import { live } from '../chain/live';
import { guilds, type GuildEntry } from '../guild/directory';
import { empire } from '../game/empire';
import { act } from '../game/actions';
import { wallet } from '../wallet/wallet';
import { covenColor, covenName, retellError } from '../lore';
import { markPath } from '../ui/guide';

export function atlas(ctx: Ctx): Screen {
  const canvas = h('canvas');
  const bar = topbar('#/atlas', ctx.oath);
  const search = h('input', { id: 'warden-search', type: 'search', placeholder: 'Name, sigil or isle', autocomplete: 'off' }) as HTMLInputElement;
  const chips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Covens' });
  const list = h('ul', { class: 'list scroll-y', 'data-tut': 'atlas' });
  markPath('atlas');
  const foot = h('p', { class: 'faint', style: { margin: '0', fontSize: '12px' } });
  const card = h('div');
  const legend = h('footer', { class: 'glass row', style: { alignSelf: 'center', justifyContent: 'center', gap: '16px', padding: '10px 18px', borderRadius: '999px', fontSize: '13px' } });
  const el = h('div', { class: 'screen' }, h('div', { class: 'stage' }, canvas),
    h('div', { class: 'hud' }, bar.el,
      h('div', { class: 'cols through' },
        h('aside', { class: 'glass panel col-l', 'aria-label': 'Wardens' },
          h('div', { class: 'field', style: { marginTop: 0 } }, h('label', { for: 'warden-search' }, 'Find a warden'), search), chips, list, foot),
        card),
      legend));

  let all: Warden[] = [];
  let covens: string[] = [];
  let meta = new Map<string, GuildEntry>();
  let coven: string | null = null;
  let richOnly = false;
  let sight = new Map<string, Sight>();
  const oreOf = (w: Warden) => sight.get(w.id)?.ore ?? 0;
  const sleptFor = (w: Warden) => { const l = sight.get(w.id)?.lastAction ?? 0; return l && live.height ? live.height - l : 0; };
  let sel = -1;
  let scene: ReturnType<typeof mountScene<{ dispose(): void; select(i: number | null): void; ride(i: number): void; glowRich(o: number[]): void }>> | null = null;

  const name = (id: string) => covenName(id, meta.get(id)?.meta?.name);

  function pick(i: number | null) { sel = i ?? -1; scene?.get()?.select(i); paint(); }

  function paint() {
    const q = search.value.trim().toLowerCase();
    clear(chips);
    chips.append(h('button', { type: 'button', class: 'chip' + (richOnly ? ' on' : ''), 'aria-pressed': String(richOnly), 'data-tut': 'rich', onclick: () => { richOnly = !richOnly; paint(); } },
      h('span', { class: 'gem', style: { background: 'var(--root)', width: '8px', height: '8px' } }), 'Unbrewed wildroot', h('span', { class: 'n' }, String(all.filter((w) => oreOf(w) > 0 && w.id !== empire.commander?.playerId).length))));
    for (const c of covens) chips.append(h('button', { type: 'button', class: 'chip' + (coven === c ? ' on' : ''), 'aria-pressed': String(coven === c), onclick: () => { coven = coven === c ? null : c; paint(); } },
      h('span', { class: 'gem', style: { background: covenColor(c), width: '8px', height: '8px' } }), name(c)));
    clear(list);
    let shown = all.map((w, i) => ({ w, i })).filter(({ w }) => (!coven || w.guildId === coven) && (!richOnly || (oreOf(w) > 0 && w.id !== empire.commander?.playerId)) && (!q || wardenName(w).toLowerCase().includes(q) || w.id.includes(q) || w.planetId.includes(q)));
    if (richOnly) shown = shown.sort((a, b) => oreOf(b.w) - oreOf(a.w));
    for (const { w, i } of shown.slice(0, 300)) {
      const you = w.id === empire.commander?.playerId;
      list.append(h('li', null, h('button', { type: 'button', class: 'item' + (sel === i ? ' on' : ''), style: { minHeight: '46px' }, onclick: () => pick(i) },
        h('span', { class: 'l' }, h('span', { class: 'gem', style: { background: you ? '#fff1c4' : covenColor(w.guildId), boxShadow: `0 0 8px ${covenColor(w.guildId)}` } }), h('span', { class: 'nm', style: { fontSize: '15px' } }, you ? 'Your Hold' : wardenName(w))),
        oreOf(w) > 0 && !you ? h('span', { class: 'mono', style: { fontSize: '11px', color: 'var(--root)' } }, `${oreOf(w)} unbrewed`) : h('span', { class: 'mono faint', style: { fontSize: '11px' } }, w.planetId))));
    }
    foot.textContent = all.length ? `${shown.length} of ${all.length} wardens · newest on the ledger` : 'Reading the ledger…';
    clear(card);
    const w = all[sel];
    if (w) {
      const me = empire.commander;
      const you = w.id === me?.playerId;
      card.append(h('section', { class: 'glass panel rise', 'aria-label': 'Chosen isle', style: { flex: '0 1 360px', minWidth: '280px', padding: '20px' } },
        h('p', { class: 'eyebrow row', style: { color: covenColor(w.guildId), gap: '8px' } }, h('span', { class: 'gem', style: { background: covenColor(w.guildId), width: '8px', height: '8px' } }), name(w.guildId)),
        h('h1', { class: 'display', style: { fontSize: '36px', marginTop: '6px', overflowWrap: 'anywhere' } }, you ? 'Your Hold' : wardenName(w)),
        h('dl', { class: 'facts' },
          h('div', null, h('dt', null, 'Warden sigil'), h('dd', { class: 'mono' }, w.id)),
          h('div', null, h('dt', null, 'Isle'), h('dd', { class: 'mono' }, w.planetId)),
          h('div', null, h('dt', null, 'Coven'), h('dd', { class: 'mono' }, w.guildId || '—')),
          h('div', null, h('dt', null, 'Warband'), h('dd', { class: 'mono' }, w.fleetId || '—')),
          h('div', null, h('dt', null, 'Unbrewed wildroot'), h('dd', { style: { color: oreOf(w) > 0 ? 'var(--root)' : undefined } }, oreOf(w) > 0 ? `${oreOf(w)} ${oreOf(w) === 1 ? 'sheaf' : 'sheaves'}` : 'none')),
          h('div', null, h('dt', null, 'Last stirred'), h('dd', null, sleptFor(w) ? (sleptFor(w) > 14400 ? 'long asleep' : `${sleptFor(w).toLocaleString('en-US')} bells ago`) : '—'))),
        h('p', { style: { margin: '14px 0 0', fontSize: '15px', color: '#cfc5dd' } }, you ? 'Your own isle, drifting where the old sky set it.' : 'Somewhere on that shard a warden sleeps, or schemes. To you it floats here, a ride from your hold.'),
        h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '8px', marginTop: '16px' } },
          h('a', { class: 'btn', href: `#/hold/${w.id}`, style: { borderRadius: '14px', minHeight: '56px', borderColor: 'rgba(201,160,255,.5)' } }, 'Scry'),
          h('button', { type: 'button', class: 'btn', disabled: you, 'data-tut': 'ride', style: { borderRadius: '14px', minHeight: '56px', borderColor: 'rgba(232,200,114,.55)' }, onclick: () => rideOut(w) }, 'Ride out'),
          h('a', { class: 'btn', href: `#/skirmish/${w.id}`, style: { borderRadius: '14px', minHeight: '56px', borderColor: 'rgba(255,122,77,.6)', color: 'var(--ember-ink)' } }, 'Plunder')),
        h('button', { type: 'button', class: 'btn ghost block', style: { marginTop: '10px' }, onclick: () => pick(null) }, 'Back to the whole sky')));
    }
    clear(legend);
    for (const c of covens) legend.append(h('span', { class: 'row', style: { gap: '6px' } }, h('span', { class: 'gem', style: { background: covenColor(c) } }), name(c), h('span', { class: 'mono faint', style: { fontSize: '11px' } }, c)));
  }

  function rideOut(w: Warden) {
    const p = empire.commander;
    if (!p) { toast('Swear the oath first: you have no warband to ride.', 'warn', 5000, { label: 'Oath', run: ctx.oath }); return; }
    if (!wallet.unlocked) { toast('Your soulstone is sealed.', 'warn', 5000, { label: 'Unseal', run: ctx.oath }); return; }
    try {
      act.fleetMove(p, w.planetId);
      scene?.get()?.ride(sel);
      toast(`Your warband rides for isle ${w.planetId}. When it lands, the plunder chant can begin.`, 'player', 6000, { label: 'To war', run: () => ctx.go(`#/skirmish/${w.id}`) });
    } catch (e) { toast(retellError((e as Error).message), 'enemy'); }
  }

  search.addEventListener('input', paint);
  Promise.all([wardens(), guilds().catch(() => [] as GuildEntry[]), omenSight().catch(() => new Map<string, Sight>())]).then(([ws, gs, sg]) => {
    sight = sg;
    meta = new Map(gs.map((g) => [g.id, g]));
    const me = empire.commander;
    all = ws.slice();
    if (me && me.planetId && !all.some((w) => w.id === me.playerId)) all.unshift({ id: me.playerId, name: me.name, guildId: me.guildId, planetId: me.planetId, fleetId: me.fleetId, address: me.address });
    covens = [...new Set(all.map((w) => w.guildId).filter(Boolean))].sort();
    const colors: Record<string, number> = {};
    for (const c of covens) colors[c] = parseInt(covenColor(c).slice(1), 16);
    scene = mountScene(canvas, (c) => K.atlas(c, {
      covens, colors, isles: all.map((w) => ({ id: w.id, coven: w.guildId, you: w.id === me?.playerId })), onPick: (i: number) => pick(i),
    }), (c) => { c.glowRich(all.map((w) => oreOf(w))); if (ctx.param) { const i = all.findIndex((w) => w.id === ctx.param); if (i >= 0) pick(i); } });
    paint();
  }).catch((e) => { foot.textContent = 'The ledger did not answer: ' + (e as Error).message; });
  paint();
  return { el, title: 'Sky Atlas', leave: () => { scene?.dispose(); bar.dispose(); } };
}
