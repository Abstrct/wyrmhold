/* The Hold: your isle, read live from the ledger. Every beast and hallow is a struct you own;
 * every button signs a real transaction through the rite queue. `#/hold/<playerId>` watches
 * another warden's hold, read-only. */
import { h, clear, toast, confirmBox } from '../core/dom';
import K from '../world/wyrmkit.js';
import { mountScene, type Ctx, type Screen } from './types';
import { topbar, hearts } from '../ui/frame';
import { chantsPanel, chroniclePanel } from '../ui/chants';
import { empire, type OwnedStruct, type PlayerState } from '../game/empire';
import { act, actionBlock, buildBlock, exploreConfirmed, verbsFor } from '../game/actions';
import { wallet } from '../wallet/wallet';
import { txq } from '../wallet/queue';
import { markPath } from '../ui/guide';
import { STRUCT_TYPES, typeOf, type Ambit } from '../data/catalogue';
import { num } from '../chain/lcd';
import { live } from '../chain/live';
import { AMBIT_OF_REALM, HALLOW_COLOR, REALMS, REALM_COLOR, REALM_NAME, WARD_CRAFT, beastName, fmtMana, lore, reachOf, retell, retellError, type Realm } from '../lore';
import { freeCircle, owned, raidersAt, realmOf, unitsOf } from '../realm';

const VERB_NAME: Record<string, string> = { on: 'Awaken', off: 'Slumber', stealth: 'Veil', unstealth: 'Drop veil', undefend: 'Stand down', cancel: 'Abandon the summoning' };

export function hold(ctx: Ctx): Screen {
  const watching = ctx.param && !wallet.byPlayer(ctx.param) ? ctx.param : null;
  if (watching) empire.watch(watching);
  const player = (): PlayerState | null => (watching ? empire.players.get(watching) ?? null : ctx.param ? empire.players.get(ctx.param) ?? null : empire.commander);

  let sel: string | null = null;
  let filter: Realm | 'all' | 'hallows' = 'all';
  let first = true;
  let raiders: { fleetId: string; owner: string }[] = [];
  let raidCheckAt = 0;
  const checkRaiders = () => {
    const p = player();
    if (!p?.planet || Date.now() - raidCheckAt < 4000) return;
    raidCheckAt = Date.now();
    void raidersAt(p.planet).then((r) => { if (JSON.stringify(r) !== JSON.stringify(raiders)) { raiders = r; paint(); } });
  };

  const canvas = h('canvas');
  const bar = topbar('#/hold', ctx.oath, { meters: true });
  const chants = chantsPanel();
  chants.el.setAttribute('data-tut', 'chants');
  const chron = chroniclePanel((j) => { const p = player(); return !!p && j.playerId === p.playerId; });
  const omens = h('div', { class: 'stack', style: { alignItems: 'center' } });
  const filters = h('div', { class: 'chips', role: 'group', 'aria-label': 'Filter by realm' });
  const roster = h('ul', { class: 'list scroll-y' });
  const rosterHead = h('div', { class: 'row between' });
  const card = h('section', { class: 'glass panel', 'aria-label': 'Chosen beast' });
  const rites = h('nav', { class: 'glass rites', 'aria-label': 'Rites' });
  const banner = h('div');

  const el = h('div', { class: 'screen' },
    h('div', { class: 'stage' }, canvas),
    h('div', { class: 'hud' }, bar.el, banner, omens,
      h('div', { class: 'cols through' },
        h('aside', { class: 'glass panel col-l', 'aria-label': 'Warband' }, rosterHead, filters, roster),
        h('div', { class: 'col-r' }, card, chants.el, chron.el)),
      rites));

  const scene = mountScene(canvas, (c) => K.hold(c, { units: [], onPick: (id: string | null) => pick(id) }), () => paint());

  function pick(id: string | null) {
    sel = id; scene.get()?.select(id);
    const p = player();
    if (id && p && empire.commands(p.playerId) && p.structs.get(id)?.typeId === 1) markPath('wyrm');
    paint();
  }

  /** Run a rite, or say why it can't be spoken. */
  function rite(p: PlayerState, run: () => unknown, needsGrid = true) {
    if (!empire.commands(p.playerId)) { toast('This hold is not yours to command.', 'warn'); return; }
    if (!wallet.unlocked) { toast('Your soulstone is sealed.', 'warn', 5000, { label: 'Unseal', run: ctx.oath }); return; }
    const why = needsGrid ? actionBlock(p) : null;
    if (why) { toast(retellError(why), 'enemy', 5000); return; }
    try { run(); } catch (e) { toast(retellError((e as Error).message), 'enemy', 6000); }
  }

  function stateOf(s: OwnedStruct): [string, string] {
    if (!s.built) return ['Being summoned', 'var(--gold)'];
    if (!s.online) return ['Slumbering', 'var(--faint)'];
    if (s.hidden) return ['Veiled', 'var(--violet)'];
    if (s.protectedStructIndex) return ['On guard', 'var(--violet)'];
    return ['Awake', '#7dffb0'];
  }

  function paintOmens(p: PlayerState | null) {
    clear(omens);
    const omen = (tone: 'ember' | 'gold' | 'teal', text: string, action?: [string, () => void]) => omens.append(h('div', { role: 'status', class: 'glass row', style: {
      padding: '8px 10px 8px 16px', borderRadius: '999px', fontSize: '15px', flexWrap: 'nowrap',
      borderColor: tone === 'ember' ? 'rgba(255,122,77,.55)' : tone === 'gold' ? 'rgba(232,200,114,.5)' : 'rgba(95,211,181,.5)',
      background: tone === 'ember' ? 'rgba(60,24,18,.82)' : undefined, color: tone === 'ember' ? 'var(--ember-ink)' : undefined,
    } }, h('span', null, text), action ? h('button', { type: 'button', class: 'btn small', onclick: action[1] }, action[0]) : null));
    if (!p) return;
    const mine = empire.commands(p.playerId);
    const wyrmAlive = [...p.structs.values()].some((s) => s.typeId === 1 && !s.destroyed);
    if (p.planetId && !wyrmAlive && mine) omen('ember', 'Your Elder Wyrm has fallen. Until a new one hatches, your hold lies open to any raider.', ['Hatch anew', () => {
      const t = typeOf(1);
      if (!t) return;
      if (p.capacity + p.connectionCapacity - p.load - p.structsLoad < BigInt(t.buildDraw)) { toast('Not enough spare mana to hatch a Wyrm. Let something slumber, or feed a spring.', 'warn', 6000); return; }
      rite(p, () => act.build(p, t, 'land', 0), false);
      toast('An egg is laid in the Wilds. The hatching chant begins as soon as the circle lands.', 'player', 5000);
    }]);
    for (const r of raiders) omen('ember', `Raiders hang over your isle — warden ${r.owner}’s warband. Fell their Elder Wyrm and the plunder breaks.`, mine ? ['Defend', () => ctx.go(`#/skirmish/${r.owner}`)] : undefined);
    if (!p.online) omen('ember', 'Your leylines are overdrawn: every beast gutters until load fits the flow. Slumber something, or feed a spring.');
    if (p.ore > 0) omen('ember', p.ore === 1 ? 'A sheaf of wildroot lies unbrewed. Raiders can plunder it until the Cauldron draws out its alpha.' : `${p.ore} sheaves of wildroot lie unbrewed. Raiders can plunder them until the Cauldron draws out their alpha.`, owned(p, 15) || !mine ? undefined : ['Summon a Cauldron', () => summonDialog(p, 15)]);
    if (p.fleet?.status === 'away') omen('gold', `Your warband is abroad at isle ${p.fleet.locationId}. Your hold has no beasts to defend it.`, mine ? ['Ride home', () => rite(p, () => act.fleetMove(p, p.planetId), false)] : undefined);
    const ground = num(p.planet?.gridAttributes?.ore);
    if (!p.planetId || (p.planet && ground <= 0 && p.ore === 0)) omen('teal', p.planetId ? 'Your isle is spent: no wildroot left in its marrow.' : 'You hold no isle yet.', mine ? ['Seek a new isle', () => rite(p, () => exploreConfirmed(p), false)] : undefined);
    else if (ground > 0 && !owned(p, 14) && mine) omen('teal', `Your isle still holds ${ground} sheaves of wildroot. A Root Delver would lift them.`, ['Summon a Delver', () => summonDialog(p, 14)]);
  }

  function paintRoster(p: PlayerState | null) {
    clear(rosterHead); clear(filters); clear(roster);
    const structs = p ? [...p.structs.values()].filter((s) => !s.destroyed && s.type) : [];
    rosterHead.append(h('h2', { class: 'display' }, watching ? `${p?.name || watching}’s warband` : 'Warband'), h('span', { class: 'mono faint', style: { fontSize: '12px' } }, `${structs.length} bound`));
    const count = (f: typeof filter) => structs.filter((s) => f === 'all' || (f === 'hallows' ? s.type!.category === 'planet' : s.type!.category === 'fleet' && realmOf(s) === f)).length;
    const opts: [typeof filter, string, string][] = [['all', 'All', HALLOW_COLOR], ...REALMS.map((r) => [r, REALM_NAME[r], REALM_COLOR[r]] as [Realm, string, string]), ['hallows', 'Hallows', HALLOW_COLOR]];
    for (const [k, label, color] of opts) filters.append(h('button', { type: 'button', class: 'chip' + (filter === k ? ' on' : ''), 'aria-pressed': String(filter === k), onclick: () => {
      filter = k; scene.get()?.focus(k === 'hallows' ? 'wilds' : k); paint();
    } }, h('span', { class: 'gem', style: { background: color, width: '8px', height: '8px' } }), label, h('span', { class: 'n' }, String(count(k)))));
    if (!p) { roster.append(h('li', null, h('p', { class: 'empty' }, watching ? 'Reading their hold from the ledger…' : 'No warden is bound to this soulstone yet.'))); return; }
    const shown = structs.filter((s) => filter === 'all' || (filter === 'hallows' ? s.type!.category === 'planet' : s.type!.category === 'fleet' && realmOf(s) === filter))
      .sort((a, b) => (a.type!.category === 'planet' ? 1 : 0) - (b.type!.category === 'planet' ? 1 : 0) || a.typeId - b.typeId);
    if (!shown.length) roster.append(h('li', null, h('p', { class: 'empty', style: { fontSize: '15px' } }, 'None bound in this realm.')));
    for (const s of shown) {
      const [state, color] = stateOf(s);
      const hallow = s.type!.category === 'planet';
      const away = !hallow && p.fleet?.status === 'away';
      const gem = hallow ? HALLOW_COLOR : REALM_COLOR[realmOf(s)];
      roster.append(h('li', null, h('button', { type: 'button', class: 'item' + (sel === s.id ? ' on' : ''), 'data-tut': s.typeId === 1 ? 'wyrm' : null, onclick: () => pick(s.id) },
        h('span', { class: 'l' }, h('span', { class: 'gem', style: { background: gem, boxShadow: `0 0 10px ${gem}` } }),
          h('span', { style: { minWidth: '0' } }, h('span', { class: 'nm' }, beastName(s.typeId)),
            h('span', { class: 'sub', style: { color } }, (hallow ? 'Hallow' : REALM_NAME[realmOf(s)]) + ' · ' + (away ? 'Riding abroad' : state)))),
        h('span', { class: 'hearts', 'aria-label': `Vigor ${s.health} of ${s.type!.maxHealth}` }, hearts(s.health, s.type!.maxHealth)))));
    }
  }

  function paintCard(p: PlayerState | null) {
    clear(card);
    const s = p && sel ? p.structs.get(sel) : undefined;
    if (!p || !s || !s.type) {
      card.append(h('p', { class: 'empty' }, p ? 'Touch a beast or hallow on your isle, or choose one from the warband.' : watching ? 'Reading the ledger…' : 'Swear the oath and your Elder Wyrm will hatch here.'),
        !p && !watching ? h('button', { type: 'button', class: 'btn gold', style: { marginTop: '12px' }, onclick: ctx.oath }, 'Swear the oath') : '');
      return;
    }
    const t = s.type, L = lore(s.typeId), hallow = t.category === 'planet';
    const [state, color] = stateOf(s);
    const reach = [...new Set([...reachOf(t.primaryWeaponAmbits), ...reachOf(t.secondaryWeaponAmbits)])];
    const mine = empire.commands(p.playerId);
    card.append(
      h('div', { class: 'row between', style: { alignItems: 'flex-start', flexWrap: 'nowrap' } },
        h('div', null,
          h('p', { class: 'eyebrow', style: { color: hallow ? HALLOW_COLOR : REALM_COLOR[realmOf(s)] } }, `${hallow ? 'Hallow' : REALM_NAME[realmOf(s)]} · ${s.id}`),
          h('h3', { class: 'display', style: { fontSize: '30px', marginTop: '4px' } }, L.name),
          h('p', { class: 'italic', style: { margin: '4px 0 0' } }, L.epithet)),
        h('span', { class: 'hearts', style: { fontSize: '16px' } }, hearts(s.health, t.maxHealth))),
      h('dl', { class: 'facts' },
        h('div', null, h('dt', null, 'State'), h('dd', { style: { color } }, state)),
        h('div', null, h('dt', null, 'Mana draw'), h('dd', null, fmtMana(t.passiveDraw))),
        h('div', null, h('dt', null, 'Strikes into'), h('dd', null, s.typeId === 1 ? 'Its own realm' : reach.length ? reach.map((r) => REALM_NAME[r]).join(', ') : '—')),
        h('div', null, h('dt', null, 'Ward-craft'), h('dd', null, WARD_CRAFT[t.unitDefenses] || '—'))),
      h('p', { style: { margin: '12px 0 0', fontSize: '15px', color: '#cfc5dd' } }, L.tale));
    if (!mine) { card.append(h('p', { class: 'faint', style: { marginTop: '12px', fontSize: '14px' } }, 'You are watching. Only its warden can command it.')); return; }
    const row = h('div', { class: 'row', style: { marginTop: '14px' } });
    for (const v of verbsFor(p, s)) row.append(h('button', { type: 'button', class: 'btn small', title: retellError(v.hint), onclick: () => rite(p, v.run, v.id !== 'off' && v.id !== 'cancel') },
      VERB_NAME[v.id] || retell(v.label), v.cost ? h('span', { class: 'cost' }, `${v.cost} breath`) : null));
    if (s.built && t.generatingRate > 0) row.append(h('button', { type: 'button', class: 'btn small', onclick: () => feedDialog(p, s) }, 'Feed alpha'));
    if (s.built && !hallow && s.typeId !== 1 && !s.protectedStructIndex) row.append(h('button', { type: 'button', class: 'btn small', onclick: () => guardDialog(p, s) }, 'Guard…', h('span', { class: 'cost' }, `${t.defendChangeCharge} breath`)));
    if (!hallow) row.append(h('a', { class: 'btn small', href: '#/skirmish', style: { borderColor: 'rgba(255,122,77,.5)', color: 'var(--ember-ink)' } }, 'Lead to war'));
    if (s.built && s.typeId !== 1) row.append(h('button', { type: 'button', class: 'btn small ghost', style: { color: 'var(--ember-ink)' }, onclick: async () => {
      if (await confirmBox(`Banish the ${L.name}?`, 'It is released for good. Its circle frees for another summoning.', 'Banish')) rite(p, () => act.trash(p, s));
    } }, 'Banish'));
    card.append(row);
    if (s.typeId === 1 && s.built) {
      card.append(h('div', { role: 'group', 'aria-label': 'Soar to a realm', style: { marginTop: '12px', paddingTop: '12px', borderTop: '1px solid rgba(243,235,221,.1)' } },
        h('p', { class: 'label', style: { margin: '0 0 8px' } }, `Soar to · ${t.moveCharge} breath`),
        h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: '6px' } }, ...REALMS.map((r) => {
          const here = realmOf(s) === r;
          return h('button', { type: 'button', class: 'chip' + (here ? ' on' : ''), 'aria-pressed': String(here), style: { justifyContent: 'center', minHeight: '40px', borderColor: here ? REALM_COLOR[r] : undefined },
            onclick: () => { if (!here) rite(p, () => act.move(p, s, 'fleet', AMBIT_OF_REALM[r], 0)); } }, REALM_NAME[r]);
        }))));
    }
  }

  function paintRites(p: PlayerState | null) {
    clear(rites);
    const mine = !!p && empire.commands(p.playerId);
    const btn = (label: string, sub: string, color: string, run: () => void, disabled = false, tut?: string) =>
      h('button', { type: 'button', class: 'rite', disabled, 'data-tut': tut || null, onclick: run }, h('b', { style: { color } }, label), h('small', null, sub));
    if (!p || !mine) {
      rites.append(watching
        ? h('a', { class: 'rite', href: '#/skirmish/' + (p?.playerId || watching) }, h('b', { style: { color: 'var(--ember)' } }, 'Plan a raid'), h('small', null, 'on this hold'))
        : btn('Swear the oath', 'bind · swear · seek', 'var(--gold)', ctx.oath));
      rites.append(h('a', { class: 'rite', href: '#/atlas' }, h('b', { style: { color: 'var(--violet)' } }, 'Sky Atlas'), h('small', null, 'every warden')));
      return;
    }
    rites.append(
      btn('Summon', '8 breath', 'var(--gold)', () => summonDialog(p), false, 'summon'),
      btn('Seek Isle', p.planetId ? 'when spent' : 'begin here', 'var(--violet)', () => rite(p, () => exploreConfirmed(p), false), false, 'seek'),
      p.fleet?.status === 'away'
        ? btn('Ride Home', `from ${p.fleet.locationId}`, 'var(--sky)', () => rite(p, () => act.fleetMove(p, p.planetId), false))
        : h('a', { class: 'rite', href: '#/atlas' }, h('b', { style: { color: 'var(--sky)' } }, 'Ride Out'), h('small', null, 'choose an isle')),
      h('a', { class: 'rite', href: '#/skirmish' }, h('b', { style: { color: 'var(--ember)' } }, 'Skirmish'), h('small', null, 'strike & plunder')),
      h('a', { class: 'rite', href: '#/bestiary' }, h('b', { style: { color: 'var(--verdigris)' } }, 'Bestiary'), h('small', null, 'know your beasts')));
  }

  function summonDialog(p: PlayerState, only?: number) {
    const ch = empire.charge(p);
    const list = h('div', { class: 'grid-cards scroll-y', style: { padding: '4px 2px', maxHeight: '60vh' } });
    for (const t of STRUCT_TYPES) {
      if (t.id === 1 || (only && t.id !== only)) continue;
      const limit = t.buildLimit && owned(p, t.id) >= t.buildLimit;
      const circle = freeCircle(p, t);
      const why = limit ? 'Only one may be bound to a warden.' : !circle ? 'No free circle in a realm it can stand in.' : buildBlock(p, t);
      const L = lore(t.id), hallow = t.category === 'planet';
      const realms = REALMS.filter((r) => t.possibleAmbit & { starfall: 16, skies: 8, wilds: 4, deeps: 2 }[r]);
      list.append(h('button', { type: 'button', class: 'card-btn', disabled: !!why, onclick: () => {
        veil.remove();
        rite(p, () => act.build(p, t, circle!.ambit as Ambit, circle!.slot));
        toast(`The circle is drawn for the ${L.name}. The chant begins once the summoning lands.`, 'player', 4500);
      } },
      h('span', { class: 'row between' }, h('b', null, L.name), h('span', { class: 'label', style: { color: hallow ? HALLOW_COLOR : REALM_COLOR[realms[0]] } }, hallow ? 'Hallow' : realms.map((r) => REALM_NAME[r]).join(' · '))),
      h('span', { class: 'muted', style: { fontSize: '13px' } }, L.epithet),
      h('span', { class: 'row between mono', style: { fontSize: '12px', color: 'var(--ink-2)' } }, h('span', null, `${fmtMana(t.buildDraw)} mana`), h('span', null, `chant ${t.buildDifficulty}`), h('span', { style: { color: ch >= t.buildCharge ? 'var(--verdigris)' : 'var(--root)' } }, `${t.buildCharge} breath`)),
      why ? h('span', { class: 'why' }, retellError(why)) : null));
    }
    const veil = h('div', { class: 'veil', onclick: (e: Event) => { if (e.target === veil) veil.remove(); } },
      h('section', { class: 'scroll wide', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Summon' },
        h('div', { class: 'row between', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } },
          h('div', null, h('h2', null, 'Summon'), h('p', { style: { margin: '4px 0 12px', color: 'var(--muted)' } },
            `Each summoning claims its mana the moment the circle is drawn. Spare mana now: ${fmtMana(p.capacity + p.connectionCapacity - p.load - p.structsLoad)}. Breath: ${ch}.`)),
          h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Close', onclick: () => veil.remove() }, '✕')),
        list));
    document.body.append(veil);
  }

  function feedDialog(p: PlayerState, s: OwnedStruct) {
    const amt = h('input', { id: 'feed-amt', type: 'number', min: '0.001', step: '0.001', value: '1' }) as HTMLInputElement;
    const veil = h('div', { class: 'veil' }, h('section', { class: 'scroll', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Feed alpha' },
      h('h2', null, `Feed the ${beastName(s.typeId)}`),
      h('p', null, `Alpha fed here becomes mana flow for your hold, for good. You hold ${(Number(p.alpha) / 1e6).toLocaleString('en-US')} g.`),
      h('div', { class: 'field' }, h('label', { for: 'feed-amt' }, 'Alpha to feed'), amt),
      h('div', { class: 'row end', style: { marginTop: '16px' } },
        h('button', { type: 'button', class: 'btn ghost', onclick: () => veil.remove() }, 'Not now'),
        h('button', { type: 'button', class: 'btn gold', onclick: () => {
          const g = Number(amt.value);
          if (!(g > 0)) return;
          const u = BigInt(Math.round(g * 1e6));
          if (u > p.alpha) { toast('You do not hold that much alpha.', 'warn'); return; }
          veil.remove(); rite(p, () => act.infuseGenerator(p, s, u), false);
        } }, 'Feed it'))));
    document.body.append(veil);
  }

  function guardDialog(p: PlayerState, s: OwnedStruct) {
    const allies = [...p.structs.values()].filter((x) => x.id !== s.id && !x.destroyed && x.built);
    const veil = h('div', { class: 'veil', onclick: (e: Event) => { if (e.target === veil) veil.remove(); } }, h('section', { class: 'scroll', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Guard' },
      h('h2', null, `Whom shall the ${beastName(s.typeId)} guard?`),
      h('p', null, 'A guard steps in front of blows aimed at its ward, when it can reach them.'),
      h('div', { class: 'stack scroll-y', style: { maxHeight: '50vh' } }, ...allies.map((a) => h('button', { type: 'button', class: 'choice', onclick: () => { veil.remove(); rite(p, () => act.defend(p, s, a.id)); } },
        h('span', null, beastName(a.typeId), h('small', null, `${a.type?.category === 'planet' ? 'Hallow' : REALM_NAME[realmOf(a)]} · ${a.id}`)), h('span', { class: 'hearts' }, hearts(a.health, a.type?.maxHealth || 0)))))));
    document.body.append(veil);
  }

  function paintBanner(p: PlayerState | null) {
    clear(banner);
    if (watching) banner.append(h('div', { class: 'glass row', style: { alignSelf: 'center', padding: '8px 16px', borderRadius: '999px', margin: '0 auto', width: 'fit-content' } },
      h('span', { class: 'italic' }, `Watching ${p?.name || watching}’s hold · isle ${p?.planetId || '…'}`), h('a', { href: '#/hold' }, 'Back to your own')));
    else if (!p && wallet.state !== 'empty' && wallet.active?.playerId) banner.append(h('p', { class: 'italic', style: { textAlign: 'center' } }, 'Reading your hold from the ledger…'));
  }

  function paint() {
    const p = player();
    checkRaiders();
    paintBanner(p); paintOmens(p); paintRoster(p); paintCard(p); paintRites(p);
    const ctl = scene.get();
    if (ctl && p) {
      ctl.sync(unitsOf(p), first);
      first = false;
      const shield = num(p.planet?.planetAttributes?.planetaryShield);
      ctl.setWard(Math.min(1.4, shield / 125));
    }
  }

  // When a rite of this hold lands, the isle answers.
  const onLanded = txq.onSettled((j) => {
    const p = player();
    if (j.status !== 'success' || !p || j.playerId !== p.playerId) return;
    const urls = j.msgs.map((m) => m.typeUrl).join();
    const ctl = scene.get();
    if (!ctl) return;
    if (/OreMinerComplete/.test(urls)) ctl.rite('delve');
    if (/OreRefineryComplete/.test(urls)) ctl.rite('brew');
    if (/GeneratorInfuse/.test(urls)) ctl.rite('tithe');
    if (/PlanetExplore/.test(urls)) ctl.rite('seek');
    if (/DefenseSet|StealthActivate/.test(urls)) ctl.rite('ward');
  });
  const offs = [empire.onChange(paint), wallet.onChange(paint), live.onBlock(() => { /* breath ticks */ }), onLanded];
  paint();

  return {
    el, title: watching ? 'Watching a hold' : 'The Hold',
    leave: () => { offs.forEach((f) => f()); scene.dispose(); bar.dispose(); chants.dispose(); chron.dispose(); if (watching) empire.unwatch(watching); document.querySelectorAll('.veil').forEach((v) => v.remove()); },
  };
}

