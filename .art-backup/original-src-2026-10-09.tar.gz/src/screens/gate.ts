/* The Gate: the title vista, the invitation, and the wardens abroad (real players, live). */
import { h } from '../core/dom';
import K from '../world/wyrmkit.js';
import { mountScene, type Ctx, type Screen } from './types';
import { topbar, icon, ICON } from '../ui/frame';
import { wallet } from '../wallet/wallet';
import { wardens, wardenName } from '../realm';
import { STRUCT_TYPES } from '../data/catalogue';
import { playPrologue, prologueSeen } from '../ui/prologue';

export function gate(ctx: Ctx): Screen {
  const canvas = h('canvas');
  const bar = topbar(ctx.route, ctx.oath);
  const ticker = h('div', null, h('span', { class: 'italic' }, 'Listening for wardens…'));
  const count = h('dd', { class: 'display', style: { fontSize: '34px', margin: '4px 0 0' } }, '—');

  const enter = h('a', { class: 'btn gold', href: '#/hold', style: { minHeight: '52px', padding: '0 28px', fontSize: '18px' },
    onclick: (e: Event) => { if (wallet.state === 'empty') { e.preventDefault(); ctx.oath(); } } },
  wallet.state === 'empty' ? 'Swear the oath' : 'Enter your Hold', icon(ICON.arrow));

  const stat = (k: string, v: Node | string) => h('div', { style: { borderTop: '1px solid rgba(232,200,114,.4)', paddingTop: '10px' } },
    h('dt', { class: 'label' }, k), typeof v === 'string' ? h('dd', { class: 'display', style: { fontSize: '34px', margin: '4px 0 0' } }, v) : v);

  const el = h('div', { class: 'screen' },
    h('div', { class: 'stage' }, canvas),
    h('div', { class: 'gate-shade' }),
    h('div', { class: 'hud gate-hud' }, bar.el),
    h('main', { class: 'gate-main' },
      h('p', { class: 'eyebrow rise' }, 'When the sky broke, alpha fell like rain'),
      h('h1', { class: 'gate-title rise', style: { animationDelay: '.15s' } }, 'Wyrmhold'),
      h('p', { class: 'rise', style: { margin: '22px 0 0', fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(22px, 2.6vw, 32px)', animationDelay: '.3s' } }, 'Bind beasts. Brew alpha. Hold the sky.'),
      h('p', { class: 'rise', style: { margin: '18px 0 0', fontSize: '19px', color: '#cfc5dd', maxWidth: '520px', animationDelay: '.45s' } },
        'The shards of the old sky drift above the cloud-sea, and every one is held by a living warden. Alpha — the first light — still seeps through their roots. Raise a wyrm, delve the wildroot, brew it into alpha, and take the sky from those who sleep.'),
      h('div', { class: 'row rise', style: { gap: '14px', marginTop: '34px', animationDelay: '.6s' } }, enter,
        h('a', { class: 'btn', href: '#/grimoire', style: { minHeight: '52px', padding: '0 24px', fontSize: '18px' } }, 'Open the Grimoire')),
      h('dl', { class: 'rise', style: { display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '18px', margin: '46px 0 0', maxWidth: '520px', animationDelay: '.75s' } },
        stat('Realms', '4'), stat('Beasts & hallows', String(STRUCT_TYPES.length)), h('div', { style: { borderTop: '1px solid rgba(232,200,114,.4)', paddingTop: '10px' } }, h('dt', { class: 'label' }, 'Wardens seen'), count))),
    h('footer', { class: 'gate-foot' },
      h('div', { class: 'row', style: { padding: '0 clamp(16px, 4vw, 48px) 10px', gap: '10px' } }, h('span', { class: 'link-dot live' }), h('span', { class: 'eyebrow' }, 'Wardens abroad in the sky'),
        h('button', { type: 'button', class: 'btn small ghost', style: { marginLeft: 'auto', minHeight: '32px' }, onclick: () => tell() }, 'Hear the prologue')),
      h('div', { class: 'marquee' }, ticker)));

  const scene = mountScene(canvas, (c) => K.gate(c, {}));
  let tale: { close(): void } | null = null;
  const tell = () => { tale?.close(); tale = playPrologue({ rain: (on) => scene.get()?.rain(on), onOath: ctx.oath }); };
  const auto = !prologueSeen() || ctx.param === 'prologue' ? setTimeout(tell, 400) : 0;
  wardens().then((list) => {
    count.textContent = String(list.length);
    const items = list.slice(0, 40).map((w) => h('span', { class: 'row', style: { gap: '8px', flexWrap: 'nowrap' } },
      h('span', { style: { color: 'var(--gold)' } }, '✦'), wardenName(w), h('a', { href: `#/hold/${w.id}`, class: 'mono faint', style: { fontSize: '12px', textDecoration: 'none' } }, `isle ${w.planetId}`)));
    ticker.textContent = '';
    for (const it of [...items, ...items.map((n) => n.cloneNode(true))]) ticker.append(it);
  }).catch(() => { ticker.textContent = 'The ledger is quiet just now.'; });

  return { el, title: '', leave: () => { clearTimeout(auto); tale?.close(); scene.dispose(); bar.dispose(); } };
}
