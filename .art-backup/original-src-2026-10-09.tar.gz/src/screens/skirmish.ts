/* The Skirmish: your warband against a real warden's hold. Their beasts are read from the ledger
 * (their hallows and any warband at home); yours are your fleet. Strikes sign MsgStructAttack;
 * the plunder chant (MsgPlanetRaidComplete) is ground by the chant engine once you are in orbit. */
import { h, clear, toast } from '../core/dom';
import K from '../world/wyrmkit.js';
import { mountScene, type Ctx, type Screen } from './types';
import { topbar, hearts } from '../ui/frame';
import { chantsPanel, chroniclePanel } from '../ui/chants';
import { empire, type OwnedStruct, type PlayerState } from '../game/empire';
import { act, actionBlock } from '../game/actions';
import { wallet } from '../wallet/wallet';
import { txq } from '../wallet/queue';
import { AMBIT_FLAG, type Ambit, type WeaponSystem } from '../data/catalogue';
import { num } from '../chain/lcd';
import { REALM_COLOR, REALM_NAME, WARD_CRAFT, beastName, retellError } from '../lore';
import { raidersAt, realmOf } from '../realm';

type Side = 'ours' | 'theirs';

export function skirmish(ctx: Ctx): Screen {
  const canvas = h('canvas');
  const bar = topbar('#/skirmish', ctx.oath, { meters: true });
  const ours = h('aside', { class: 'glass panel col-l scroll-y', 'aria-label': 'Your warband' });
  const theirs = h('aside', { class: 'glass panel col-l scroll-y', 'aria-label': 'Their hold' });
  const strike = h('section', { class: 'glass panel', 'aria-label': 'Strike', style: { flex: '0 1 560px', minWidth: '280px' } });
  const chants = chantsPanel();
  const chron = chroniclePanel((j) => /Attack|RaidComplete|FleetMove/.test(j.msgs.map((m) => m.typeUrl).join()), 12);
  const status = h('div');
  const el = h('div', { class: 'screen' }, h('div', { class: 'stage' }, canvas),
    h('div', { class: 'hud' }, bar.el, status,
      h('div', { class: 'cols through' }, ours, theirs),
      h('div', { class: 'row', style: { justifyContent: 'center', alignItems: 'flex-end', gap: '12px' } }, strike,
        h('div', { class: 'stack', style: { flex: '0 1 380px', minWidth: '260px' } }, chants.el, chron.el))));

  let targetPid: string | null = ctx.param || null;
  let atk: string | null = null, mark: string | null = null;
  let sceneKey = '';
  let scene: ReturnType<typeof mountScene<any>> | null = null;
  const watched = new Set<string>();
  const fallen = new Set<string>();

  const me = () => empire.commander;
  const foe = (): PlayerState | null => (targetPid ? empire.players.get(targetPid) ?? null : null);

  /** If our warband is already abroad, the hold it circles is the foe. */
  let raidLook = 0;
  async function resolveTarget() {
    const p = me();
    if (!targetPid && p?.fleet?.status === 'away' && p.target) targetPid = p.target.Planet.owner;
    // Raiders over our own isle: they are the foe.
    if (!targetPid && p?.planet && Date.now() - raidLook > 4000) {
      raidLook = Date.now();
      const r = await raidersAt(p.planet).catch(() => []);
      if (r.length && !targetPid) { targetPid = r[0].owner; paint(); return; }
    }
    if (targetPid && !watched.has(targetPid) && !wallet.byPlayer(targetPid)) { watched.add(targetPid); empire.watch(targetPid); }
  }

  const alive = (s: OwnedStruct) => !s.destroyed && s.built && !!s.type;
  function ourBeasts(p: PlayerState | null) { return p ? [...p.structs.values()].filter((s) => alive(s) && s.type!.category === 'fleet') : []; }
  /** Their warband hangs over our isle while ours is home: we defend. */
  function defending(): boolean {
    const p = me(), f = foe();
    return !!(p && f && f.fleet?.status === 'away' && f.fleet.locationId === p.planetId && p.fleet?.status !== 'away');
  }
  function theirBeasts(f: PlayerState | null) {
    if (!f) return [];
    if (defending()) return [...f.structs.values()].filter((s) => alive(s) && s.type!.category === 'fleet');
    const home = f.fleet?.status !== 'away';
    return [...f.structs.values()].filter((s) => alive(s) && (s.type!.category === 'planet' || home));
  }

  /** Which weapon (if any) can reach `t` from `a`, and why not. */
  function reach(a: OwnedStruct, t: OwnedStruct): { weapon: WeaponSystem | null; why: string } {
    const at = a.type!, ta = t.ambit as Ambit;
    if (t.hidden && t.ambit !== a.ambit) return { weapon: null, why: 'Veiled — only its own realm can find it' };
    const can = (mask: number) => (mask & AMBIT_FLAG[ta]) || ((mask & AMBIT_FLAG.local) && a.ambit === t.ambit);
    if (at.primaryWeaponCharge && can(at.primaryWeaponAmbits)) return { weapon: 'primaryWeapon', why: '' };
    if (at.secondaryWeaponCharge && can(at.secondaryWeaponAmbits)) return { weapon: 'secondaryWeapon', why: '' };
    if (at.primaryWeaponAmbits & AMBIT_FLAG.local) return { weapon: null, why: 'The Wyrm must soar into that realm first' };
    return { weapon: null, why: `Out of reach for the ${beastName(a.typeId)}` };
  }

  function odds(a: OwnedStruct, t: OwnedStruct, w: WeaponSystem): string {
    const at = a.type!, tt = t.type!;
    const pre = w === 'primaryWeapon' ? 'primaryWeapon' : 'secondaryWeapon';
    const control = (at as unknown as Record<string, string>)[pre + 'Control'];
    const dmg = (at as unknown as Record<string, number>)[pre + 'Damage'];
    const ap = (at as unknown as Record<string, boolean>)[pre + 'ArmourPiercing'];
    const charge = (at as unknown as Record<string, number>)[pre + 'Charge'];
    const bits = [`${control === 'guided' ? 'A seeking blow' : 'A flung blow'} for ${charge} breath.`];
    const tr = tt as unknown as Record<string, number>;
    const [n, d] = control === 'guided' ? [tr.guidedDefensiveSuccessRateNumerator, tr.guidedDefensiveSuccessRateDenominator] : [tr.unguidedDefensiveSuccessRateNumerator, tr.unguidedDefensiveSuccessRateDenominator];
    if (d) bits.push(`${WARD_CRAFT[tt.unitDefenses]} lets ${n} in ${d} through.`);
    const red = tt.attackReduction && !ap ? tt.attackReduction : 0;
    bits.push(`${Math.max(0, dmg - red)} damage${red ? ' (stone-skin)' : ap && tt.attackReduction ? ' — it cracks stone-skin' : ''}.`);
    const counter = a.ambit === t.ambit ? tt.counterAttackSameAmbit : tt.counterAttack;
    bits.push(!at.attackCounterable ? 'It cannot answer.' : counter ? `If it lives, it answers for ${counter}.` : 'It cannot answer.');
    return bits.join(' ');
  }

  function remountScene(p: PlayerState | null, f: PlayerState | null) {
    const mineList = ourBeasts(p), theirList = theirBeasts(f);
    const key = mineList.map((s) => s.id).join(',') + '|' + theirList.map((s) => s.id).join(',');
    if (key === sceneKey && scene) return;
    sceneKey = key;
    scene?.dispose();
    const pack = (list: OwnedStruct[]) => list.map((s) => ({ id: s.id, type: s.typeId, realm: s.type!.category === 'fleet' ? realmOf(s) : undefined }));
    scene = mountScene(canvas, (c) => K.skirmish(c, {
      ours: pack(mineList), theirs: pack(theirList),
      onPick: (id: string | null) => { if (!id) return; if (mineList.some((s) => s.id === id)) atk = id; else mark = id; paint(); },
    }), (c) => { c.mark('a', atk); c.mark('t', mark); });
  }

  function unleash() {
    const p = me(), f = foe();
    const a = p?.structs.get(atk || ''), t = f?.structs.get(mark || '');
    if (!p || !a || !t) return;
    if (!wallet.unlocked) { toast('Your soulstone is sealed.', 'warn', 5000, { label: 'Unseal', run: ctx.oath }); return; }
    const block = actionBlock(p); if (block) { toast(retellError(block), 'enemy'); return; }
    const r = reach(a, t); if (!r.weapon) { toast(r.why, 'warn'); return; }
    try {
      const job = act.attack(p, a, [t.id], r.weapon);
      const control = (a.type as unknown as Record<string, string>)[r.weapon + 'Control'];
      const off = txq.onSettled((j) => {
        if (j.id !== job.id) return;
        off();
        if (j.status === 'success') scene?.get()?.strike(a.id, t.id, { color: 0xffc04a, guided: control === 'guided' });
      });
      toast(`The ${beastName(a.typeId)} gathers itself to strike.`, 'player', 2500);
    } catch (e) { toast(retellError((e as Error).message), 'enemy'); }
  }

  function paint() {
    void resolveTarget();
    const p = me(), f = foe();
    const ctl = scene?.get();
    // fallen beasts tumble once
    if (f) for (const s of f.structs.values()) if (s.destroyed && !fallen.has(s.id)) { fallen.add(s.id); ctl?.fell(s.id); }
    if (p) for (const s of p.structs.values()) if (s.destroyed && !fallen.has(s.id)) { fallen.add(s.id); ctl?.fell(s.id); }
    remountScene(p, f);
    scene?.get()?.mark('a', atk); scene?.get()?.mark('t', mark);

    clear(status);
    const inOrbit = !!(p && f && p.fleet?.status === 'away' && p.fleet.locationId === f.planetId) || defending();
    if (!p) status.append(banner('You have no warband yet.', ['Swear the oath', ctx.oath]));
    else if (!targetPid) status.append(banner('Choose a hold to raid from the Sky Atlas.', ['Open the Atlas', () => ctx.go('#/atlas')]));
    else if (!f) status.append(banner('Scrying their hold from the ledger…'));
    else if (defending()) status.append(banner(`Raiders over your isle! ${f.name || f.playerId}’s warband hangs in your sky. Fell their Elder Wyrm and the plunder breaks.`));
    else if (!inOrbit) status.append(banner(`Your warband is ${p.fleet?.status === 'away' ? `abroad at isle ${p.fleet.locationId}` : 'at home'}. Ride to isle ${f.planetId} to strike and plunder.`,
      ['Ride out', () => { try { act.fleetMove(p, f.planetId); } catch (e) { toast(retellError((e as Error).message), 'enemy'); } }]));
    else {
      const ward = num(f.planet?.planetAttributes?.planetaryShield);
      status.append(banner(`In orbit over ${f.name || f.playerId}’s isle ${f.planetId} · ward ${ward} · ${f.ore} sheaves of wildroot unbrewed. The plunder chant runs while you hold the sky.`,
        ['Ride home', () => { try { act.fleetMove(p, p.planetId); } catch (e) { toast(retellError((e as Error).message), 'enemy'); } }]));
    }

    const aS = p?.structs.get(atk || '');
    clear(ours);
    ours.append(h('h2', { class: 'display', style: { marginBottom: '8px' } }, 'Your warband'));
    const mine = ourBeasts(p);
    if (!mine.length) ours.append(h('p', { class: 'empty' }, 'No beasts ride with you.'));
    ours.append(h('ul', { class: 'list' }, ...mine.map((s) => h('li', null, h('button', { type: 'button', class: 'item' + (atk === s.id ? ' on' : ''), onclick: () => { atk = s.id; paint(); } },
      h('span', { class: 'l' }, h('span', { class: 'gem', style: { background: REALM_COLOR[realmOf(s)] } }),
        h('span', { style: { minWidth: '0' } }, h('span', { class: 'nm' }, beastName(s.typeId)), h('span', { class: 'sub' }, `${REALM_NAME[realmOf(s)]} · ${s.type!.primaryWeaponCharge || '—'} breath${s.online ? '' : ' · slumbering'}`))),
      h('span', { class: 'hearts' }, hearts(s.health, s.type!.maxHealth)))))));

    clear(theirs);
    theirs.append(h('h2', { class: 'display', style: { marginBottom: '8px', color: 'var(--ember-ink)' } }, f ? `${f.name || f.playerId}’s hold` : 'Their hold'));
    const foes = theirBeasts(f);
    if (f && !foes.length) theirs.append(h('p', { class: 'empty' }, 'Nothing stands on their isle.'));
    theirs.append(h('ul', { class: 'list' }, ...foes.map((s) => {
      const r = aS ? reach(aS, s) : { weapon: 'primaryWeapon' as WeaponSystem, why: '' };
      const hallow = s.type!.category === 'planet';
      return h('li', null, h('button', { type: 'button', class: 'item' + (mark === s.id ? ' mark' : ''), disabled: !r.weapon, title: r.why, onclick: () => { mark = s.id; paint(); } },
        h('span', { class: 'l' }, h('span', { class: 'gem', style: { background: hallow ? 'var(--gold)' : REALM_COLOR[realmOf(s)] } }),
          h('span', { style: { minWidth: '0' } }, h('span', { class: 'nm' }, beastName(s.typeId)),
            h('span', { class: 'sub', style: { color: r.weapon ? undefined : '#ff9f7a' } }, r.weapon ? `${hallow ? 'Hallow' : REALM_NAME[realmOf(s)]}${s.hidden ? ' · Veiled' : ''}${WARD_CRAFT[s.type!.unitDefenses] && s.type!.unitDefenses !== 'noUnitDefenses' ? ' · ' + WARD_CRAFT[s.type!.unitDefenses] : ''}` : r.why))),
        h('span', { class: 'hearts' }, hearts(s.health, s.type!.maxHealth))));
    })));

    clear(strike);
    const tS = f?.structs.get(mark || '');
    const r = aS && tS ? reach(aS, tS) : null;
    strike.append(
      h('p', { style: { margin: 0, fontSize: '16px' } }, h('span', { style: { color: 'var(--gold)' } }, aS ? beastName(aS.typeId) : 'Choose a striker'), h('span', { class: 'faint' }, ' → '), h('span', { style: { color: '#ff9f7a' } }, tS ? beastName(tS.typeId) : 'choose a mark')),
      h('p', { class: 'muted', style: { margin: '4px 0 0', fontSize: '14px', minHeight: '20px' } }, aS && tS ? (r?.weapon ? odds(aS, tS, r.weapon) : r?.why || '') : 'Your striker’s reach decides which of their beasts can be marked.'),
      h('div', { class: 'row', style: { marginTop: '12px' } },
        h('button', { type: 'button', class: 'btn ember', 'data-tut': 'unleash', style: { flex: '1 1 200px', minHeight: '54px', borderRadius: '14px' }, disabled: !(r?.weapon && inOrbit), onclick: unleash }, 'Unleash'),
        ...(['ours', 'all', 'theirs'] as (Side | 'all')[]).map((v) => h('button', { type: 'button', class: 'btn small ghost', onclick: () => scene?.get()?.view(v) }, v === 'all' ? 'The gulf' : v === 'ours' ? 'Ours' : 'Theirs'))));
  }

  function banner(text: string, action?: [string, () => void]) {
    return h('div', { class: 'glass row', role: 'status', style: { alignSelf: 'center', margin: '0 auto', width: 'fit-content', maxWidth: '100%', padding: '8px 10px 8px 16px', borderRadius: '999px', flexWrap: 'wrap' } },
      h('span', null, text), action ? h('button', { type: 'button', class: 'btn small', onclick: action[1] }, action[0]) : null);
  }

  const offs = [empire.onChange(paint), wallet.onChange(paint)];
  paint();
  return {
    el, title: 'Skirmish',
    leave: () => { offs.forEach((f) => f()); scene?.dispose(); bar.dispose(); chants.dispose(); chron.dispose(); for (const w of watched) empire.unwatch(w); },
  };
}
