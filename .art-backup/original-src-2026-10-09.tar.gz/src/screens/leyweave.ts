/* The Leyweave: where alpha becomes mana. Every coven's wellspring, the ley shrine your hold drinks
 * from, and your own tithes — all read live. Tithing and unbinding seal real rites. */
import { h, clear, toast, confirmBox } from '../core/dom';
import K from '../world/wyrmkit.js';
import { mountScene, type Ctx, type Screen } from './types';
import { topbar } from '../ui/frame';
import { chroniclePanel } from '../ui/chants';
import { lcd, big, type Grid, type RawInfusion, type RawReactor } from '../chain/lcd';
import { guilds, type GuildEntry } from '../guild/directory';
import { empire } from '../game/empire';
import { wallet } from '../wallet/wallet';
import { txq } from '../wallet/queue';
import { covenColor, covenName, fmtAlpha, fmtMana, speak } from '../lore';

interface Well { r: RawReactor; grid: Grid; commission: number }

const M = (name: string, value: Record<string, unknown>) => ({ typeUrl: `/structs.structs.${name}`, value });

export function leyweave(ctx: Ctx): Screen {
  const canvas = h('canvas');
  const bar = topbar('#/leyweave', ctx.oath, { meters: true });
  const mine = h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '14px' } });
  const wellsBox = h('div', { class: 'grid-cards' });
  const chron = chroniclePanel((j) => /Reactor|GeneratorInfuse/.test(j.msgs.map((m) => m.typeUrl).join()), 10);
  const el = h('div', { class: 'screen scrolls', style: { background: '#0a0b1e' } },
    h('section', { style: { position: 'relative', height: '52vh', minHeight: '360px', overflow: 'hidden' } },
      h('div', { class: 'stage' }, canvas),
      h('div', { class: 'hud', style: { height: 'auto' } }, bar.el),
      h('p', { style: { position: 'absolute', left: 'clamp(16px, 3vw, 32px)', bottom: '14px', margin: 0, maxWidth: '620px', fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 'clamp(18px, 2vw, 24px)', color: 'var(--gold-hi)', textShadow: '0 2px 20px rgba(0,0,0,.8)', zIndex: 3 } },
        'Alpha tithed to a wellspring wakes as mana. The leylines carry it to the shrines, and every hold that drinks there feels it.')),
    h('main', { style: { maxWidth: '1280px', margin: '0 auto', padding: '26px clamp(16px, 3vw, 32px) 64px' } },
      h('h2', { class: 'display', style: { fontSize: '32px' } }, 'Your leyweave'), h('div', { style: { marginTop: '14px' } }, mine),
      h('div', { class: 'row between', style: { marginTop: '44px', alignItems: 'baseline' } },
        h('h2', { class: 'display', style: { fontSize: '32px' } }, 'The wellsprings'),
        h('span', { class: 'muted', style: { fontSize: '14px' } }, 'Every coven keeps one. A wellspring keeps a little of each tithe as its due.')),
      h('div', { style: { marginTop: '14px' } }, wellsBox),
      h('div', { style: { marginTop: '24px', maxWidth: '640px' } }, chron.el)));

  const scene = mountScene(canvas, (c) => K.leyweave(c, {}));
  let wells: Well[] = [];
  let tithes: RawInfusion[] = [];
  let shrine: Grid | null = null;
  let covens = new Map<string, GuildEntry>();
  let loaded = false;

  const name = (gid: string) => covenName(gid, covens.get(gid)?.meta?.name);

  async function load() {
    const p = empire.commander;
    const [rs, inf, gs, sub] = await Promise.all([
      lcd.list<RawReactor>('reactor', 'Reactor'),
      p ? lcd.list<RawInfusion>('infusion', 'Infusion').catch(() => [] as RawInfusion[]) : Promise.resolve([] as RawInfusion[]),
      guilds().catch(() => [] as GuildEntry[]),
      p?.substationId ? lcd.entity<{ gridAttributes?: Grid }>('substation', p.substationId).then((r) => r.gridAttributes || {}).catch(() => null) : Promise.resolve(null),
    ]);
    covens = new Map(gs.map((g) => [g.id, g]));
    const grids = await Promise.all(rs.map((r) => lcd.entity<{ gridAttributes?: Grid }>('reactor', r.id).then((x) => x.gridAttributes || {}).catch(() => ({} as Grid))));
    wells = rs.map((r, i) => ({ r, grid: grids[i], commission: Number(r.defaultCommission || 0) })).sort((a, b) => Number(big(b.grid.fuel) - big(a.grid.fuel)));
    tithes = p ? inf.filter((i) => i.address === p.address && i.destinationType === 'reactor') : [];
    shrine = sub;
    loaded = true;
    paint();
  }

  function guard(): boolean {
    if (!empire.commander) { toast('Swear the oath first.', 'warn', 5000, { label: 'Oath', run: ctx.oath }); return false; }
    if (!wallet.unlocked) { toast('Your soulstone is sealed.', 'warn', 5000, { label: 'Unseal', run: ctx.oath }); return false; }
    return true;
  }

  function titheDialog(w: Well, unbind = false) {
    const p = empire.commander;
    if (!guard() || !p) return;
    const staked = big(tithes.find((t) => t.destinationId === w.r.id)?.fuel);
    const max = unbind ? staked : p.alpha;
    const amt = h('input', { id: 'tithe-amt', type: 'number', min: '0.000001', step: '0.1', value: '1' }) as HTMLInputElement;
    const preview = h('p', { class: 'muted', style: { minHeight: '22px', fontSize: '14px' } });
    const upd = () => {
      const u = BigInt(Math.max(0, Math.round(Number(amt.value || 0) * 1e6)));
      const yours = BigInt(Math.round(Number(u) * (1 - w.commission)));
      preview.textContent = u > max ? `You ${unbind ? 'have tithed' : 'hold'} only ${fmtAlpha(max)} α here.` : unbind ? `Your mana flow falls by about ${fmtMana(yours)}. The alpha returns over many days.` : `About +${fmtMana(yours)} mana flow for your hold; the wellspring keeps ${(w.commission * 100).toFixed(0)}% as its due.`;
    };
    amt.addEventListener('input', upd); upd();
    const veil = h('div', { class: 'veil', onclick: (e: Event) => { if (e.target === veil) veil.remove(); } }, h('section', { class: 'scroll', role: 'dialog', 'aria-modal': 'true', 'aria-label': unbind ? 'Unbind' : 'Tithe' },
      h('h2', null, unbind ? `Unbind from ${name(w.r.guildId)}` : `Tithe to ${name(w.r.guildId)}`),
      h('p', null, unbind ? 'Drawing a tithe back takes many days; your mana flow falls at once.' : `You hold ${fmtAlpha(p.alpha)} α. A tithe stays yours — you can unbind it later — and wakes as mana while it rests in the wellspring.`),
      h('div', { class: 'field' }, h('label', { for: 'tithe-amt' }, 'Alpha'), amt), preview,
      h('div', { class: 'row end' },
        h('button', { type: 'button', class: 'btn ghost', onclick: () => veil.remove() }, 'Not now'),
        h('button', { type: 'button', class: unbind ? 'btn ember' : 'btn gold', onclick: async () => {
          const u = BigInt(Math.round(Number(amt.value || 0) * 1e6));
          if (u <= 0n || u > max) return;
          if (unbind && !(await confirmBox('Unbind this tithe?', `${fmtAlpha(u)} α leaves the wellspring over many days, and your mana flow falls now. If your beasts drink more than you keep, they will slumber.`, 'Unbind'))) return;
          veil.remove();
          try {
            txq.enqueue(M(unbind ? 'MsgReactorDefuse' : 'MsgReactorInfuse', { delegator_address: p.address, validator_address: w.r.validator, amount: { denom: 'ualpha', amount: u.toString() } }),
              { account: p.account, playerId: p.playerId, label: `${unbind ? 'Unbind' : 'Tithe'} ${fmtAlpha(u)} alpha ${unbind ? 'from' : 'to'} the wellspring of ${name(w.r.guildId)}`, source: 'you' });
            if (!unbind) scene.get()?.tithe();
            toast(unbind ? 'The unbinding begins.' : 'Your alpha sinks into the wellspring.', 'player');
            setTimeout(() => void load(), 14000);
          } catch (e) { toast(speak((e as Error).message), 'enemy'); }
        } }, unbind ? 'Unbind' : 'Tithe'))));
    document.body.append(veil);
  }

  function card(title: string, eyebrow: string, color: string, body: (Node | string)[]) {
    return h('section', { class: 'glass panel', style: { padding: '18px' } },
      h('p', { class: 'eyebrow', style: { color } }, eyebrow), h('h3', { class: 'display', style: { fontSize: '26px', marginTop: '6px' } }, title), ...body);
  }

  function paint() {
    const p = empire.commander;
    clear(mine);
    if (!p) {
      mine.append(card('No warden yet', 'Your leyweave', 'var(--violet)', [h('p', { class: 'muted' }, 'Swear the oath: your coven lends you its leyline the moment you are sworn.'), h('button', { type: 'button', class: 'btn gold', onclick: ctx.oath }, 'Swear the oath')]));
    } else {
      const cap = p.capacity + p.connectionCapacity, load = p.load + p.structsLoad;
      const own = covens.get(p.guildId)?.chain?.primaryReactorId;
      const tithed = tithes.reduce((a, t) => a + big(t.fuel), 0n);
      mine.append(
        card(`${fmtMana(load)} / ${fmtMana(cap)}`, 'Mana flow', 'var(--sky)', [h('p', { class: 'muted', style: { margin: '8px 0 0' } }, p.online ? 'Your beasts drink within your flow.' : 'Your beasts drink more than you pour: they slumber until it fits.'),
          h('span', { class: 'bar', style: { marginTop: '10px' } }, h('i', { style: { width: (cap > 0n ? Math.min(100, Number(load * 100n / cap)) : 100) + '%', background: p.online ? 'var(--sky)' : 'var(--ember)' } }))]),
        card(p.substationId ? `Shrine ${p.substationId}` : 'No shrine', 'Ley shrine', 'var(--verdigris)', [h('p', { class: 'muted', style: { margin: '8px 0 0' } },
          shrine ? `${shrine.connectionCount || '0'} holds drink here, each granted up to ${fmtMana(big(shrine.connectionCapacity))} mana.` : 'Your hold drinks from no shrine.')]),
        card(`${fmtAlpha(tithed)} α`, 'Your tithes', 'var(--gold)', [h('p', { class: 'muted', style: { margin: '8px 0 0' } }, tithes.length ? `Resting in ${tithes.length} wellspring${tithes.length === 1 ? '' : 's'}.` : 'You have tithed nothing yet.'),
          own ? h('p', { class: 'faint', style: { fontSize: '13px', margin: '6px 0 0' } }, `Your coven’s wellspring is ${own}.`) : '']),
      );
      const ctl = scene.get();
      if (ctl) ctl.setRate(cap > 0n ? 0.4 + Math.min(2.6, Number(load * 100n / cap) / 40) : 0.2);
    }
    clear(wellsBox);
    if (!loaded) { wellsBox.append(h('p', { class: 'italic' }, 'Listening to the wellsprings…')); return; }
    const me = empire.commander;
    for (const w of wells) {
      const color = covenColor(w.r.guildId);
      const mineHere = tithes.find((t) => t.destinationId === w.r.id);
      const ours = me && covens.get(me.guildId)?.chain?.primaryReactorId === w.r.id;
      wellsBox.append(h('div', { class: 'card-btn', style: { cursor: 'default', borderColor: ours ? 'rgba(232,200,114,.6)' : undefined } },
        h('span', { class: 'row between' }, h('b', null, name(w.r.guildId)), h('span', { class: 'gem', style: { background: color, boxShadow: `0 0 10px ${color}` } })),
        h('span', { class: 'mono faint', style: { fontSize: '12px' } }, `wellspring ${w.r.id}${ours ? ' · your coven' : ''}`),
        h('span', { class: 'row between mono', style: { fontSize: '13px', color: 'var(--ink-2)' } },
          h('span', null, `${fmtAlpha(big(w.grid.fuel))} α resting`), h('span', null, `${(w.commission * 100).toFixed(0)}% due`)),
        h('span', { class: 'mono', style: { fontSize: '13px', color: 'var(--sky)' } }, `${fmtMana(big(w.grid.capacity) || big(w.grid.power))} mana poured`),
        mineHere ? h('span', { style: { fontSize: '13px', color: 'var(--gold)' } }, `Your tithe: ${fmtAlpha(big(mineHere.fuel))} α`) : '',
        h('span', { class: 'row', style: { marginTop: '4px' } },
          h('button', { type: 'button', class: 'btn small gold', 'data-tut': ours || (!me && w === wells[0]) ? 'tithe' : null, onclick: () => titheDialog(w) }, 'Tithe'),
          mineHere ? h('button', { type: 'button', class: 'btn small ghost', onclick: () => titheDialog(w, true) }, 'Unbind') : '')));
    }
  }

  const offs = [empire.onChange(paint)];
  paint();
  load().catch((e) => { loaded = true; clear(wellsBox); wellsBox.append(h('p', { class: 'muted' }, 'The wellsprings did not answer: ' + speak((e as Error).message))); });
  return { el, title: 'Leyweave', leave: () => { offs.forEach((f) => f()); scene.dispose(); bar.dispose(); chron.dispose(); document.querySelectorAll('.veil').forEach((v) => v.remove()); } };
}
