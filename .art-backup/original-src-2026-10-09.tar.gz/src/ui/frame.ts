/* The frame every screen shares: the sigil, the realm's roads, the ledger's pulse, the warden's
 * soulstone, and the five meters of a hold (alpha, wildroot, mana, breath, ward). */
import { h } from '../core/dom';
import { live } from '../chain/live';
import { wallet } from '../wallet/wallet';
import { empire, type PlayerState } from '../game/empire';
import { num } from '../chain/lcd';
import { fmtAlpha, fmtMana } from '../lore';
import { enlisting } from '../game/enlist';
import { ambience } from '../core/audio';

export function sigil(size = 34, color = '#e8c872') {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('width', String(size)); svg.setAttribute('height', String(size));
  svg.setAttribute('viewBox', '0 0 40 40'); svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', color); svg.setAttribute('stroke-width', '1.6'); svg.setAttribute('aria-hidden', 'true');
  for (const [d, fill] of [['M20 2 L37 20 L20 38 L3 20 Z', ''], ['M8 20 C13 12, 27 12, 32 20 C27 28, 13 28, 8 20 Z', ''], ['M20 13 C22 17, 22 23, 20 27 C18 23, 18 17, 20 13 Z', color]]) {
    const p = document.createElementNS(ns, 'path'); p.setAttribute('d', d); if (fill) p.setAttribute('fill', fill); svg.append(p);
  }
  return svg;
}

export function icon(path: string, size = 18) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('width', String(size)); svg.setAttribute('height', String(size)); svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '2'); svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round');
  const p = document.createElementNS(ns, 'path'); p.setAttribute('d', path); svg.append(p);
  return svg;
}
export const ICON = { close: 'M6 6l12 12M18 6L6 18', arrow: 'M5 12h14M13 6l6 6-6 6', warn: 'M12 3l10 18H2zM12 10v5M12 18v.5', key: 'M15 7a4 4 0 1 1-3.9 4.9L3 20v-3h3v-3h3l2.1-2.1A4 4 0 0 1 15 7z' };

const ROADS: [string, string][] = [['#/hold', 'The Hold'], ['#/bestiary', 'Bestiary'], ['#/atlas', 'Sky Atlas'], ['#/leyweave', 'Leyweave'], ['#/skirmish', 'Skirmish'], ['#/grimoire', 'Grimoire']];

/** The top bar. Returns the element and a disposer for its listeners. */
export function topbar(route: string, onSoulstone: () => void, opts: { meters?: boolean } = {}) {
  const dot = h('span', { class: 'link-dot' });
  const bell = h('span', { class: 'mono faint', style: { fontSize: '12px' } });
  const stone = h('button', { type: 'button', class: 'btn small', 'data-tut': 'soulstone', onclick: onSoulstone });
  const music = h('button', { type: 'button', class: 'icon-btn', style: { width: '36px', height: '36px' }, onclick: () => ambience.toggle() });
  const meterBox = h('div', { class: 'meters' });
  const bar = h('header', { class: 'glass topbar' },
    h('a', { class: 'brand', href: '#/' }, sigil(), h('span', null, h('b', null, 'Wyrmhold'), h('small', null, h('span', { class: 'row', style: { gap: '6px' } }, dot, bell)))),
    opts.meters ? meterBox : null,
    h('nav', { class: 'nav', 'aria-label': 'Realms' }, ...ROADS.map(([href, label]) => h('a', { href, class: route === href ? 'on' : '' }, label))),
    h('div', { class: 'row', style: { gap: '6px' } }, music, stone));
  const paint = () => {
    dot.className = 'link-dot ' + (live.state === 'live' ? 'live' : live.state === 'down' ? 'down' : '');
    bell.textContent = live.state === 'live' ? `bell ${live.height.toLocaleString('en-US')}` : live.state === 'down' ? 'the ledger is silent' : 'reaching the ledger…';
    const a = wallet.active;
    stone.textContent = '';
    stone.append(icon(ICON.key, 16), ' ',
      wallet.state === 'empty' ? 'Bind your soulstone'
        : enlisting.running ? 'Swearing the oath…'
          : a?.playerId ? `${a.label && a.label !== 'Commander' ? a.label : 'Warden'} · ${a.playerId}` : wallet.unlocked ? 'Unsworn soulstone' : 'Soulstone sealed');
    if (opts.meters) paintMeters(meterBox, empire.commander);
    music.textContent = '';
    music.setAttribute('aria-label', ambience.on ? 'Hush the sky’s music' : 'Let the sky sing');
    music.setAttribute('aria-pressed', String(ambience.on));
    music.title = ambience.on ? 'Hush the music' : 'Let the sky sing';
    music.append(icon(ambience.on ? 'M9 18V5l12-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM21 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z' : 'M9 18V5l12-2v13M3 3l18 18', 16));
  };
  const offs = [live.onBlock(paint), live.onState(paint), wallet.onChange(paint), empire.onChange(paint), enlisting.onChange(paint), ambience.onChange(paint)];
  paint();
  return { el: bar, dispose: () => offs.forEach((f) => f()) };
}

export function wardOf(p: PlayerState | null) { return num(p?.planet?.planetAttributes?.planetaryShield); }

export function paintMeters(box: HTMLElement, p: PlayerState | null) {
  box.textContent = '';
  if (!p) return;
  const cap = p.capacity + p.connectionCapacity, load = p.load + p.structsLoad;
  const pct = cap > 0n ? Math.min(100, Number((load * 100n) / cap)) : 100;
  const breath = empire.charge(p);
  box.append(
    h('div', { class: 'meter m-alpha', title: 'Alpha — the first light, fallen when the sky broke. It quickens everything it touches, and no raider can take it.' },
      h('span', { class: 'k' }, h('span', null, 'Alpha')), h('span', { class: 'v' }, fmtAlpha(p.alpha), h('small', { class: 'alpha-glyph' }, ' α'))),
    h('div', { class: 'meter m-root' + (p.ore > 0 ? ' risk' : ''), title: 'Wildroot — roots that drank fallen alpha. Raw and plunderable until the Cauldron draws its alpha out.' },
      h('span', { class: 'k' }, h('span', null, 'Wildroot')), h('span', { class: 'v' }, String(p.ore), h('small', null, ' sheaves'))),
    h('div', { class: 'meter m-mana', title: 'Mana flow — what your beasts drink against what your springs and shrine pour.' },
      h('span', { class: 'k' }, h('span', null, 'Mana'), h('span', null, `${fmtMana(load)} / ${fmtMana(cap)}`)),
      h('span', { class: 'bar' }, h('i', { style: { width: pct + '%', background: pct > 90 || !p.online ? 'var(--ember)' : 'var(--sky)' } }))),
    h('div', { class: 'meter m-breath', title: 'Breath — one draws in with every bell, shared by your whole warband.' },
      h('span', { class: 'k' }, h('span', null, 'Breath'), h('span', null, String(breath))),
      h('span', { class: 'bar' }, h('i', { style: { width: Math.min(100, breath / 8 * 100) + '%', background: 'var(--verdigris)' } }))),
    h('div', { class: 'meter m-ward', title: 'Ward — how long a raider must chant to break into your hold.' },
      h('span', { class: 'k' }, h('span', null, 'Ward')), h('span', { class: 'v' }, String(wardOf(p)))),
  );
}

export function hearts(hp: number, max: number) { return '♥'.repeat(Math.max(0, hp)) + '♡'.repeat(Math.max(0, max - hp)); }
