/* The Warden's Path: a living tutorial. Ysolde, a grey owl spirit, walks a new warden from soulstone
 * to first strike. Every step is judged from the warden's real state on the ledger (or a rite that
 * landed), so it can never be "faked" past — and a warden who arrives already strong finds the early
 * steps already lit. "Show me" carries you to the right place and makes the right control glow. */
import { h, clear } from '../core/dom';
import K from '../world/wyrmkit.js';
import { wallet } from '../wallet/wallet';
import { empire, type PlayerState } from '../game/empire';
import { txq } from '../wallet/queue';
import { audio } from '../core/audio';
import { enlisting } from '../game/enlist';

interface Step {
  id: string;
  title: string;
  say: string;                // Ysolde's words while the step waits
  done?: string;              // her words when it lands
  route: string;              // where "Show me" goes
  glow?: string;              // data-tut target to make glow
  test: (p: PlayerState | null) => boolean;
  slow?: boolean;             // ripens over many bells: the path may walk on
}

const HIDE_KEY = 'wyrmhold.path.hidden';
/** Each warden walks their own path: remembered moments are kept per warden sigil. */
const flagsKey = () => `wyrmhold.path.${wallet.active?.playerId || wallet.active?.address || 'unbound'}`;
let flagsFor = '';
let flags: Record<string, boolean> = {};
function loadFlags() {
  const k = flagsKey();
  if (k === flagsFor) return;
  flagsFor = k;
  try { flags = JSON.parse(localStorage.getItem(k) || '{}'); } catch { flags = {}; }
  lastSig = ''; lastSaid = ''; ready = false;
}
const save = () => { try { localStorage.setItem(flagsKey(), JSON.stringify(flags)); } catch { /* memory only */ } };

/** Screens call this when the warden does something the path watches for. */
export function markPath(id: string) { loadFlags(); if (!flags[id]) { flags[id] = true; save(); paintSoon(); } }

const owns = (p: PlayerState | null, type: number, built = false) => !!p && [...p.structs.values()].some((s) => s.typeId === type && !s.destroyed && (!built || s.built));

const STEPS: Step[] = [
  { id: 'stone', title: 'Bind your soulstone', route: '#/', glow: 'soulstone',
    say: 'Hoo. A new light on the old wind. Before the sky will know you, you need a soulstone — your name, sealed here, that only you can speak. Touch the stone in the corner.',
    done: 'There. The stone is warm. It knows your hand now.', test: () => wallet.state !== 'empty' },
  { id: 'oath', title: 'Swear to a coven', route: '#/', glow: 'soulstone',
    say: 'No warden survives alone up here. Choose a coven; they will lend you a leyline until your own springs run. Give yourself a name the wind can carry.',
    done: 'Sworn. I heard the coven’s scribe write you into the ledger.', test: () => !!wallet.active?.playerId },
  { id: 'isle', title: 'Seek your isle', route: '#/hold', glow: 'seek',
    say: 'Somewhere below the clouds drifts a shard of the old sky with no one on it. Seek it — and something old will hatch there to meet you.',
    done: 'Feel that? Your isle. And listen — the egg is cracking.', test: (p) => !!p?.planetId },
  { id: 'wyrm', title: 'Meet your Elder Wyrm', route: '#/hold', glow: 'wyrm',
    say: 'Your Elder Wyrm is bound to you alone. It is the only beast that can soar between the four realms, and every raid you ever ride rides on its back. Go to it. Touch it.',
    done: 'It knows your scent now. Guard it well: if it falls while you raid, the raid breaks.', test: () => !!flags.wyrm },
  { id: 'delver', title: 'Summon a Root Delver', route: '#/hold', glow: 'summon',
    say: 'Your isle’s marrow is full of wildroot — roots that drank the fallen alpha. A Root Delver will lift it. Draw a circle and summon one; it costs eight breath.',
    done: 'The circle is drawn. Now the summoning must be sung.', test: (p) => owns(p, 14) },
  { id: 'chant', title: 'Let the chant ripen', route: '#/hold', glow: 'chants',
    say: 'Every summoning needs a chant, and a chant must ripen: the sky makes it easier with every bell. Your Hold is singing it for you, with every thread this machine can spare. Watch the bar.',
    done: 'Heard! The Delver wakes. It will chant wildroot up from the deep on its own now.', test: (p) => owns(p, 14, true) },
  { id: 'cauldron', title: 'Raise a Dawn Cauldron', route: '#/hold', glow: 'summon',
    say: 'Wildroot is only half a treasure — any raider can carry it off. A Dawn Cauldron draws the alpha out of it, and alpha, once brewed, no one can ever take from you.',
    done: 'Good. From now on, what you delve, you keep.', test: (p) => owns(p, 15) },
  { id: 'alpha', title: 'Understand alpha', route: '#/grimoire', glow: 'tale',
    say: 'Alpha is the first light — it fell when the sky broke. It feeds your springs, calls your beasts, and is the only coin the covens honour. Read the old tale in the Grimoire; I will wait.',
    done: 'Now you know why every warden up here is hungry.', test: () => !!flags.grimoire },
  { id: 'tithe', title: 'Tithe to your wellspring', route: '#/leyweave', glow: 'tithe',
    say: 'Your beasts drink mana, and mana is alpha that has been given away — for a while. Tithe a little alpha to your coven’s wellspring, and your mana flow will rise. You can unbind it later.',
    done: 'Your flow rises. The leylines hum your name.', test: () => !!flags.tithe },
  { id: 'atlas', title: 'Read the sky', route: '#/atlas', glow: 'rich',
    say: 'Every light out there is a hold, and every hold is a warden — sleeping, scheming, or watching you. Look at them. Touch “Unbrewed wildroot”: the isles burning amber hold a prize — and the ones long asleep will not wake to defend it.',
    done: 'You see them now. Some of them see you.', test: () => !!flags.atlas },
  { id: 'ride', title: 'Ride out', route: '#/atlas', glow: 'ride',
    say: 'Choose an isle and ride. While your warband is abroad your own hold stands unguarded — so be quick, and be sure.',
    done: 'The wind is under you. Hold the sky over their isle and the plunder chant begins.', test: (p) => !!flags.ride || p?.fleet?.status === 'away' },
  { id: 'strike', title: 'Strike', route: '#/skirmish', glow: 'unleash',
    say: 'Choose a striker, then a mark within its reach. Read the odds — glamour, windslip, stone-skin — then unleash. Whatever lives will answer.',
    done: 'Blood in the clouds. You are a warden now, truly. The rest of the sky is yours to learn.', test: () => !!flags.strike },
];

let panel: HTMLElement | null = null;
let body: HTMLElement | null = null;
let portrait: { dispose(): void } | null = null;
let lastDone = new Set<string>();
let ready = false;
let paintTimer = 0;
function paintSoon() { if (!paintTimer) paintTimer = window.setTimeout(() => { paintTimer = 0; paint(); }, 60); }

function hidden() {
  try { const v = localStorage.getItem(HIDE_KEY); if (v != null) return v === '1'; } catch { /* default */ }
  // On a phone Ysolde starts folded into her lantern: one tap opens her.
  return matchMedia('(max-width: 720px)').matches;
}
function setHidden(v: boolean) { try { localStorage.setItem(HIDE_KEY, v ? '1' : '0'); } catch { /* memory */ } lastSig = ''; paint(); }

/** Make a control glow until it is used (or for a while). Screens repaint, so the glow is
 * re-applied to whatever element carries the tag until it is touched or the moment passes. */
let glowing: { tag: string; until: number; scrolled: boolean } | null = null;
setInterval(() => {
  document.querySelectorAll('.tut-glow').forEach((el) => { if (!glowing || (el as HTMLElement).dataset.tut !== glowing.tag) el.classList.remove('tut-glow'); });
  if (!glowing) return;
  if (Date.now() > glowing.until) { glowing = null; return; }
  const el = document.querySelector(`[data-tut="${glowing.tag}"]`) as HTMLElement | null;
  if (!el) return;
  el.classList.add('tut-glow');
  if (!glowing.scrolled) { glowing.scrolled = true; el.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' }); }
}, 250);
document.addEventListener('click', (e) => {
  if (glowing && (e.target as HTMLElement)?.closest?.(`[data-tut="${glowing.tag}"]`)) glowing = null;
}, true);
export function glow(tag: string) { glowing = { tag, until: Date.now() + 12000, scrolled: false }; }

/** A tiny living portrait: the grey owl, breathing in her own little sky. */
const owlPortrait = (canvas: HTMLCanvasElement) => K.portrait(canvas, { type: 6, tint: 0x9a93b0 }) as { dispose(): void };

/** Type a line out, like a voice. */
function speakInto(el: HTMLElement, text: string) {
  el.textContent = '';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) { el.textContent = text; return; }
  let i = 0;
  const tick = () => { if (!el.isConnected) return; el.textContent = text.slice(0, i += 2); if (i < text.length) setTimeout(tick, 18); };
  tick();
}

function celebrate(step: Step) {
  audio.bell(783.99, 0.18, 2.6);
  setTimeout(() => audio.bell(1046.5, 0.14, 2.2), 180);
  const burst = h('div', { class: 'path-burst', 'aria-hidden': 'true' });
  for (let i = 0; i < 28; i++) {
    const a = (i / 28) * Math.PI * 2, d = 70 + Math.random() * 90;
    burst.append(h('i', { style: { '--dx': `${Math.cos(a) * d}px`, '--dy': `${Math.sin(a) * d}px`, animationDelay: `${Math.random() * 120}ms` } as unknown as Record<string, string> }));
  }
  panel?.append(burst);
  setTimeout(() => burst.remove(), 1600);
  void step;
}

let lastSaid = '';
let lastSig = '';
function paint() {
  if (!panel || !body) return;
  loadFlags();
  const p = empire.commander;
  const done = new Set(STEPS.filter((s) => s.test(p)).map((s) => s.id));
  // first paint: whatever is already true is simply lit, without fanfare
  if (ready) for (const id of done) if (!lastDone.has(id)) { const s = STEPS.find((x) => x.id === id)!; celebrate(s); }
  lastDone = done; ready = true;
  const cur = STEPS.find((s) => !done.has(s.id));
  const n = done.size;
  const sig = [...done].join(',') + '|' + hidden();
  if (sig === lastSig) return;
  lastSig = sig;
  panel.classList.toggle('min', hidden());
  document.body.classList.toggle('has-path', !hidden());
  clear(body);
  if (hidden()) {
    body.append(h('button', { type: 'button', class: 'path-pill', onclick: () => setHidden(false), 'aria-label': 'Open the Warden’s Path' },
      h('span', { class: 'mono' }, `${n}/${STEPS.length}`), ' The Warden’s Path'));
    return;
  }
  const said = h('p', { class: 'path-say' });
  const recent = [...STEPS].reverse().find((s) => done.has(s.id) && s.done && !flags['heard:' + s.id]);
  const last = 'You have walked the whole path. I will be in the Grimoire if you need the old words. Hoo.';
  const line = cur ? (recent ? `${recent.done} ${cur.say}` : cur.say) : recent ? `${recent.done} ${last}` : last;
  if (recent) { flags['heard:' + recent.id] = true; save(); }
  body.append(
    h('div', { class: 'path-head' },
      h('div', null, h('p', { class: 'eyebrow', style: { color: 'var(--gold)' } }, `The Warden’s Path · ${n} of ${STEPS.length}`),
        h('h2', { class: 'display', style: { fontSize: '21px', marginTop: '3px' } }, cur ? cur.title : 'The path is walked')),
      h('button', { type: 'button', class: 'icon-btn', style: { width: '32px', height: '32px', fontSize: '14px' }, 'aria-label': 'Fold the guide away', title: 'Fold away', onclick: () => setHidden(true) }, '–')),
    h('div', { class: 'path-steps', 'aria-hidden': 'true' }, ...STEPS.map((s) => h('i', { class: done.has(s.id) ? 'on' : s === cur ? 'cur' : '' }))),
    said,
    cur ? h('div', { class: 'row', style: { marginTop: '10px' } },
      h('button', { type: 'button', class: 'btn small gold', onclick: () => { if (location.hash !== cur.route && !(cur.route === '#/' && (location.hash === '' || location.hash === '#/'))) location.hash = cur.route; if (cur.glow) setTimeout(() => glow(cur.glow!), 450); } }, 'Show me'),
      cur.slow ? h('span', { class: 'faint', style: { fontSize: '12px' } }, 'This one ripens slowly.') : '') : '');
  if (line !== lastSaid) { lastSaid = line; speakInto(said, line); } else said.textContent = line;
}

export function mountGuide() {
  if (panel) return;
  const canvas = h('canvas', { width: 96, height: 96, class: 'path-owl', 'aria-hidden': 'true' }) as HTMLCanvasElement;
  body = h('div', { class: 'path-body' });
  panel = h('aside', { class: 'path glass', 'aria-label': 'The Warden’s Path — Ysolde the grey owl guides you' },
    h('div', { class: 'path-portrait' }, canvas, h('span', { class: 'path-name' }, 'Ysolde')), body);
  document.body.append(panel);
  try { portrait = owlPortrait(canvas); } catch { /* no GL: the words still guide */ }
  empire.onChange(paintSoon); wallet.onChange(paintSoon); enlisting.onChange(paintSoon);
  txq.onSettled((j) => {
    if (j.status !== 'success') return;
    const urls = j.msgs.map((m) => m.typeUrl).join();
    if (/ReactorInfuse|GeneratorInfuse/.test(urls)) markPath('tithe');
    if (/FleetMove/.test(urls)) markPath('ride');
    if (/StructAttack/.test(urls)) markPath('strike');
  });
  window.addEventListener('hashchange', paintSoon);
  paint();
  void portrait;
}

/** Start the path again from the first unlit step (flags for watched moments are kept). */
export function resetPath() { flags = {}; save(); lastSaid = ''; lastSig = ''; ready = false; setHidden(false); }
