/* The Oath: binding a soulstone (the wallet), swearing to a coven (guild signup through the
 * guild's signer) and seeking an isle (MsgPlanetExplore) — and, once sworn, the soulstone itself:
 * its address, its soul-words, and forgetting it. Keys never leave this tab. */
import { h, clear, confirmBox, toast } from '../core/dom';
import { wallet } from '../wallet/wallet';
import { enlist, enlisting, retryEnlist } from '../game/enlist';
import { guilds, type GuildEntry } from '../guild/directory';
import { covenColor, covenName, speak } from '../lore';
import { icon, ICON } from './frame';
import { empire } from '../game/empire';

let open: HTMLElement | null = null;

export function openOath() {
  if (open) return;
  const body = h('div');
  const veil = h('div', { class: 'veil', onclick: (e: Event) => { if (e.target === veil) close(); } },
    h('section', { class: 'scroll', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'oath-title' }, body));
  open = veil;
  document.body.append(veil);
  let offs: (() => unknown)[] = [];
  function close() { offs.forEach((f) => f()); veil.remove(); open = null; document.removeEventListener('keydown', esc); window.removeEventListener('hashchange', close); }
  const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };

  let mode: 'choose' | 'forge' | 'speak' | 'coven' | 'words' = 'choose';
  let name = '';
  let coven = '';
  let covens: GuildEntry[] | null = null;
  let revealed = '';
  let busy = false;

  const head = (step: string, title: string) => h('div', { class: 'row between', style: { alignItems: 'flex-start', flexWrap: 'nowrap' } },
    h('div', null, h('p', { class: 'eyebrow' }, step), h('h2', { id: 'oath-title', style: { marginTop: '6px' } }, title)),
    h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Close', onclick: close }, icon(ICON.close)));

  function loadCovens() {
    if (covens) return;
    guilds().then((g) => { covens = g; if (!coven && g.length) coven = g[0].id; paint(); }).catch(() => { covens = []; paint(); });
  }

  function covenPicker() {
    loadCovens();
    if (!covens) return h('p', { class: 'italic' }, 'Reading the covens from the ledger…');
    if (!covens.length) return h('p', { class: 'muted' }, 'No coven answered. The ledger may be quiet — try again in a moment.');
    return h('div', { class: 'stack', role: 'radiogroup', 'aria-label': 'Covens' }, ...covens.map((g) => {
      const nm = covenName(g.id, g.meta?.name);
      return h('button', { type: 'button', role: 'radio', 'aria-checked': String(coven === g.id), class: 'choice' + (coven === g.id ? ' on' : ''), onclick: () => { coven = g.id; paint(); } },
        h('span', { class: 'row', style: { flexWrap: 'nowrap' } }, h('span', { class: 'gem', style: { background: covenColor(g.id), boxShadow: `0 0 12px ${covenColor(g.id)}` } }),
          h('span', null, nm)),
        h('span', { class: 'mono faint', style: { fontSize: '12px' } }, `coven ${g.id}`));
    }));
  }

  async function swear() {
    const g = covens?.find((c) => c.id === coven);
    if (!g) return;
    const nm = name.trim();
    if (!/^[A-Za-z0-9_-]{3,20}$/.test(nm)) { toast('A warden’s name is 3–20 letters, digits, - or _', 'warn'); return; }
    busy = true; paint();
    try { await enlist(nm, g.id, covenName(g.id, g.meta?.name)); }
    catch (e) { toast((e as Error).message, 'enemy', 6000); }
    busy = false; paint();
  }

  function paint() {
    clear(body);
    const a = wallet.active;
    const job = enlisting.current;

    if (job && job.status !== 'done' && !(a?.playerId)) {
      body.append(head('The oath is being sworn', job.status === 'failed' ? 'The oath faltered' : `Welcome, ${job.name}`),
        h('p', null, `Your soulstone is bound. ${job.guildName} is writing you into the ledger; this takes a few bells.`),
        h('ol', { class: 'stack', style: { paddingLeft: '20px', color: 'var(--ink-2)' } }, ...job.steps.map((s) => h('li', null, speak(s)))),
        job.status === 'failed' ? h('div', { class: 'stack' }, h('p', { style: { color: 'var(--ember-ink)' } }, speak(job.error || '')), h('button', { type: 'button', class: 'btn gold', onclick: () => retryEnlist() }, 'Try the oath again')) : '');
      return;
    }

    if (wallet.state === 'locked') {
      const pass = h('input', { type: 'password', id: 'pass', autocomplete: 'current-password' }) as HTMLInputElement;
      body.append(head('Your soulstone is sealed', 'Speak the passphrase'),
        h('div', { class: 'field' }, h('label', { for: 'pass' }, 'Passphrase'), pass),
        h('div', { class: 'row end', style: { marginTop: '16px' } }, h('button', { type: 'button', class: 'btn gold', onclick: async () => {
          try { await wallet.unlock(pass.value); } catch (e) { toast((e as Error).message, 'enemy'); }
        } }, 'Unseal')));
      return;
    }

    if (wallet.unlocked && a?.playerId) {
      body.append(head('Your soulstone', a.label && a.label !== 'Commander' ? a.label : 'Warden'),
        h('dl', { class: 'facts' },
          h('div', null, h('dt', null, 'Warden sigil'), h('dd', { class: 'mono' }, a.playerId)),
          h('div', null, h('dt', null, 'Isle'), h('dd', { class: 'mono' }, empire.commander?.planetId || 'none yet')),
          h('div', { style: { gridColumn: 'span 2' } }, h('dt', null, 'Soulstone mark'), h('dd', { class: 'mono', style: { fontSize: '13px' } }, '…' + a.address.slice(-12)))));
      if (mode === 'words' && revealed) {
        body.append(h('p', { style: { marginTop: '16px' } }, 'Your soul-words. Anyone who reads them can take everything. Write them somewhere no wind can reach.'),
          h('div', { class: 'words', 'data-raw': '' }, ...revealed.split(' ').map((w, i) => h('span', null, h('i', null, String(i + 1)), w))));
      }
      body.append(h('div', { class: 'row', style: { marginTop: '18px' } },
        mode === 'words'
          ? h('button', { type: 'button', class: 'btn', onclick: () => { revealed = ''; mode = 'choose'; paint(); } }, 'Hide the soul-words')
          : h('button', { type: 'button', class: 'btn', onclick: async () => { try { revealed = await wallet.revealPhrase(''); mode = 'words'; paint(); } catch (e) { toast((e as Error).message, 'enemy'); } } }, 'Show my soul-words'),
        h('button', { type: 'button', class: 'btn ghost', style: { color: 'var(--ember-ink)' }, onclick: async () => {
          if (await confirmBox('Forget this soulstone?', 'It leaves this browser. Only your soul-words can bring your warden back.', 'Forget it')) { wallet.forget(); close(); }
        } }, 'Forget this soulstone')));
      return;
    }

    if (wallet.unlocked && !a?.playerId) mode = mode === 'choose' || mode === 'forge' || mode === 'speak' ? 'coven' : mode;

    if (mode === 'choose') {
      body.append(head('The Oath · 1 of 3', 'Bind your soulstone'),
        h('p', null, 'Your soulstone is your name in the sky. It stays sealed in this browser; Wyrmhold only ever asks it to set its seal on a rite.'),
        h('div', { class: 'stack', style: { marginTop: '14px' } },
          h('button', { type: 'button', class: 'choice', onclick: () => { mode = 'forge'; paint(); } },
            h('span', null, 'Forge a new soulstone', h('small', null, 'Twenty-four soul-words are made for you, sealed to this device')), h('span', { style: { color: 'var(--gold)' } }, '→')),
          h('button', { type: 'button', class: 'choice', onclick: () => { mode = 'speak'; paint(); } },
            h('span', null, 'Speak your soul-words', h('small', null, 'Bring back a warden you already hold')), h('span', { style: { color: 'var(--gold)' } }, '→'))));
      return;
    }

    if (mode === 'speak') {
      const words = h('textarea', { id: 'words', spellcheck: false, autocomplete: 'off', placeholder: 'twelve or twenty-four words' }) as HTMLTextAreaElement;
      body.append(head('The Oath · 1 of 3', 'Speak your soul-words'),
        h('p', null, 'Speak the words in order and your warden wakes exactly as you left them: the same isle, the same beasts, the same alpha.'),
        h('div', { class: 'field' }, h('label', { for: 'words' }, 'Soul-words'), words),
        h('div', { class: 'row between', style: { marginTop: '16px' } },
          h('button', { type: 'button', class: 'btn ghost', onclick: () => { mode = 'choose'; paint(); } }, 'Back'),
          h('button', { type: 'button', class: 'btn gold', disabled: busy, onclick: async () => {
            busy = true; paint();
            try { await wallet.createInstant(words.value); await wallet.resolvePlayers(); toast('Your soulstone wakes.', 'player'); }
            catch (e) { toast((e as Error).message, 'enemy', 6000); }
            busy = false; mode = 'coven'; paint();
          } }, busy ? 'Listening…' : 'Bind it')));
      return;
    }

    // forge (no wallet yet) or coven (wallet bound, no player): both end in the same oath
    const nameIn = h('input', { id: 'warden-name', value: name, maxLength: 20, autocomplete: 'nickname', placeholder: 'Ashwen', oninput: (e: Event) => { name = (e.target as HTMLInputElement).value; } }) as HTMLInputElement;
    body.append(head(mode === 'forge' ? 'The Oath · 2 of 3' : 'The Oath · 2 of 3', 'Swear to a coven'),
      h('p', null, 'A coven lends you its leyline so your first rites have mana, and its signer writes you into the ledger. Then your Elder Wyrm hatches upon a fresh isle.'),
      h('div', { class: 'field' }, h('label', { for: 'warden-name' }, 'Your warden’s name'), nameIn),
      h('p', { class: 'label', style: { marginTop: '16px' } }, 'Covens on the ledger'),
      covenPicker(),
      h('button', { type: 'button', class: 'btn gold block', style: { marginTop: '18px', minHeight: '52px' }, disabled: busy || !coven, onclick: swear }, busy ? 'Swearing…' : 'Swear the oath and seek my isle'));
  }
  // empire.onChange calls back at once: wire listeners only after the state above exists.
  offs = [wallet.onChange(() => paint()), enlisting.onChange(() => paint()), empire.onChange(() => paint())];
  document.addEventListener('keydown', esc);
  window.addEventListener('hashchange', close);
}
