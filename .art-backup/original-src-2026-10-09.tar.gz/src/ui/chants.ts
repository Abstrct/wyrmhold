/* Incantations (the proof-of-work engine's tasks) and the Chronicle (the transaction queue),
 * told in the realm's words. Both are live views over the borrowed ledger modules. */
import { h, clear } from '../core/dom';
import { pow, type PowTask } from '../pow/pow';
import { txq, type TxJob } from '../wallet/queue';
import { live } from '../chain/live';
import { retell, retellError } from '../lore';

const KIND: Record<PowTask['kind'], [string, string]> = {
  build: ['Summoning chant', 'var(--gold)'], mine: ['Delving chant', 'var(--root)'], refine: ['Brewing chant', '#7dffb0'], raid: ['Plunder chant', 'var(--ember)'],
};

function fmtRate(r: number) { return r >= 1e9 ? `${(r / 1e9).toFixed(1)} G` : r >= 1e6 ? `${(r / 1e6).toFixed(1)} M` : r >= 1e3 ? `${(r / 1e3).toFixed(0)} k` : `${Math.round(r)}`; }

export function chantsPanel() {
  const list = h('ul', { class: 'list', style: { gap: '12px' } });
  const meta = h('span', { class: 'mono faint', style: { fontSize: '11px' } });
  const el = h('section', { class: 'glass panel', 'aria-label': 'Incantations' },
    h('div', { class: 'row between', style: { marginBottom: '10px' } }, h('h2', { class: 'display', style: { fontSize: '19px' } }, 'Incantations'), meta), list);
  const paint = () => {
    clear(list);
    const tasks = pow.active.filter((t) => t.account >= 0);
    meta.textContent = pow.rate ? `${fmtRate(pow.rate)}chants/s` : '';
    if (!tasks.length) { list.append(h('li', null, h('p', { class: 'muted', style: { margin: 0, fontSize: '14px' } }, 'No chant is sounding. Summon, delve, brew or ride out to plunder, and the chant begins on its own.'))); return; }
    for (const t of tasks) {
      const [name, color] = KIND[t.kind];
      const need = pow.required(t), best = t.best?.zeros ?? 0;
      const pct = Math.max(4, Math.min(100, (best / Math.max(1, need)) * 100));
      const wait = need > best ? pow.blocksUntil(t, best) : 0;
      const note = t.status === 'submitting' ? 'spoken to the ledger…'
        : best >= need ? 'ready'
          : Number.isFinite(wait) && wait > 0 ? `the bar falls in ~${wait} bells` : t.status === 'hashing' ? 'chanting…' : 'waiting';
      list.append(h('li', { class: 'chant' },
        h('div', { class: 'top' }, h('span', null, name, h('span', { class: 'faint' }, ' · ' + retell(t.label).replace(/^[^·]*chant · /i, '').replace(/ · chant of \d+$/, ''))), h('span', { class: 'mono faint', style: { fontSize: '12px' } }, `${best}/${need}`)),
        h('span', { class: 'bar' }, h('i', { style: { width: pct + '%', background: color } })),
        h('span', { class: 'faint', style: { fontSize: '12px' } }, note + (t.error ? ` · ${retellError(t.error).replace(/\bunder_raid\b/, 'raiders overhead')}` : ''))));
    }
  };
  const offs = [pow.onChange(paint), live.onBlock(paint)];
  paint();
  return { el, dispose: () => offs.forEach((f) => f()) };
}

const STATUS: Record<TxJob['status'], [string, string]> = {
  queued: ['awaits', 'var(--muted)'], waiting: ['gathers breath', 'var(--verdigris)'], signing: ['is sealed', 'var(--gold)'], pending: ['is spoken', 'var(--gold)'],
  success: ['is done', '#7dffb0'], failed: ['failed', 'var(--ember)'], cancelled: ['was let go', 'var(--faint)'],
};

export function chroniclePanel(filter: (j: TxJob) => boolean = () => true, max = 30) {
  const list = h('ol', { class: 'list chron scroll-y', style: { gap: '6px', maxHeight: '170px' } });
  const el = h('section', { class: 'glass panel', 'aria-label': 'Chronicle', style: { display: 'flex', flexDirection: 'column' } },
    h('h2', { class: 'display', style: { fontSize: '19px', marginBottom: '8px' } }, 'Chronicle'), list);
  const paint = (jobs: TxJob[]) => {
    clear(list);
    const shown = jobs.filter(filter).slice().sort((a, b) => b.updatedAt - a.updatedAt).slice(0, max);
    if (!shown.length) { list.append(h('li', null, h('span', { class: 'muted' }, 'Nothing spoken yet. Every rite you sign is written here.'))); return; }
    for (const j of shown) {
      const [word, color] = STATUS[j.status];
      list.append(h('li', null,
        h('span', { class: 'when' }, j.height ? `bell ${j.height}` : new Date(j.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })),
        h('span', null, h('span', null, retell(j.label)), ' ', h('span', { style: { color } }, word),
          j.status === 'waiting' && j.waitReason ? h('span', { class: 'faint' }, ` — ${retellError(j.waitReason)}`) : null,
          j.status === 'failed' && j.error ? h('span', { style: { color: 'var(--ember-ink)' } }, ` — ${retellError(j.error)}`) : null,
          j.status === 'failed' ? h('button', { type: 'button', class: 'btn small ghost', style: { marginLeft: '6px', minHeight: '28px' }, onclick: () => txq.retry(j.id) }, 'Again') : null)));
    }
  };
  const off = txq.onChange(paint);
  return { el, dispose: () => { off(); } };
}
