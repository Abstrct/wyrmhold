/* The guild directory: every guild on chain with what its guild.json says about itself —
 * name, tag, logo, description, and the services it runs (Guild API, GRASS, Matrix).
 * guild.json sends no CORS header, so the relay reads it (and checks it names the same
 * guild as the chain). Cached for 10 minutes, served stale while it refreshes. Without a
 * relay (a static deploy) it falls back to the chain's own list, unnamed. */
import { cached } from '../cache/idb';
import { relayFetch } from './relay';
import { lcd, type RawGuild } from '../chain/lcd';
import { wallet } from '../wallet/wallet';

export interface GuildMeta {
  name: string; tag: string; description: string; logo: string; website: string;
  domain?: string; webapp?: string; socials?: Record<string, string>; denom?: Record<string, string>; baseEnergy?: string;
}
export interface GuildServices { guild_api: string | null; grass: string | null; matrix: string | null; explorer: string | null }
export interface GuildEntry { id: string; chain: RawGuild; meta: GuildMeta | null; services: GuildServices | null; error: string | null }

/** SN Corp: the guild whose infrastructure backs this client by default. */
const ENV = (import.meta as { env?: Record<string, string | undefined> }).env || {};
export const DEFAULT_GUILD = ENV.VITE_DEFAULT_GUILD || '0-5';
/** VITE_GRASS_URL points a devnet client at its own stream; "off" disables GRASS entirely. */
export const FALLBACK_GRASS = ENV.VITE_GRASS_URL || 'wss://beta.playstructs.com:1443';
const TTL = 10 * 60_000;

let last: GuildEntry[] | null = null;
const listeners = new Set<(g: GuildEntry[]) => void>();

/** The latest directory already in hand (null until the first load), for synchronous lookups. */
export function guildsNow(): GuildEntry[] | null { return last; }
export function onGuilds(f: (g: GuildEntry[]) => void) { listeners.add(f); if (last) f(last); return () => { listeners.delete(f); }; }

function publish(list: GuildEntry[]) {
  last = list;
  for (const f of listeners) { try { f(list); } catch (e) { console.error(e); } }
}

async function fromRelay(fresh: boolean): Promise<GuildEntry[]> {
  const r = await relayFetch('/__relay/guilds' + (fresh ? '?fresh=1' : ''));
  const ct = r.headers.get('content-type') || '';
  if (!r.ok || !ct.includes('json')) throw new Error('relay unavailable');
  const body = await r.json() as { guilds?: GuildEntry[] };
  return (body.guilds || []).map(clean);
}

async function fromChain(): Promise<GuildEntry[]> {
  const list = await lcd.list<RawGuild>('guild', 'Guild');
  return list.map((g) => ({ id: g.id, chain: g, meta: null, services: null, error: 'directory relay unavailable' }));
}

/** Whatever the relay hands over is still a third party's self-description: keep strings strings. */
function clean(g: GuildEntry): GuildEntry {
  const s = (v: unknown) => (typeof v === 'string' ? v : '');
  const m = g.meta;
  return {
    id: s(g.id), chain: g.chain, error: g.error ? s(g.error) : null,
    meta: m ? { name: s(m.name), tag: s(m.tag), description: s(m.description), logo: safeUrl(s(m.logo)), website: safeUrl(s(m.website)), domain: s(m.domain), webapp: s(m.webapp),
      socials: m.socials && typeof m.socials === 'object' ? m.socials : {}, denom: m.denom && typeof m.denom === 'object' ? m.denom : {}, baseEnergy: s(m.baseEnergy) } : null,
    services: g.services ? { guild_api: g.services.guild_api || null, grass: g.services.grass || null, matrix: g.services.matrix || null, explorer: g.services.explorer || null } : null,
  };
}

/** Only http(s) links leave this module: a guild.json can't smuggle javascript: into an href/src. */
export function safeUrl(u: string): string {
  try { const x = new URL(u); return x.protocol === 'https:' || x.protocol === 'http:' ? x.toString() : ''; } catch { return ''; }
}

/** Every guild on chain with its directory entry. */
export async function guilds(opts: { fresh?: boolean } = {}): Promise<GuildEntry[]> {
  try {
    const list = await cached('guilds', TTL, () => fromRelay(!!opts.fresh), {
      ns: 'directory', staleWhileRevalidate: true, force: opts.fresh, onUpdate: publish, keep: (v) => v.length > 0,
    });
    publish(list);
    return list;
  } catch {
    const list = await fromChain();
    if (!last) publish(list);
    return list;
  }
}

export async function guildEntry(id: string): Promise<GuildEntry | null> {
  return (await guilds()).find((g) => g.id === id) ?? null;
}

/** Name, tag, logo and description, with sensible fallbacks for guilds that publish nothing. */
export async function guildMeta(id: string): Promise<GuildMeta> {
  const e = await guildEntry(id).catch(() => null);
  return e?.meta?.name ? e.meta : fallbackMeta(id, e?.chain);
}

export function fallbackMeta(id: string, chain?: RawGuild): GuildMeta {
  return { name: chain?.name || `Guild ${id}`, tag: '', description: '', logo: '', website: '' };
}

/** Synchronous best name for a guild: directory, then a plain fallback. */
export function guildLabel(id: string): { name: string; tag: string } {
  const e = last?.find((g) => g.id === id);
  if (e?.meta?.name) return { name: e.meta.name, tag: e.meta.tag || '' };
  return { name: e?.chain?.name || `Guild ${id}`, tag: '' };
}

export async function servicesFor(id: string): Promise<GuildServices | null> {
  return (await guildEntry(id).catch(() => null))?.services ?? null;
}

/** The guild of the player this browser acts as. */
export async function homeGuild(): Promise<string | null> {
  const pid = wallet.active?.playerId;
  if (!pid) return null;
  try { return (await lcd.player(pid)).Player.guildId || null; } catch { return null; }
}
