/* The few DOM helpers the ledger modules (borrowed from the ledger client) ask for,
 * dressed for Wyrmhold: a herald's scroll for toasts and a sealed-oath dialog for confirms. */
import { speak } from '../lore';

type Kind = '' | 'player' | 'enemy' | 'warn';
type Props = Record<string, unknown>;
type Child = Node | string | number | null | undefined | false | Child[];

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props?: Props | null, ...children: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v as EventListener);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k === 'class') el.className = String(v);
    else if (k in el && k !== 'list' && k !== 'form') (el as unknown as Record<string, unknown>)[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  const add = (c: Child) => {
    if (c == null || c === false) return;
    if (Array.isArray(c)) c.forEach(add);
    else el.append(c instanceof Node ? c : String(c));
  };
  children.forEach(add);
  return el;
}

export function clear(el: Element) { while (el.firstChild) el.removeChild(el.firstChild); }

function tray(): HTMLElement {
  let t = document.getElementById('heralds');
  if (!t) { t = h('div', { id: 'heralds', role: 'status', 'aria-live': 'polite' }); document.body.append(t); }
  return t;
}

export function toast(text: string, kind: Kind = '', ms = 3600, action?: { label: string; run: () => void }) {
  const el = h('div', { class: `herald ${kind}` }, h('span', null, speak(text)),
    action ? h('button', { type: 'button', onclick: () => { action.run(); el.remove(); } }, speak(action.label)) : null);
  tray().append(el);
  requestAnimationFrame(() => el.classList.add('on'));
  setTimeout(() => { el.classList.remove('on'); setTimeout(() => el.remove(), 400); }, ms);
}

export function confirmBox(title: string, text: string, ok = 'Confirm', tone: 'player' | 'enemy' = 'enemy'): Promise<boolean> {
  return new Promise((resolve) => {
    const done = (v: boolean) => { veil.remove(); resolve(v); };
    const veil = h('div', { class: 'veil' },
      h('section', { class: 'scroll oath', role: 'dialog', 'aria-modal': 'true', 'aria-label': speak(title) },
        h('h2', null, speak(title)), h('p', null, speak(text)),
        h('div', { class: 'row end' },
          h('button', { type: 'button', class: 'btn ghost', onclick: () => done(false) }, 'Not now'),
          h('button', { type: 'button', class: `btn ${tone === 'enemy' ? 'ember' : 'gold'}`, onclick: () => done(true) }, speak(ok)))));
    document.body.append(veil);
  });
}
